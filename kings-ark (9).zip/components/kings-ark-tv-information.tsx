"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Play,
  Calendar,
  Tag,
  ExternalLink,
  Bookmark,
  ThumbsUp,
  Eye,
  BarChart2,
  Globe,
  Users,
  Cpu,
  Leaf,
  DollarSign,
} from "lucide-react"
import Image from "next/image"
import { mediaAssets } from "@/components/media-assets"

export default function KingsArkTVInformation() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("featured")

  const featuredVideos = [
    {
      id: "v1",
      title: "Global Market Trends 2025",
      thumbnail: mediaAssets.videos.marketAnalysis,
      duration: "18:24",
      views: "12.5K",
      date: "March 15, 2025",
      category: "Market Analysis",
      description: "An in-depth analysis of global market trends and predictions for the coming year.",
    },
    {
      id: "v2",
      title: "The Future of International Trade",
      thumbnail: mediaAssets.videos.tradeExplainer,
      duration: "24:10",
      views: "8.7K",
      date: "March 10, 2025",
      category: "Trade Insights",
      description: "Exploring how technology and geopolitical shifts are reshaping international trade.",
    },
    {
      id: "v3",
      title: "Sustainable Business Practices",
      thumbnail: mediaAssets.videos.businessPresentation,
      duration: "15:45",
      views: "6.2K",
      date: "March 5, 2025",
      category: "Sustainability",
      description: "How businesses are incorporating sustainability into their global operations.",
    },
  ]

  const liveStreams = [
    {
      id: "l1",
      title: "Global Trade Summit 2025 - Live Coverage",
      thumbnail: mediaAssets.videos.businessPresentation,
      viewers: "1.2K",
      status: "live",
      category: "Events",
      description: "Live coverage of the annual Global Trade Summit featuring keynote speakers and panel discussions.",
    },
    {
      id: "l2",
      title: "Market Opening Bell - Daily Briefing",
      thumbnail: mediaAssets.videos.marketAnalysis,
      viewers: "850",
      status: "live",
      category: "Market Updates",
      description: "Daily live briefing on market openings and key developments affecting global trade.",
    },
    {
      id: "l3",
      title: "Tech Export Roundtable",
      thumbnail: mediaAssets.videos.b2bNetworking,
      viewers: "620",
      status: "live",
      category: "Technology",
      description: "Industry leaders discuss the latest trends in technology exports and international partnerships.",
    },
  ]

  const upcomingShows = [
    {
      id: "u1",
      title: "Emerging Markets Spotlight: Africa",
      thumbnail: mediaAssets.videos.marketAnalysis,
      date: "March 20, 2025",
      time: "10:00 AM GMT",
      category: "Market Analysis",
      description: "A deep dive into the emerging markets across Africa and opportunities for global businesses.",
    },
    {
      id: "u2",
      title: "Supply Chain Innovation Summit",
      thumbnail: mediaAssets.videos.businessPresentation,
      date: "March 25, 2025",
      time: "2:00 PM GMT",
      category: "Supply Chain",
      description: "Exploring innovative approaches to global supply chain management and logistics.",
    },
    {
      id: "u3",
      title: "CEO Interview Series: Global Leaders",
      thumbnail: mediaAssets.videos.b2bNetworking,
      date: "April 1, 2025",
      time: "3:30 PM GMT",
      category: "Leadership",
      description: "Exclusive interviews with CEOs of leading global companies on their international strategies.",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Kings Ark TV</h1>
          <p className="text-muted-foreground">Business news and market insights</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <Button className="flex-1 sm:flex-none">Subscribe</Button>
          <Button variant="outline" className="flex-1 sm:flex-none">
            My Watchlist
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search videos, shows, and topics..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2 w-full sm:w-auto">
          <Tag className="h-4 w-4" />
          Categories
        </Button>
      </div>

      <Tabs defaultValue="featured" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="featured">Featured</TabsTrigger>
          <TabsTrigger value="live">Live Now</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
        </TabsList>

        <TabsContent value="featured" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {featuredVideos.map((video) => (
              <Card key={video.id} className="h-full flex flex-col">
                <div className="relative">
                  <div className="aspect-video relative rounded-t-lg overflow-hidden">
                    <Image
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <Button variant="secondary" size="icon" className="h-12 w-12 rounded-full">
                        <Play className="h-6 w-6" />
                      </Button>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                      {video.duration}
                    </div>
                  </div>
                </div>
                <CardContent className="flex-1 p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium line-clamp-2">{video.title}</h3>
                    <Badge variant="outline">{video.category}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{video.description}</p>
                  <div className="flex items-center text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>{video.date}</span>
                    <span className="mx-1">•</span>
                    <Eye className="h-3 w-3 mr-1" />
                    <span>{video.views} views</span>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between p-4 pt-0">
                  <Button variant="ghost" size="sm">
                    <ThumbsUp className="h-4 w-4 mr-1" />
                    Like
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Bookmark className="h-4 w-4 mr-1" />
                    Save
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="live" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {liveStreams.map((stream) => (
              <Card key={stream.id} className="h-full flex flex-col">
                <div className="relative">
                  <div className="aspect-video relative rounded-t-lg overflow-hidden">
                    <Image
                      src={stream.thumbnail || "/placeholder.svg"}
                      alt={stream.title}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                      <Button variant="secondary" size="icon" className="h-12 w-12 rounded-full">
                        <Play className="h-6 w-6" />
                      </Button>
                    </div>
                    <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded-full flex items-center">
                      <span className="h-2 w-2 bg-white rounded-full mr-1 animate-pulse"></span>
                      LIVE
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                      {stream.viewers} watching
                    </div>
                  </div>
                </div>
                <CardContent className="flex-1 p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium line-clamp-2">{stream.title}</h3>
                    <Badge variant="outline">{stream.category}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{stream.description}</p>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Button className="w-full">Watch Now</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="upcoming" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingShows.map((show) => (
              <Card key={show.id} className="h-full flex flex-col">
                <div className="relative">
                  <div className="aspect-video relative rounded-t-lg overflow-hidden">
                    <Image src={show.thumbnail || "/placeholder.svg"} alt={show.title} fill className="object-cover" />
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="text-center">
                        <p className="text-white font-medium">{show.date}</p>
                        <p className="text-white text-sm">{show.time}</p>
                      </div>
                    </div>
                  </div>
                </div>
                <CardContent className="flex-1 p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium line-clamp-2">{show.title}</h3>
                    <Badge variant="outline">{show.category}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{show.description}</p>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Button variant="outline" className="w-full">
                    <Calendar className="h-4 w-4 mr-2" />
                    Set Reminder
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Popular Categories</CardTitle>
          <CardDescription>Explore content by topic</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
          {[
            { name: "Market Analysis", icon: <BarChart2 className="h-6 w-6" /> },
            { name: "Trade Insights", icon: <Globe className="h-6 w-6" /> },
            { name: "Leadership", icon: <Users className="h-6 w-6" /> },
            { name: "Technology", icon: <Cpu className="h-6 w-6" /> },
            { name: "Sustainability", icon: <Leaf className="h-6 w-6" /> },
            { name: "Finance", icon: <DollarSign className="h-6 w-6" /> },
          ].map((category) => (
            <Button
              key={category.name}
              variant="outline"
              className="h-auto flex flex-col items-center justify-center p-4 gap-2"
            >
              {category.icon}
              <span className="text-xs">{category.name}</span>
            </Button>
          ))}
        </CardContent>
        <CardFooter>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.open("https://kingsglobalfunding.world", "_blank")}
          >
            View All Categories
            <ExternalLink className="h-4 w-4 ml-2" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

