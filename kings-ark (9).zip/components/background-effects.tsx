"use client"

import { useEffect, useState } from "react"
import { mediaAssets } from "@/components/media-assets"
import type { BackgroundEffectsProps } from "@/types"

export default function BackgroundEffects({ type = "worldMap" }: BackgroundEffectsProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted || type === "none") return null

  let backgroundUrl = ""
  let opacity = "0.05"

  switch (type) {
    case "smoke":
      backgroundUrl = mediaAssets.backgrounds.smoke
      opacity = "0.1"
      break
    case "particles":
      backgroundUrl = mediaAssets.backgrounds.particles
      opacity = "0.08"
      break
    case "worldMap":
      backgroundUrl = mediaAssets.backgrounds.worldMap
      opacity = "0.1"
      break
  }

  return (
    <div
      className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden"
      style={{
        backgroundImage: `url(${backgroundUrl})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        opacity: opacity,
      }}
    >
      {/* Blinking dots overlay for worldMap */}
      {type === "worldMap" && (
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url(${mediaAssets.globe.dots})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            opacity: "0.3",
            mixBlendMode: "screen",
          }}
        />
      )}
    </div>
  )
}

