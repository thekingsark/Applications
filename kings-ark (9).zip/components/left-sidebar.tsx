"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import {
  Home,
  BarChart2,
  Globe,
  Users,
  Tv,
  DollarSign,
  User,
  FileText,
  Briefcase,
  Building,
  ShoppingBag,
  Zap,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import Link from "next/link"
import SpinningCrownLogo from "./spinning-crown-logo"
import type { MenuItem } from "@/types"

export default function LeftSidebar() {
  const [activeItem, setActiveItem] = useState("dashboard")
  const [collapsed, setCollapsed] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  // Check if mobile on mount and when window resizes
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
      // Make sidebar visible by default on all devices
      setCollapsed(window.innerWidth < 768)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Update the menuItems array to include Kings Ark Metaverse
  const menuItems: MenuItem[] = [
    {
      name: "Dashboard",
      href: "#dashboard",
      icon: <Home className="h-5 w-5" />,
      description: "Overview of your trading activities",
    },
    {
      name: "Markets",
      href: "#markets",
      icon: <BarChart2 className="h-5 w-5" />,
      description: "Explore global market opportunities",
    },
    {
      name: "Trade",
      href: "#trade",
      icon: <Globe className="h-5 w-5" />,
      description: "Trade with businesses worldwide",
    },
    {
      name: "B2B Social Media",
      href: "/social",
      icon: <Users className="h-5 w-5" />,
      description: "Connect with business partners",
    },
    {
      name: "Kings Ark TV",
      href: "#tv",
      icon: <Tv className="h-5 w-5" />,
      description: "Business news and market insights",
    },
    {
      name: "Kings Global Fundings",
      href: "/global-fundings",
      icon: <DollarSign className="h-5 w-5" />,
      description: "Access global funding opportunities",
    },
    {
      name: "Kings Ark Metaverse",
      href: "/metaverse",
      icon: <Globe className="h-5 w-5" />,
      description: "Virtual conference rooms for business meetings",
    },
    {
      name: "Bidding",
      href: "#bidding",
      icon: <DollarSign className="h-5 w-5" />,
      description: "Participate in global bidding opportunities",
    },
    {
      name: "Account",
      href: "#account",
      icon: <User className="h-5 w-5" />,
      description: "Manage your account settings",
    },
  ]

  const secondaryItems = [
    {
      name: "Documents",
      href: "/documents",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      name: "Projects",
      href: "/projects",
      icon: <Briefcase className="h-5 w-5" />,
    },
    {
      name: "Organizations",
      href: "/organizations",
      icon: <Building className="h-5 w-5" />,
    },
    {
      name: "Close Deals",
      href: "/close-deals",
      icon: <ShoppingBag className="h-5 w-5" />,
    },
  ]

  const externalLinks = [
    {
      name: "Kings Global Funding",
      url: "https://kingsglobalfunding.world",
      icon: <Globe className="h-4 w-4" />,
    },
    {
      name: "Kings Idea Connections",
      url: "https://kingsideaconnections.org",
      icon: <Zap className="h-4 w-4" />,
    },
    {
      name: "B2B Social Media",
      url: "https://kingsideaconnections.org",
      icon: <Users className="h-4 w-4" />,
    },
    {
      name: "Close Deals Cloud",
      url: "https://closedeals.cloud",
      icon: <ShoppingBag className="h-4 w-4" />,
    },
    {
      name: "World Trade Center",
      url: "https://worldtradecenter.cloud",
      icon: <Building className="h-4 w-4" />,
    },
    {
      name: "Meet The Founder",
      url: "https://www.kingsleymichaeluhiara.org",
      icon: <User className="h-4 w-4" />,
    },
    {
      name: "The World Trade Center Cloud",
      url: "https://theworldtradecenter.cloud",
      icon: <Building className="h-4 w-4" />,
    },
  ]

  return (
    <div
      className={`${collapsed ? "w-16" : "w-64"} h-screen border-r bg-background flex flex-col overflow-y-auto transition-all duration-300 relative`}
    >
      {/* Collapse/Expand Button */}
      <Button
        variant="outline"
        size="icon"
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 z-10 h-8 w-8 rounded-full border bg-primary/10 shadow-md shadow-primary/20 glow-button animate-pulse"
      >
        {collapsed ? (
          <ChevronRight className="h-4 w-4 text-primary" />
        ) : (
          <ChevronLeft className="h-4 w-4 text-primary" />
        )}
      </Button>

      <div className={`p-4 border-b flex items-center ${collapsed ? "justify-center" : "gap-2"}`}>
        <SpinningCrownLogo size={32} />
        {!collapsed && <h1 className="text-xl font-bold">Kings Ark</h1>}
      </div>

      <div className="flex-1 py-4 px-2">
        <nav className="space-y-1">
          {menuItems.map((item) => (
            <Link key={item.name} href={item.href} onClick={() => setActiveItem(item.name.toLowerCase())}>
              <Button
                variant={activeItem === item.name.toLowerCase() ? "default" : "ghost"}
                className={`w-full justify-start mb-1 glow-button ${
                  activeItem === item.name.toLowerCase()
                    ? "bg-primary text-primary-foreground shadow-md shadow-primary/20"
                    : "hover:bg-accent hover:text-primary"
                } ${collapsed ? "px-2" : ""}`}
                title={collapsed ? item.name : undefined}
              >
                <span className={`menu-icon ${activeItem === item.name.toLowerCase() ? "gold-glow-icon" : ""}`}>
                  {item.icon}
                </span>
                {!collapsed && <span className="ml-2">{item.name}</span>}
              </Button>
            </Link>
          ))}
        </nav>

        {!collapsed && (
          <>
            <div className="mt-8">
              <h2 className="px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                Resources
              </h2>
              <nav className="space-y-1">
                {secondaryItems.map((item) => (
                  <Link key={item.name} href={item.href}>
                    <Button variant="ghost" className="w-full justify-start mb-1 hover:bg-accent glow-button">
                      <span className="menu-icon">{item.icon}</span>
                      <span className="ml-2">{item.name}</span>
                    </Button>
                  </Link>
                ))}
              </nav>
            </div>

            <div className="mt-8">
              <h2 className="px-4 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                External Links
              </h2>
              <nav className="space-y-1">
                {externalLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center px-4 py-2 text-sm rounded-md hover:bg-accent hover:text-accent-foreground transition-colors glow-button"
                  >
                    <span className="menu-icon">{link.icon}</span>
                    <span className="ml-2">{link.name}</span>
                    <ExternalLink className="h-3 w-3 ml-auto opacity-50" />
                  </a>
                ))}
              </nav>
            </div>
          </>
        )}

        {collapsed && (
          <div className="mt-8 flex flex-col items-center gap-4">
            {secondaryItems.map((item) => (
              <Link key={item.name} href={item.href}>
                <Button variant="ghost" size="icon" className="glow-button" title={item.name}>
                  <span className="menu-icon">{item.icon}</span>
                </Button>
              </Link>
            ))}

            <div className="border-t w-full my-2"></div>

            {externalLinks.map((link) => (
              <a key={link.name} href={link.url} target="_blank" rel="noopener noreferrer" title={link.name}>
                <Button variant="ghost" size="icon" className="glow-button">
                  <span className="menu-icon">{link.icon}</span>
                </Button>
              </a>
            ))}
          </div>
        )}
      </div>

      <div className={`p-4 border-t ${collapsed ? "flex justify-center" : ""}`}>
        {collapsed ? (
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
            <span className="text-sm font-medium">KA</span>
          </div>
        ) : (
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
              <span className="text-sm font-medium">KA</span>
            </div>
            <div className="ml-2">
              <p className="text-sm font-medium">Guest User</p>
              <p className="text-xs text-muted-foreground">guest@kingsark.com</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

