"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  MessageSquare,
  Users,
  Globe,
  Building,
  Calendar,
  ThumbsUp,
  MessageCircle,
  Share2,
  ExternalLink,
} from "lucide-react"
import Image from "next/image"
import { mediaAssets } from "@/components/media-assets"

export default function B2BSocialInformation() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("feed")

  const posts = [
    {
      id: "p1",
      author: {
        name: "Global Tech Solutions",
        avatar: "/placeholder.svg?height=40&width=40",
        verified: true,
        location: "New York, USA",
      },
      content:
        "Excited to announce our new partnership with Kings Ark World Trade Center to expand our global reach in technology distribution. Looking forward to connecting with potential partners in Asia and Europe!",
      image: mediaAssets.business.handshake,
      likes: 128,
      comments: 32,
      shares: 18,
      time: "2 hours ago",
    },
    {
      id: "p2",
      author: {
        name: "EcoFarm Exports",
        avatar: "/placeholder.svg?height=40&width=40",
        verified: false,
        location: "São Paulo, Brazil",
      },
      content:
        "Our sustainable farming practices have led to a 30% increase in export volume this quarter. We're looking for distribution partners in North America and Europe. Connect with us to learn more about our organic produce.",
      image: mediaAssets.business.agriculture,
      likes: 95,
      comments: 21,
      shares: 14,
      time: "5 hours ago",
    },
    {
      id: "p3",
      author: {
        name: "MediTech Innovations",
        avatar: "/placeholder.svg?height=40&width=40",
        verified: true,
        location: "Berlin, Germany",
      },
      content:
        "Join us at the upcoming Global Healthcare Summit in London next month. We'll be showcasing our latest medical devices and looking for distribution partners across emerging markets.",
      image: mediaAssets.business.technology,
      likes: 76,
      comments: 15,
      shares: 9,
      time: "1 day ago",
    },
  ]

  const connections = [
    {
      id: "c1",
      name: "Global Manufacturing Alliance",
      avatar: "/placeholder.svg?height=40&width=40",
      industry: "Manufacturing",
      location: "Multiple Locations",
      members: 1240,
      description: "A network of manufacturing companies collaborating on global supply chain solutions.",
    },
    {
      id: "c2",
      name: "Tech Innovators Network",
      avatar: "/placeholder.svg?height=40&width=40",
      industry: "Technology",
      location: "Global",
      members: 3450,
      description: "Connecting technology innovators with potential partners and investors worldwide.",
    },
    {
      id: "c3",
      name: "Sustainable Trade Initiative",
      avatar: "/placeholder.svg?height=40&width=40",
      industry: "Various",
      location: "Global",
      members: 2180,
      description: "Promoting sustainable and ethical trade practices across industries.",
    },
    {
      id: "c4",
      name: "Healthcare Exporters Association",
      avatar: "/placeholder.svg?height=40&width=40",
      industry: "Healthcare",
      location: "Europe",
      members: 890,
      description: "European healthcare companies focused on global export opportunities.",
    },
  ]

  const events = [
    {
      id: "e1",
      title: "Global Trade Summit 2025",
      date: "May 15-17, 2025",
      location: "Singapore",
      attendees: 1500,
      description: "Annual gathering of trade professionals, policymakers, and business leaders.",
    },
    {
      id: "e2",
      title: "Tech Export Conference",
      date: "June 8-10, 2025",
      location: "San Francisco, USA",
      attendees: 1200,
      description: "Focused on technology exports and international partnerships.",
    },
    {
      id: "e3",
      title: "Agricultural Trade Expo",
      date: "July 22-24, 2025",
      location: "Madrid, Spain",
      attendees: 950,
      description: "Showcasing agricultural products and connecting producers with buyers.",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">B2B Social Network</h1>
          <p className="text-muted-foreground">Connect with businesses worldwide</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <Button className="flex-1 sm:flex-none">Create Post</Button>
          <Button variant="outline" className="flex-1 sm:flex-none">
            My Network
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-6">
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search posts, companies, or events..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" className="gap-2 w-full sm:w-auto">
              <Globe className="h-4 w-4" />
              Global Feed
            </Button>
          </div>

          <Tabs defaultValue="feed" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="feed">Feed</TabsTrigger>
              <TabsTrigger value="connections">Connections</TabsTrigger>
              <TabsTrigger value="events">Events</TabsTrigger>
            </TabsList>

            <TabsContent value="feed" className="mt-4 space-y-4">
              {posts.map((post) => (
                <Card key={post.id}>
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarImage src={post.author.avatar} alt={post.author.name} />
                        <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">{post.author.name}</h3>
                          {post.author.verified && (
                            <Badge variant="outline" className="h-5 text-xs">
                              Verified
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Globe className="h-3 w-3 mr-1" />
                          <span>{post.author.location}</span>
                          <span className="mx-1">•</span>
                          <span>{post.time}</span>
                        </div>
                      </div>
                    </div>

                    <p>{post.content}</p>

                    {post.image && (
                      <div className="relative w-full h-[200px] sm:h-[300px] rounded-lg overflow-hidden">
                        <Image src={post.image || "/placeholder.svg"} alt="Post image" fill className="object-cover" />
                      </div>
                    )}

                    <div className="flex justify-between items-center pt-2 border-t">
                      <Button variant="ghost" size="sm" className="gap-1">
                        <ThumbsUp className="h-4 w-4" />
                        <span>{post.likes}</span>
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-1">
                        <MessageCircle className="h-4 w-4" />
                        <span>{post.comments}</span>
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-1">
                        <Share2 className="h-4 w-4" />
                        <span>{post.shares}</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="connections" className="mt-4 space-y-4">
              {connections.map((connection) => (
                <Card key={connection.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Avatar>
                        <AvatarImage src={connection.avatar} alt={connection.name} />
                        <AvatarFallback>{connection.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <h3 className="font-medium">{connection.name}</h3>
                          <Badge variant="outline" className="w-fit">
                            {connection.industry}
                          </Badge>
                        </div>
                        <div className="flex items-center text-xs text-muted-foreground mt-1">
                          <Globe className="h-3 w-3 mr-1" />
                          <span>{connection.location}</span>
                          <span className="mx-1">•</span>
                          <Users className="h-3 w-3 mr-1" />
                          <span>{connection.members} members</span>
                        </div>
                        <p className="text-sm mt-2">{connection.description}</p>
                        <div className="flex flex-col sm:flex-row gap-2 mt-3">
                          <Button size="sm" className="w-full sm:w-auto">
                            Join Network
                          </Button>
                          <Button variant="outline" size="sm" className="w-full sm:w-auto">
                            View Profile
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="events" className="mt-4 space-y-4">
              {events.map((event) => (
                <Card key={event.id}>
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row gap-4">
                      <div className="sm:w-24 flex flex-row sm:flex-col items-center sm:items-start gap-2 sm:gap-0">
                        <Calendar className="h-12 w-12 text-primary" />
                        <div className="text-center">
                          <p className="text-sm font-medium">{event.date.split(",")[0]}</p>
                          <p className="text-xs text-muted-foreground">{event.date.split(",")[1] || ""}</p>
                        </div>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-lg">{event.title}</h3>
                        <div className="flex items-center text-sm text-muted-foreground mt-1">
                          <Globe className="h-4 w-4 mr-1" />
                          <span>{event.location}</span>
                          <span className="mx-1">•</span>
                          <Users className="h-4 w-4 mr-1" />
                          <span>{event.attendees} attendees</span>
                        </div>
                        <p className="text-sm mt-2">{event.description}</p>
                        <div className="flex flex-col sm:flex-row gap-2 mt-3">
                          <Button size="sm" className="w-full sm:w-auto">
                            Register
                          </Button>
                          <Button variant="outline" size="sm" className="w-full sm:w-auto">
                            More Info
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Network</CardTitle>
              <CardDescription>Connect with businesses</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Connections</p>
                  <p className="text-sm text-muted-foreground">0 connections</p>
                </div>
                <Button variant="outline" size="sm">
                  Find Connections
                </Button>
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Groups</p>
                  <p className="text-sm text-muted-foreground">0 groups</p>
                </div>
                <Button variant="outline" size="sm">
                  Discover Groups
                </Button>
              </div>
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium">Events</p>
                  <p className="text-sm text-muted-foreground">0 upcoming</p>
                </div>
                <Button variant="outline" size="sm">
                  Browse Events
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Suggested Connections</CardTitle>
              <CardDescription>Based on your profile</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={`/placeholder.svg?height=40&width=40&text=Company${i}`} alt={`Company ${i}`} />
                    <AvatarFallback>C{i}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-medium">Company Name {i}</p>
                    <p className="text-xs text-muted-foreground">Industry • Location</p>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Users className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" className="w-full">
                View More
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Trending Topics</CardTitle>
              <CardDescription>Popular in your network</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {["#GlobalTrade", "#Sustainability", "#SupplyChain", "#TechExports", "#RenewableEnergy"].map((topic) => (
                <div key={topic} className="flex items-center gap-2">
                  <span className="text-primary">{topic}</span>
                  <span className="text-xs text-muted-foreground">Trending</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>B2B Networking Resources</CardTitle>
          <CardDescription>Tools to enhance your business connections</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <div className="border rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Building className="h-5 w-5 text-primary" />
              <h4 className="font-medium">Company Directory</h4>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              Browse our comprehensive directory of businesses across industries and regions.
            </p>
            <Button variant="outline" size="sm" className="w-full">
              Explore Directory
            </Button>
          </div>

          <div className="border rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              <h4 className="font-medium">Networking Guide</h4>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              Learn effective strategies for building valuable business connections.
            </p>
            <Button variant="outline" size="sm" className="w-full">
              Read Guide
            </Button>
          </div>

          <div className="border rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-5 w-5 text-primary" />
              <h4 className="font-medium">Event Calendar</h4>
            </div>
            <p className="text-sm text-muted-foreground mb-3">
              Stay updated on upcoming trade shows, conferences, and networking events.
            </p>
            <Button variant="outline" size="sm" className="w-full">
              View Calendar
            </Button>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.open("https://kingsideaconnections.org", "_blank")}
          >
            Visit Kings Idea Connections
            <ExternalLink className="h-4 w-4 ml-2" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

