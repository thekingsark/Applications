"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search, Settings, Mic, Moon, Sun, Menu, X, ChevronRight, ChevronLeft } from "lucide-react"
import SpinningCrownLogo from "./spinning-crown-logo"
import LanguageTranslator from "./language-translator"
import MarketInformation from "./market-information"
import TradeInformation from "./trade-information"
import KingsArkTVInformation from "./kings-ark-tv-information"
import BiddingInformation from "./bidding-information"
import AccountInformation from "./account-information"
import { useTheme } from "next-themes"
import { detectBrowserLanguage, applyTranslations } from "@/lib/translation-service"
import type { SupportedLanguage } from "@/types"
import LeftSidebar from "./left-sidebar"
import RightSidebar from "./right-sidebar"
import AccessibilityPanel from "./accessibility-panel"
import TextToSpeech from "./text-to-speech"
import VoiceSearch from "./voice-search"
import AIChat from "./ai-chat"
import DashboardCharts from "./dashboard-charts"
import TradePerformanceTable from "./trade-performance-table"
import { useRouter } from "next/navigation"

export default function MainContent() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("dashboard")
  const [searchQuery, setSearchQuery] = useState("")
  const [showSettings, setShowSettings] = useState(false)
  const [showVoiceSearch, setShowVoiceSearch] = useState(false)
  const [showAccessibility, setShowAccessibility] = useState(false)
  const [showTextToSpeech, setShowTextToSpeech] = useState(false)
  const [showAIChat, setShowAIChat] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState<SupportedLanguage>(detectBrowserLanguage())
  const { theme, setTheme } = useTheme()
  const [isLoaded, setIsLoaded] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [leftSidebarVisible, setLeftSidebarVisible] = useState(false)
  const [rightSidebarVisible, setRightSidebarVisible] = useState(false)
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [showSearchResults, setShowSearchResults] = useState(false)

  // Handle language change
  const handleLanguageChange = (languageCode: string) => {
    setCurrentLanguage(languageCode as SupportedLanguage)
    applyTranslations(languageCode as SupportedLanguage)
  }

  // Improved search functionality
  const handleSearch = (query: string) => {
    setSearchQuery(query)

    if (query.trim() === "") {
      setShowSearchResults(false)
      return
    }

    // Simulate search results
    const results = [
      { id: 1, title: "Global Market Trends", type: "Market Report", url: "/market-reports/global-trends" },
      { id: 2, title: "Technology Sector Analysis", type: "Market Report", url: "/market-reports/technology-sector" },
      { id: 3, title: "Trade Opportunities in Asia", type: "Trade Information", url: "#trade" },
      { id: 4, title: "B2B Networking Guide", type: "Help Center", url: "/help-center/networking" },
      { id: 5, title: "Account Settings", type: "User Guide", url: "#account" },
      { id: 6, title: "Bidding Process Overview", type: "Help Center", url: "#bidding" },
    ].filter(
      (item) =>
        item.title.toLowerCase().includes(query.toLowerCase()) || item.type.toLowerCase().includes(query.toLowerCase()),
    )

    setSearchResults(results)
    setShowSearchResults(true)
  }

  // Function to navigate to search result
  const navigateToResult = (url: string) => {
    setShowSearchResults(false)

    if (url.startsWith("#")) {
      // Internal tab navigation
      setActiveTab(url.substring(1))
    } else {
      // External page navigation
      router.push(url)
    }
  }

  // Toggle theme
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  useEffect(() => {
    try {
      // Simulate loading content
      setTimeout(() => {
        setIsLoaded(true)
      }, 500)
    } catch (err) {
      console.error("Error in MainContent:", err)
      setError("Failed to initialize main content")
    }
  }, [])

  // Check screen size to determine sidebar visibility
  useEffect(() => {
    const handleResize = () => {
      // Always make sidebars visible, but collapsed on smaller screens
      setLeftSidebarVisible(true)
      setRightSidebarVisible(true)
    }

    handleResize()
    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [])

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="max-w-md w-full">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <h2 className="text-2xl font-bold">Error Loading Content</h2>
              <p className="text-muted-foreground">{error}</p>
              <Button onClick={() => window.location.reload()}>Refresh Page</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Fallback UI while loading
  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <SpinningCrownLogo size={60} />
          <p>Loading main content...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Left Sidebar - Hidden on mobile unless toggled */}
      {leftSidebarVisible && <LeftSidebar />}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen overflow-hidden">
        {/* Header */}
        <header className="border-b sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between px-4 md:px-6">
            <div className="flex items-center gap-2">
              {/* Mobile menu button */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                <span className="sr-only">Toggle menu</span>
              </Button>

              {/* Left sidebar toggle button - visible on tablet and above */}
              <Button
                variant="outline"
                size="icon"
                className="hidden md:flex glow-button bg-primary/10 shadow-md shadow-primary/20"
                onClick={() => setLeftSidebarVisible(!leftSidebarVisible)}
              >
                {leftSidebarVisible ? (
                  <ChevronLeft className="h-5 w-5 text-primary" />
                ) : (
                  <ChevronRight className="h-5 w-5 text-primary" />
                )}
                <span className="sr-only">Toggle left sidebar</span>
              </Button>

              <SpinningCrownLogo size={32} />
              <h1 className="text-xl font-bold hidden sm:block">Kings Ark WTC</h1>
              <h1 className="text-xl font-bold sm:hidden">Kings Ark</h1>
            </div>

            <div className="flex-1 mx-4 max-w-md hidden sm:block relative">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search markets, companies, or products..."
                  className="w-full bg-background pl-8 pr-12"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch(searchQuery)}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-9 w-9"
                  onClick={() => setShowVoiceSearch(true)}
                >
                  <Mic className="h-4 w-4" />
                  <span className="sr-only">Voice Search</span>
                </Button>
              </div>

              {/* Search Results Dropdown */}
              {showSearchResults && searchResults.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-md shadow-lg z-50 max-h-[300px] overflow-y-auto">
                  <div className="p-2 border-b">
                    <p className="text-sm font-medium">Search Results</p>
                  </div>
                  <ul>
                    {searchResults.map((result) => (
                      <li key={result.id} className="border-b last:border-0">
                        <button
                          className="w-full text-left p-3 hover:bg-muted/50 transition-colors"
                          onClick={() => navigateToResult(result.url)}
                        >
                          <p className="font-medium">{result.title}</p>
                          <p className="text-xs text-muted-foreground">{result.type}</p>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="sm:hidden"
                onClick={() => {
                  if (searchQuery) {
                    handleSearch(searchQuery)
                  } else {
                    setShowVoiceSearch(true)
                  }
                }}
              >
                <Search className="h-5 w-5" />
                <span className="sr-only">Search</span>
              </Button>

              <div className="hidden sm:block">
                <LanguageTranslator onLanguageChange={handleLanguageChange} />
              </div>

              <Button variant="ghost" size="icon" onClick={toggleTheme}>
                {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                <span className="sr-only">Toggle theme</span>
              </Button>

              <Button variant="ghost" size="icon" onClick={() => setShowAIChat(true)} className="relative glow-button">
                <div className="absolute -top-1 -right-1 w-2 h-2 bg-green-500 rounded-full"></div>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5"
                >
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                <span className="sr-only">AI Chat</span>
              </Button>

              <Button variant="ghost" size="icon" onClick={() => setShowSettings(true)}>
                <Settings className="h-5 w-5" />
                <span className="sr-only">Settings</span>
              </Button>

              {/* Right sidebar toggle button - visible on desktop and above */}
              <Button
                variant="outline"
                size="icon"
                className="hidden lg:flex glow-button bg-primary/10 shadow-md shadow-primary/20"
                onClick={() => setRightSidebarVisible(!rightSidebarVisible)}
              >
                {rightSidebarVisible ? (
                  <ChevronRight className="h-5 w-5 text-primary" />
                ) : (
                  <ChevronLeft className="h-5 w-5 text-primary" />
                )}
                <span className="sr-only">Toggle right sidebar</span>
              </Button>
            </div>
          </div>
        </header>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden fixed inset-0 z-30 bg-background/95 backdrop-blur-sm pt-16">
            <div className="container p-4 space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold">Menu</h2>
                <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="space-y-2">
                {["dashboard", "markets", "trade", "social", "tv", "bidding", "account"].map((tab) => (
                  <Button
                    key={tab}
                    variant={activeTab === tab ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => {
                      setActiveTab(tab)
                      setMobileMenuOpen(false)
                    }}
                  >
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </Button>
                ))}
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Language</span>
                  <LanguageTranslator onLanguageChange={handleLanguageChange} />
                </div>
              </div>

              <div className="pt-4 border-t">
                <div className="space-y-2">
                  <Button
                    variant="ghost"
                    className="w-full justify-start"
                    onClick={() => {
                      setShowAccessibility(true)
                      setMobileMenuOpen(false)
                    }}
                  >
                    Accessibility Options
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start"
                    onClick={() => {
                      setShowTextToSpeech(true)
                      setMobileMenuOpen(false)
                    }}
                  >
                    Text to Speech
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Main navigation tabs */}
        <div className="container mt-4 px-4 md:px-6">
          <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="hidden md:grid md:grid-cols-7 w-full">
              <TabsTrigger value="dashboard" className="glow-tab hover:text-primary hover:bg-primary/10">
                Dashboard
              </TabsTrigger>
              <TabsTrigger value="markets" className="glow-tab hover:text-primary hover:bg-primary/10">
                Markets
              </TabsTrigger>
              <TabsTrigger value="trade" className="glow-tab hover:text-primary hover:bg-primary/10">
                Trade
              </TabsTrigger>
              <TabsTrigger value="social" className="glow-tab hover:text-primary hover:bg-primary/10">
                B2B Social
              </TabsTrigger>
              <TabsTrigger value="tv" className="glow-tab hover:text-primary hover:bg-primary/10">
                Kings Ark TV
              </TabsTrigger>
              <TabsTrigger value="bidding" className="glow-tab hover:text-primary hover:bg-primary/10">
                Bidding
              </TabsTrigger>
              <TabsTrigger value="account" className="glow-tab hover:text-primary hover:bg-primary/10">
                Account
              </TabsTrigger>
            </TabsList>

            {/* Dashboard content */}
            <TabsContent value="dashboard" className="py-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-2xl font-bold mb-4">Welcome to Kings Ark World Trade Center</h2>
                    <p className="mb-4">
                      Your gateway to global trade and investment opportunities. Connect with businesses worldwide,
                      access market insights, and grow your international presence.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <Button onClick={() => setActiveTab("markets")}>Explore Markets</Button>
                      <Button variant="outline" onClick={() => setActiveTab("trade")}>
                        Start Trading
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-xl font-bold mb-4">Quick Stats</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">Active Markets</p>
                        <p className="text-2xl font-bold">142</p>
                      </div>
                      <div className="border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">Trading Volume</p>
                        <p className="text-2xl font-bold">$1.2B</p>
                      </div>
                      <div className="border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">Connected Businesses</p>
                        <p className="text-2xl font-bold">12,450</p>
                      </div>
                      <div className="border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">Countries</p>
                        <p className="text-2xl font-bold">78</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Enhanced Dashboard Content with Live Charts */}
              <DashboardCharts />

              {/* Trade Performance Table */}
              <div className="mt-6">
                <TradePerformanceTable />
              </div>
            </TabsContent>

            {/* Markets content */}
            <TabsContent value="markets" className="py-4">
              <MarketInformation />
            </TabsContent>

            {/* Trade content */}
            <TabsContent value="trade" className="py-4">
              <TradeInformation />
            </TabsContent>

            {/* B2B Social content */}
            <TabsContent value="social" className="py-4">
              <div className="text-center">
                <p className="mb-4">Redirecting to B2B Social Media platform...</p>
                <Button onClick={() => router.push("/social")}>Go to B2B Social Media</Button>
              </div>
            </TabsContent>

            {/* Kings Ark TV content */}
            <TabsContent value="tv" className="py-4">
              <KingsArkTVInformation />
            </TabsContent>

            {/* Bidding content */}
            <TabsContent value="bidding" className="py-4">
              <BiddingInformation />
            </TabsContent>

            {/* Account content */}
            <TabsContent value="account" className="py-4">
              <AccountInformation />
            </TabsContent>
          </Tabs>
        </div>

        {/* Footer */}
        <footer className="border-t mt-auto py-6 bg-background">
          <div className="container flex flex-col md:flex-row justify-between items-center px-4 md:px-6">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <SpinningCrownLogo size={24} />
              <p className="text-sm">© 2025 Kings Ark World Trade Center. All rights reserved.</p>
            </div>
            <div className="flex gap-4">
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Terms
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy
              </a>
              <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </a>
            </div>
          </div>
        </footer>
      </div>

      {/* Right Sidebar - Hidden on mobile */}
      {rightSidebarVisible && <RightSidebar />}

      {/* Modals */}
      {showAccessibility && (
        <AccessibilityPanel isOpen={showAccessibility} onClose={() => setShowAccessibility(false)} />
      )}

      {showTextToSpeech && <TextToSpeech isOpen={showTextToSpeech} onClose={() => setShowTextToSpeech(false)} />}

      {showVoiceSearch && (
        <VoiceSearch isOpen={showVoiceSearch} onClose={() => setShowVoiceSearch(false)} onSearch={handleSearch} />
      )}

      {showAIChat && <AIChat isOpen={showAIChat} onClose={() => setShowAIChat(false)} />}
    </div>
  )
}

