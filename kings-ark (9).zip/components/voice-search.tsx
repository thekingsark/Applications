"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mic, MicOff, Search, X, Volume2 } from "lucide-react"
import type { VoiceSearchProps } from "@/types"

export default function VoiceSearch({ isOpen, onClose, onSearch }: VoiceSearchProps) {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [recognition, setRecognition] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const micRef = useRef<HTMLButtonElement>(null)
  const [selectedLanguage, setSelectedLanguage] = useState("en-US")
  const [continuous, setContinuous] = useState(false)
  const searchInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        // @ts-ignore - SpeechRecognition is not in the TypeScript types yet
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

        if (SpeechRecognition) {
          const recognitionInstance = new SpeechRecognition()
          recognitionInstance.continuous = continuous
          recognitionInstance.interimResults = true
          recognitionInstance.lang = selectedLanguage

          recognitionInstance.onresult = (event: any) => {
            let finalTranscript = ""
            let interimTranscript = ""

            for (let i = event.resultIndex; i < event.results.length; i++) {
              const transcript = event.results[i][0].transcript
              if (event.results[i].isFinal) {
                finalTranscript += transcript
              } else {
                interimTranscript += transcript
              }
            }

            setTranscript(finalTranscript || interimTranscript)
          }

          recognitionInstance.onend = () => {
            setIsListening(false)
          }

          recognitionInstance.onerror = (event: any) => {
            console.error("Speech recognition error", event.error)
            setError(`Error: ${event.error}. Please try again.`)
            setIsListening(false)
          }

          setRecognition(recognitionInstance)
        } else {
          setError("Speech recognition is not supported in your browser.")
        }
      } catch (error) {
        console.error("Error initializing speech recognition:", error)
        setError("Failed to initialize speech recognition. Please try again.")
      }
    }

    return () => {
      if (recognition) {
        try {
          recognition.abort()
        } catch (error) {
          console.error("Error aborting recognition:", error)
        }
      }

      // Clean up any speech synthesis
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel()
      }
    }
  }, [continuous, selectedLanguage])

  // Focus input when modal opens
  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      setTimeout(() => {
        searchInputRef.current?.focus()
      }, 100)
    }
  }, [isOpen])

  const toggleListening = () => {
    if (isListening) {
      try {
        recognition?.stop()
      } catch (error) {
        console.error("Error stopping recognition:", error)
      }
      setIsListening(false)
    } else {
      setTranscript("")
      setError(null)
      try {
        recognition?.start()
        setIsListening(true)
      } catch (error) {
        console.error("Error starting recognition:", error)
        setError("Failed to start speech recognition. Please try again.")
        setIsListening(false)
      }
    }
  }

  // Update the handleSearch function to make it work properly
  const handleSearch = () => {
    if (transcript.trim()) {
      onSearch(transcript)
      // Close the voice search modal after searching
      onClose()
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTranscript(e.target.value)
  }

  // Add a function to handle full text-to-voice capability
  const speakText = (text: string) => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      try {
        const utterance = new SpeechSynthesisUtterance(text)
        utterance.lang = selectedLanguage
        window.speechSynthesis.speak(utterance)
      } catch (error) {
        console.error("Error with text-to-speech:", error)
        setError("Text-to-speech failed. Please try again.")
      }
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-background border border-border rounded-lg shadow-lg w-full max-w-md glow-border">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-bold flex items-center gap-2 glow-text">
            <Search className="h-5 w-5" />
            Voice Search
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="glow-button">
            <X className="h-5 w-5" />
            <span className="sr-only">Close</span>
          </Button>
        </div>

        <div className="p-6 space-y-6">
          <div className="flex items-center gap-2">
            <Input
              ref={searchInputRef}
              value={transcript}
              onChange={handleInputChange}
              placeholder="Say something or type your search..."
              className="flex-1"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
            <Button
              ref={micRef}
              variant={isListening ? "destructive" : "outline"}
              size="icon"
              onClick={toggleListening}
              disabled={!recognition}
              className={`${isListening ? "voice-listening" : ""} glow-button`}
            >
              {isListening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </Button>
          </div>

          {isListening && (
            <div className="mt-2 flex items-center justify-center">
              <div className="flex space-x-1">
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-75"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-150"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-300"></div>
              </div>
              <p className="text-xs text-primary ml-2">Listening to your voice...</p>
            </div>
          )}

          {error && <div className="text-center text-sm text-destructive">{error}</div>}

          <div className="flex justify-between items-center mt-2 mb-4">
            <p className="text-xs text-muted-foreground">Select language:</p>
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="text-xs p-1 rounded border bg-background"
            >
              <option value="en-US">English (US)</option>
              <option value="es-ES">Spanish</option>
              <option value="fr-FR">French</option>
              <option value="de-DE">German</option>
              <option value="zh-CN">Chinese</option>
              <option value="ja-JP">Japanese</option>
              <option value="ru-RU">Russian</option>
              <option value="ar-SA">Arabic</option>
            </select>
          </div>

          <div className="flex items-center gap-2 mt-2">
            <label className="text-xs text-muted-foreground flex items-center gap-2">
              <input
                type="checkbox"
                checked={continuous}
                onChange={(e) => setContinuous(e.target.checked)}
                className="rounded border-muted"
              />
              Continuous recognition
            </label>
            <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => setTranscript("")}>
              Clear
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="h-6 text-xs flex items-center gap-1"
              onClick={() => speakText(transcript)}
            >
              <Volume2 className="h-3 w-3" /> Speak Text
            </Button>
          </div>

          <div className="text-center text-xs text-muted-foreground">
            {recognition
              ? "Click the microphone icon and speak clearly. Your speech will be converted to text."
              : "Speech recognition is not supported in your browser. Please type your search query."}
          </div>
        </div>

        <div className="p-4 border-t flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="glow-button">
            Cancel
          </Button>
          <Button
            onClick={handleSearch}
            disabled={!transcript.trim()}
            className="gap-2 glow-button bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Search className="h-4 w-4" />
            Search
          </Button>
        </div>
      </div>
    </div>
  )
}

