"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, ArrowUp, ArrowDown, MoreHorizontal, Download } from "lucide-react"

export default function TradePerformanceTable() {
  const [searchQuery, setSearchQuery] = useState("")
  const [sortColumn, setSortColumn] = useState("value")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  // Sample trade data
  const tradeData = [
    {
      id: "TR-7829",
      company: "Global Tech Solutions",
      sector: "Technology",
      value: 1250000,
      date: "2025-03-10",
      status: "completed",
      change: 12.5,
    },
    {
      id: "TR-6543",
      company: "EuroFinance Group",
      sector: "Finance",
      value: 980000,
      date: "2025-03-09",
      status: "completed",
      change: 8.2,
    },
    {
      id: "TR-9021",
      company: "MediHealth International",
      sector: "Healthcare",
      value: 750000,
      date: "2025-03-08",
      status: "completed",
      change: 5.7,
    },
    {
      id: "TR-3456",
      company: "PowerGen Renewables",
      sector: "Energy",
      value: 1450000,
      date: "2025-03-07",
      status: "completed",
      change: -3.2,
    },
    {
      id: "TR-2178",
      company: "AgriGlobal Exports",
      sector: "Agriculture",
      value: 520000,
      date: "2025-03-06",
      status: "completed",
      change: 4.8,
    },
    {
      id: "TR-8765",
      company: "BuildTech Manufacturing",
      sector: "Manufacturing",
      value: 890000,
      date: "2025-03-05",
      status: "completed",
      change: -1.5,
    },
    {
      id: "TR-5432",
      company: "OceanFreight Logistics",
      sector: "Transportation",
      value: 680000,
      date: "2025-03-04",
      status: "completed",
      change: 7.3,
    },
    {
      id: "TR-1098",
      company: "DigitalEdge Solutions",
      sector: "Technology",
      value: 1120000,
      date: "2025-03-03",
      status: "completed",
      change: 9.6,
    },
  ]

  // Filter and sort data
  const filteredData = tradeData
    .filter(
      (trade) =>
        searchQuery === "" ||
        trade.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        trade.sector.toLowerCase().includes(searchQuery.toLowerCase()) ||
        trade.id.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    .sort((a, b) => {
      const aValue = a[sortColumn as keyof typeof a]
      const bValue = b[sortColumn as keyof typeof b]

      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue
      }

      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue)
      }

      return 0
    })

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortColumn(column)
      setSortDirection("desc")
    }
  }

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(value)
  }

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(date)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle>Trade Performance</CardTitle>
            <CardDescription>Recent trade activity and performance metrics</CardDescription>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="h-8 gap-1">
              <Download className="h-3.5 w-3.5" />
              Export
            </Button>
            <Button size="sm" className="h-8">
              View All
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row gap-4 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search trades..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" className="gap-2 w-full sm:w-auto">
            <Filter className="h-4 w-4" />
            Filters
          </Button>
        </div>

        <div className="rounded-md border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-muted/50">
                  <th
                    className="px-4 py-3 text-left text-sm font-medium cursor-pointer hover:bg-muted"
                    onClick={() => handleSort("id")}
                  >
                    <div className="flex items-center gap-1">
                      Trade ID
                      {sortColumn === "id" &&
                        (sortDirection === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-left text-sm font-medium cursor-pointer hover:bg-muted"
                    onClick={() => handleSort("company")}
                  >
                    <div className="flex items-center gap-1">
                      Company
                      {sortColumn === "company" &&
                        (sortDirection === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-left text-sm font-medium cursor-pointer hover:bg-muted"
                    onClick={() => handleSort("sector")}
                  >
                    <div className="flex items-center gap-1">
                      Sector
                      {sortColumn === "sector" &&
                        (sortDirection === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-right text-sm font-medium cursor-pointer hover:bg-muted"
                    onClick={() => handleSort("value")}
                  >
                    <div className="flex items-center justify-end gap-1">
                      Value
                      {sortColumn === "value" &&
                        (sortDirection === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-left text-sm font-medium cursor-pointer hover:bg-muted"
                    onClick={() => handleSort("date")}
                  >
                    <div className="flex items-center gap-1">
                      Date
                      {sortColumn === "date" &&
                        (sortDirection === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                    </div>
                  </th>
                  <th
                    className="px-4 py-3 text-right text-sm font-medium cursor-pointer hover:bg-muted"
                    onClick={() => handleSort("change")}
                  >
                    <div className="flex items-center justify-end gap-1">
                      Change
                      {sortColumn === "change" &&
                        (sortDirection === "asc" ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
                    </div>
                  </th>
                  <th className="px-4 py-3 text-center text-sm font-medium">Status</th>
                  <th className="px-4 py-3 text-right text-sm font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredData.map((trade, index) => (
                  <tr key={trade.id} className="border-t hover:bg-muted/50">
                    <td className="px-4 py-3 text-sm font-medium">{trade.id}</td>
                    <td className="px-4 py-3 text-sm">{trade.company}</td>
                    <td className="px-4 py-3 text-sm">
                      <span
                        className="px-2 py-1 rounded-full text-xs font-medium"
                        style={{
                          backgroundColor: `hsl(${(index * 30) % 360}, 70%, 60%, 0.2)`,
                          color: `hsl(${(index * 30) % 360}, 70%, 40%)`,
                        }}
                      >
                        {trade.sector}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-right font-medium">{formatCurrency(trade.value)}</td>
                    <td className="px-4 py-3 text-sm">{formatDate(trade.date)}</td>
                    <td className="px-4 py-3 text-sm text-right">
                      <span className={`font-medium ${trade.change >= 0 ? "text-green-500" : "text-red-500"}`}>
                        {trade.change >= 0 ? "+" : ""}
                        {trade.change}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-center">
                      <Badge
                        variant="outline"
                        className="capitalize"
                        style={{
                          backgroundColor:
                            trade.status === "completed" ? "rgba(16, 185, 129, 0.1)" : "rgba(59, 130, 246, 0.1)",
                          color: trade.status === "completed" ? "rgb(16, 185, 129)" : "rgb(59, 130, 246)",
                          borderColor:
                            trade.status === "completed" ? "rgba(16, 185, 129, 0.2)" : "rgba(59, 130, 246, 0.2)",
                        }}
                      >
                        {trade.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 text-sm text-right">
                      <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-primary/10 hover:text-primary">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex justify-between items-center mt-4 text-sm text-muted-foreground">
          <div>
            Showing {filteredData.length} of {tradeData.length} trades
          </div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="sm" className="h-8 w-8 p-0">
              1
            </Button>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              2
            </Button>
            <span>...</span>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              5
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

