"use client"

import { useState, useEffect } from "react"
import { Check, ChevronDown, Globe } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"
import type { LanguageTranslatorProps } from "@/types"
import { applyTranslations, type SupportedLanguage } from "@/utils/i18n"

const languages = [
  { code: "en", name: "English" },
  { code: "es", name: "Español" },
  { code: "fr", name: "Français" },
  { code: "de", name: "Deutsch" },
  { code: "it", name: "Italiano" },
  { code: "pt", name: "Português" },
  { code: "ru", name: "Русский" },
  { code: "zh", name: "中文" },
  { code: "ja", name: "日本語" },
  { code: "ko", name: "한국어" },
  { code: "ar", name: "العربية" },
  { code: "hi", name: "हिन्दी" },
]

// Add a function to translate text using the browser's language API
const translateText = (text: string, targetLanguage: string) => {
  // In a real application, this would use a translation API
  // For demonstration purposes, we'll simulate translation
  console.log(`Translating text to ${targetLanguage}: ${text}`)

  // Apply translations from our translation service
  applyTranslations(targetLanguage as SupportedLanguage)

  // Return a simulated translated text
  return `[Translated to ${targetLanguage}] ${text}`
}

// Add a function to translate the current page
const translatePage = (language: string) => {
  // Get all text elements on the page
  const textElements = document.querySelectorAll("p, h1, h2, h3, h4, h5, h6, span, button, a")

  // Apply translations from our translation service
  applyTranslations(language as SupportedLanguage)

  console.log(`Translating page to ${language}`)
}

export default function LanguageTranslator({ onLanguageChange }: LanguageTranslatorProps) {
  const [selectedLanguage, setSelectedLanguage] = useState(languages[0])

  // Update the handleLanguageSelect function to translate the page
  const handleLanguageSelect = (language: (typeof languages)[0]) => {
    setSelectedLanguage(language)
    onLanguageChange(language.code)
    translatePage(language.code)

    // Store language preference
    if (typeof window !== "undefined") {
      localStorage.setItem("preferredLanguage", language.code)
    }
  }

  // Initialize with stored language preference
  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedLanguage = localStorage.getItem("preferredLanguage")
      if (storedLanguage) {
        const language = languages.find((lang) => lang.code === storedLanguage)
        if (language) {
          setSelectedLanguage(language)
          onLanguageChange(language.code)
        }
      }
    }
  }, [onLanguageChange])

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {/* Make the dropdown button more visible with glowing effects */}
        <Button
          variant="outline"
          size="sm"
          className="gap-1 glow-button bg-primary/10 text-primary hover:bg-primary/20"
        >
          <Globe className="h-4 w-4" />
          {selectedLanguage.name}
          <ChevronDown className="h-3 w-3 opacity-50" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[200px] max-h-[300px] overflow-y-auto">
        {languages.map((language) => (
          <DropdownMenuItem
            key={language.code}
            className="flex items-center justify-between"
            onClick={() => handleLanguageSelect(language)}
          >
            {language.name}
            {selectedLanguage.code === language.code && <Check className="h-4 w-4" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

