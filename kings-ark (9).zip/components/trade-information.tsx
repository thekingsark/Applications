"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, TrendingUp, TrendingDown, BarChart2, Globe, ExternalLink } from "lucide-react"
import Image from "next/image"
import { mediaAssets } from "@/components/media-assets"

export default function TradeInformation() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("markets")

  const markets = [
    {
      id: "m1",
      name: "Technology",
      trend: "up",
      change: "+2.4%",
      volume: "$1.2B",
      status: "open",
      description: "Technology sector including software, hardware, and IT services.",
    },
    {
      id: "m2",
      name: "Finance",
      trend: "down",
      change: "-0.8%",
      volume: "$950M",
      status: "open",
      description: "Financial services including banking, insurance, and investment.",
    },
    {
      id: "m3",
      name: "Healthcare",
      trend: "up",
      change: "+1.7%",
      volume: "$780M",
      status: "open",
      description: "Healthcare products, pharmaceuticals, and medical devices.",
    },
    {
      id: "m4",
      name: "Energy",
      trend: "up",
      change: "+3.2%",
      volume: "$1.5B",
      status: "open",
      description: "Energy production, distribution, and renewable resources.",
    },
    {
      id: "m5",
      name: "Manufacturing",
      trend: "down",
      change: "-0.3%",
      volume: "$620M",
      status: "open",
      description: "Manufacturing of goods across various industries.",
    },
    {
      id: "m6",
      name: "Agriculture",
      trend: "up",
      change: "+0.9%",
      volume: "$450M",
      status: "open",
      description: "Agricultural products, farming, and food production.",
    },
  ]

  const filteredMarkets = markets.filter((market) => {
    if (
      searchQuery &&
      !market.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !market.description.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }
    return true
  })

  const tradeOpportunities = [
    {
      id: "t1",
      title: "Technology Equipment Export",
      region: "Asia Pacific",
      value: "$2.5M",
      deadline: "April 15, 2025",
      status: "active",
      description: "Opportunity to export technology equipment to growing markets in Asia.",
    },
    {
      id: "t2",
      title: "Agricultural Products Import",
      region: "South America",
      value: "$1.8M",
      deadline: "May 10, 2025",
      status: "active",
      description: "Import high-quality agricultural products from South American producers.",
    },
    {
      id: "t3",
      title: "Medical Supplies Distribution",
      region: "Europe",
      value: "$3.2M",
      deadline: "June 22, 2025",
      status: "active",
      description: "Distribution partnership for medical supplies across European markets.",
    },
    {
      id: "t4",
      title: "Renewable Energy Investment",
      region: "Africa",
      value: "$5.0M",
      deadline: "July 30, 2025",
      status: "active",
      description: "Investment opportunity in renewable energy projects in African countries.",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Trade Platform</h1>
          <p className="text-muted-foreground">Connect and trade with global partners</p>
        </div>
        <Button>New Trade</Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search markets and opportunities..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      <Tabs defaultValue="markets" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="markets">Markets</TabsTrigger>
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
        </TabsList>

        <TabsContent value="markets" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredMarkets.map((market) => (
              <Card key={market.id} className="h-full flex flex-col">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{market.name}</CardTitle>
                    <div className={`flex items-center ${market.trend === "up" ? "text-green-500" : "text-red-500"}`}>
                      {market.trend === "up" ? (
                        <TrendingUp className="h-4 w-4 mr-1" />
                      ) : (
                        <TrendingDown className="h-4 w-4 mr-1" />
                      )}
                      <span>{market.change}</span>
                    </div>
                  </div>
                  <CardDescription>{market.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 pb-2">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-muted-foreground">Trading Volume</p>
                      <p className="font-medium">{market.volume}</p>
                    </div>
                    <Badge variant="outline" className="capitalize">
                      {market.status}
                    </Badge>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">View Market</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="opportunities" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tradeOpportunities.map((opportunity) => (
              <Card key={opportunity.id} className="h-full flex flex-col">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{opportunity.title}</CardTitle>
                    <Badge>{opportunity.status}</Badge>
                  </div>
                  <CardDescription>{opportunity.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Region:</span>
                      <span className="text-sm font-medium">{opportunity.region}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Value:</span>
                      <span className="text-sm font-medium">{opportunity.value}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Deadline:</span>
                      <span className="text-sm font-medium">{opportunity.deadline}</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Express Interest</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Global Trade Insights</CardTitle>
          <CardDescription>Latest trends and market analysis</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative w-full h-[200px] sm:h-[300px] rounded-lg overflow-hidden">
            <Image
              src={mediaAssets.business.trading || "/placeholder.svg?height=300&width=500"}
              alt="Global Trade Insights"
              fill
              className="object-cover"
            />
          </div>

          <h3 className="text-lg font-semibold">Current Market Trends</h3>
          <p>
            Global trade is experiencing significant growth in technology and renewable energy sectors, with emerging
            markets in Asia and Africa showing strong potential. Supply chain diversification remains a key focus for
            businesses worldwide, with increased investment in regional manufacturing hubs.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <BarChart2 className="h-5 w-5 text-primary" />
                <h4 className="font-medium">Top Performing Sectors</h4>
              </div>
              <ul className="space-y-1 text-sm">
                <li className="flex justify-between">
                  <span>Technology</span>
                  <span className="text-green-500">+12.4%</span>
                </li>
                <li className="flex justify-between">
                  <span>Renewable Energy</span>
                  <span className="text-green-500">+8.7%</span>
                </li>
                <li className="flex justify-between">
                  <span>Healthcare</span>
                  <span className="text-green-500">+6.2%</span>
                </li>
              </ul>
            </div>

            <div className="border rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Globe className="h-5 w-5 text-primary" />
                <h4 className="font-medium">Emerging Markets</h4>
              </div>
              <ul className="space-y-1 text-sm">
                <li className="flex justify-between">
                  <span>Southeast Asia</span>
                  <span className="text-green-500">High Growth</span>
                </li>
                <li className="flex justify-between">
                  <span>East Africa</span>
                  <span className="text-green-500">Emerging</span>
                </li>
                <li className="flex justify-between">
                  <span>Latin America</span>
                  <span className="text-green-500">Stable</span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.open("https://kingsglobalfunding.world", "_blank")}
          >
            View Detailed Market Reports
            <ExternalLink className="h-4 w-4 ml-2" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

