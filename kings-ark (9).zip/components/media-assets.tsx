// This file contains media assets for the application
export const mediaAssets = {
  // Globe images
  globe: {
    main: "/placeholder.svg?height=300&width=300",
    rotating: "/placeholder.svg?height=300&width=300",
    dots: "/placeholder.svg?height=300&width=300",
    connections: "/placeholder.svg?height=300&width=300",
  },

  // Background effects
  backgrounds: {
    smoke: "/placeholder.svg?height=1080&width=1920",
    particles: "/placeholder.svg?height=1080&width=1920",
    worldMap: "/placeholder.svg?height=1080&width=1920",
  },

  // Business images
  business: {
    meeting: "/placeholder.svg?height=600&width=800",
    handshake: "/placeholder.svg?height=600&width=800",
    office: "/placeholder.svg?height=600&width=800",
    trading: "/placeholder.svg?height=600&width=800",
    technology: "/placeholder.svg?height=600&width=800",
    agriculture: "/placeholder.svg?height=600&width=800",
    manufacturing: "/placeholder.svg?height=600&width=800",
    logistics: "/placeholder.svg?height=600&width=800",
  },

  // Company logos
  logos: {
    kingsArk: "/placeholder.svg?height=80&width=200&text=Kings+Ark",
    globalTrade: "/placeholder.svg?height=80&width=200&text=Global+Trade",
    euroTrade: "/placeholder.svg?height=80&width=200&text=Euro+Trade",
    asiaPacific: "/placeholder.svg?height=80&width=200&text=Asia+Pacific",
    africanTrade: "/placeholder.svg?height=80&width=200&text=African+Trade",
    southAmerican: "/placeholder.svg?height=80&width=200&text=South+American",
    oceaniaBusiness: "/placeholder.svg?height=80&width=200&text=Oceania+Business",
  },

  // Videos
  videos: {
    businessPresentation: "/placeholder.svg?height=300&width=500",
    marketAnalysis: "/placeholder.svg?height=300&width=500",
    tradeExplainer: "/placeholder.svg?height=300&width=500",
    b2bNetworking: "/placeholder.svg?height=300&width=500",
  },

  // Maps
  maps: {
    worldMap: "/placeholder.svg?height=600&width=1200",
    interactiveMap: "/placeholder.svg?height=600&width=1200",
  },
}

