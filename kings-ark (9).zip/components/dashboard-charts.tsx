"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Update the color palette for charts
const CHART_COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--destructive))",
  "hsl(var(--warning) / 0.8)",
  "hsl(var(--success) / 0.8)",
  "#8884d8",
  "#82ca9d",
  "#ffc658",
  "#ff8042",
]

export default function DashboardCharts() {
  return (
    <div className="mt-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Market Activity Overview</CardTitle>
          <CardDescription>Real-time market performance and trends</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="volume">
            <TabsList className="mb-4">
              <TabsTrigger value="volume">Trading Volume</TabsTrigger>
              <TabsTrigger value="markets">Active Markets</TabsTrigger>
              <TabsTrigger value="businesses">Connected Businesses</TabsTrigger>
              <TabsTrigger value="countries">Global Reach</TabsTrigger>
            </TabsList>

            <TabsContent value="volume" className="h-[350px]">
              <div className="h-full flex flex-col">
                <div className="flex-1 relative">
                  {/* Trading Volume Line Chart */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-full bg-muted/20 rounded-md overflow-hidden">
                      {/* Simulated Line Chart */}
                      <div className="w-full h-full relative">
                        <div className="absolute bottom-0 left-0 w-full h-[60%] bg-gradient-to-t from-primary/10 to-transparent"></div>
                        <svg viewBox="0 0 100 30" className="w-full h-full" preserveAspectRatio="none">
                          <path
                            d="M0,25 L5,22 L10,26 L15,20 L20,22 L25,18 L30,16 L35,14 L40,16 L45,13 L50,15 L55,10 L60,12 L65,8 L70,10 L75,6 L80,8 L85,4 L90,6 L95,2 L100,5"
                            fill="none"
                            stroke="hsl(var(--primary))"
                            strokeWidth="1"
                            vectorEffect="non-scaling-stroke"
                          />
                          <path
                            d="M0,25 L5,22 L10,26 L15,20 L20,22 L25,18 L30,16 L35,14 L40,16 L45,13 L50,15 L55,10 L60,12 L65,8 L70,10 L75,6 L80,8 L85,4 L90,6 L95,2 L100,5 V30 H0 Z"
                            fill="url(#gradient)"
                            opacity="0.7"
                          />
                          <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                              <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.5" />
                              <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0.1" />
                            </linearGradient>
                          </defs>
                        </svg>

                        {/* Animated Dot for "Live" Effect */}
                        <div className="absolute right-0 top-[5%] h-3 w-3">
                          <div className="absolute h-3 w-3 rounded-full bg-primary"></div>
                          <div className="absolute h-3 w-3 rounded-full bg-primary animate-ping opacity-75"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-2 grid grid-cols-4 gap-4 text-center">
                  <div>
                    <p className="text-sm font-medium">Daily Volume</p>
                    <p className="text-2xl font-bold">$42.8M</p>
                    <p className="text-xs text-green-500">+5.2%</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Weekly</p>
                    <p className="text-2xl font-bold">$298M</p>
                    <p className="text-xs text-green-500">+3.7%</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Monthly</p>
                    <p className="text-2xl font-bold">$1.2B</p>
                    <p className="text-xs text-green-500">+12.4%</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">YTD</p>
                    <p className="text-2xl font-bold">$8.7B</p>
                    <p className="text-xs text-green-500">+18.9%</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="markets" className="h-[350px]">
              <div className="h-full flex flex-col">
                <div className="flex-1 relative">
                  {/* Active Markets Bar Chart */}
                  <div className="absolute inset-0 flex items-end justify-between p-4">
                    {["Tech", "Finance", "Energy", "Health", "Mfg", "Agri", "Retail"].map((market, i) => {
                      const heights = [75, 60, 85, 50, 65, 40, 55]
                      return (
                        <div key={market} className="flex flex-col items-center gap-2 w-[10%]">
                          <div
                            className="w-full rounded-t-md transition-all duration-500 hover:bg-primary"
                            style={{
                              height: `${heights[i]}%`,
                              background: `linear-gradient(to top, ${CHART_COLORS[i % CHART_COLORS.length]}, ${CHART_COLORS[(i + 2) % CHART_COLORS.length]})`,
                            }}
                          ></div>
                          <span className="text-xs font-medium">{market}</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
                <div className="mt-2 grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-sm font-medium">Total Markets</p>
                    <p className="text-2xl font-bold">142</p>
                    <p className="text-xs text-green-500">+3 this month</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Most Active</p>
                    <p className="text-2xl font-bold">Technology</p>
                    <p className="text-xs text-green-500">+12.4% growth</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Emerging</p>
                    <p className="text-2xl font-bold">Green Energy</p>
                    <p className="text-xs text-green-500">+28.7% growth</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="businesses" className="h-[350px]">
              <div className="h-full flex flex-col">
                <div className="flex-1 relative">
                  {/* Connected Businesses Area Chart */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-full h-full bg-muted/20 rounded-md overflow-hidden">
                      {/* Simulated Area Chart */}
                      <div className="w-full h-full relative">
                        <svg viewBox="0 0 100 30" className="w-full h-full" preserveAspectRatio="none">
                          <path
                            d="M0,30 L0,20 C10,18 15,22 20,20 C25,18 30,15 40,16 C50,17 55,14 60,12 C65,10 70,8 80,10 C90,12 95,8 100,5 L100,30 Z"
                            fill="hsl(var(--primary))"
                            opacity="0.2"
                          />
                          <path
                            d="M0,20 C10,18 15,22 20,20 C25,18 30,15 40,16 C50,17 55,14 60,12 C65,10 70,8 80,10 C90,12 95,8 100,5"
                            fill="none"
                            stroke="hsl(var(--primary))"
                            strokeWidth="0.5"
                            vectorEffect="non-scaling-stroke"
                          />
                        </svg>

                        {/* Data Points */}
                        {[20, 22, 15, 17, 14, 8, 10, 5].map((pos, i) => (
                          <div
                            key={i}
                            className="absolute h-2 w-2 rounded-full bg-primary"
                            style={{
                              bottom: `${30 - pos}%`,
                              left: `${i * 12.5}%`,
                            }}
                          ></div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-2 grid grid-cols-4 gap-4 text-center">
                  <div>
                    <p className="text-sm font-medium">Total</p>
                    <p className="text-2xl font-bold">12,450</p>
                    <p className="text-xs text-green-500">+124 this week</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Enterprise</p>
                    <p className="text-2xl font-bold">1,280</p>
                    <p className="text-xs text-green-500">+15 this week</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">SMB</p>
                    <p className="text-2xl font-bold">8,340</p>
                    <p className="text-xs text-green-500">+92 this week</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Startups</p>
                    <p className="text-2xl font-bold">2,830</p>
                    <p className="text-xs text-green-500">+17 this week</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="countries" className="h-[350px]">
              <div className="h-full flex flex-col">
                <div className="flex-1 relative">
                  {/* Global Reach Pie Chart */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-[250px] h-[250px]">
                      {/* Simulated Pie Chart */}
                      <svg viewBox="0 0 100 100" className="w-full h-full">
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={CHART_COLORS[0]}
                          strokeWidth="20"
                          strokeDasharray="75 25"
                          strokeDashoffset="0"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={CHART_COLORS[1]}
                          strokeWidth="20"
                          strokeDasharray="50 50"
                          strokeDashoffset="-25"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={CHART_COLORS[2]}
                          strokeWidth="20"
                          strokeDasharray="35 65"
                          strokeDashoffset="-75"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={CHART_COLORS[3]}
                          strokeWidth="20"
                          strokeDasharray="25 75"
                          strokeDashoffset="-110"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={CHART_COLORS[4]}
                          strokeWidth="20"
                          strokeDasharray="15 85"
                          strokeDashoffset="-135"
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="text-center">
                          <p className="text-3xl font-bold">78</p>
                          <p className="text-sm">Countries</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-2 grid grid-cols-5 gap-4 text-center">
                  <div>
                    <p className="text-sm font-medium">North America</p>
                    <p className="text-xl font-bold">25%</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Europe</p>
                    <p className="text-xl font-bold">30%</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Asia</p>
                    <p className="text-xl font-bold">20%</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Africa</p>
                    <p className="text-xl font-bold">15%</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium">Other</p>
                    <p className="text-xl font-bold">10%</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Market Growth Trends</CardTitle>
            <CardDescription>Year-over-year growth by sector</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <div className="h-full relative">
              {/* Horizontal Bar Chart */}
              <div className="absolute inset-0 flex flex-col justify-around p-4">
                {[
                  { name: "Technology", value: 28, color: "bg-blue-500" },
                  { name: "Finance", value: 22, color: "bg-green-500" },
                  { name: "Healthcare", value: 18, color: "bg-purple-500" },
                  { name: "Energy", value: 15, color: "bg-yellow-500" },
                  { name: "Manufacturing", value: 12, color: "bg-red-500" },
                  { name: "Agriculture", value: 5, color: "bg-emerald-500" },
                ].map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <span className="text-sm w-28">{item.name}</span>
                    <div className="flex-1 h-6 bg-muted/30 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${item.color} rounded-full transition-all duration-1000`}
                        style={{ width: `${item.value * 2}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium w-12 text-right">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Regional Activity</CardTitle>
            <CardDescription>Real-time trading activity by region</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <div className="h-full relative">
              {/* Heatmap/Grid */}
              <div className="absolute inset-0 grid grid-cols-4 grid-rows-3 gap-2 p-4">
                {[
                  { region: "North America", activity: 85 },
                  { region: "Europe", activity: 75 },
                  { region: "Asia Pacific", activity: 80 },
                  { region: "Middle East", activity: 60 },
                  { region: "South America", activity: 50 },
                  { region: "Africa", activity: 40 },
                  { region: "Oceania", activity: 30 },
                  { region: "Caribbean", activity: 25 },
                  { region: "Central Asia", activity: 20 },
                  { region: "Eastern Europe", activity: 45 },
                  { region: "Southeast Asia", activity: 55 },
                  { region: "Nordic", activity: 35 },
                ].map((item, i) => (
                  <div
                    key={item.region}
                    className="rounded-md flex flex-col items-center justify-center p-2 text-center transition-colors duration-500"
                    style={{
                      backgroundColor: `hsl(var(--primary) / ${item.activity / 100})`,
                      color: item.activity > 60 ? "white" : undefined,
                    }}
                  >
                    <p className="text-xs font-medium">{item.region}</p>
                    <p className="text-lg font-bold">{item.activity}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

