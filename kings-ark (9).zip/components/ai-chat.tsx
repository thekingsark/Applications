"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { X, Send, Mic, MicOff, Volume2, VolumeX, Maximize2, Minimize2 } from "lucide-react"
import type { Message } from "@/types"

interface AIChatProps {
  isOpen: boolean
  onClose: () => void
}

export default function AIChat({ isOpen, onClose }: AIChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello! I'm your Kings Ark AI assistant. How can I help you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (input.trim() === "") return

    try {
      // Add user message
      const userMessage: Message = {
        role: "user",
        content: input,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, userMessage])
      setInput("")
      setIsLoading(true)

      // Simulate AI response after a delay
      setTimeout(() => {
        try {
          const aiResponse: Message = {
            role: "assistant",
            content: getAIResponse(input),
            timestamp: new Date(),
          }
          setMessages((prev) => [...prev, aiResponse])
        } catch (error) {
          console.error("Error generating AI response:", error)
          const errorResponse: Message = {
            role: "assistant",
            content: "I'm sorry, I encountered an error processing your request. Please try again.",
            timestamp: new Date(),
          }
          setMessages((prev) => [...prev, errorResponse])
        } finally {
          setIsLoading(false)
        }
      }, 1500)
    } catch (error) {
      console.error("Error in message handling:", error)
      setIsLoading(false)
    }
  }

  const getAIResponse = (query: string): string => {
    // Simple response logic - in a real app, this would call an AI API
    const lowerQuery = query.toLowerCase()

    if (lowerQuery.includes("hello") || lowerQuery.includes("hi")) {
      return "Hello! How can I assist you with Kings Ark services today?"
    } else if (lowerQuery.includes("market") || lowerQuery.includes("trade")) {
      return "Our market data shows strong growth in technology and renewable energy sectors. Would you like specific information about any market?"
    } else if (lowerQuery.includes("account") || lowerQuery.includes("login")) {
      return "You can manage your account settings through the Account tab. Need help with anything specific?"
    } else if (lowerQuery.includes("contact") || lowerQuery.includes("support")) {
      return "You can reach our support team at support@kingsark.com or through the Help Center in the right sidebar."
    } else {
      return "I understand you're interested in this topic. Our team is continuously updating our knowledge base. Can you provide more details about what you're looking for?"
    }
  }

  const toggleRecording = () => {
    try {
      setIsRecording(!isRecording)
      // In a real app, this would start/stop speech recognition

      // Simulate recording functionality
      if (!isRecording) {
        // Starting recording
        console.log("Voice recording started")
        // After 3 seconds, simulate stopping and processing
        setTimeout(() => {
          if (isRecording) {
            setIsRecording(false)
            setInput((prev) => prev + " [Voice input: How can I get help with trading?]")
          }
        }, 3000)
      } else {
        // Stopping recording
        console.log("Voice recording stopped")
      }
    } catch (error) {
      console.error("Error toggling recording:", error)
      setIsRecording(false)
    }
  }

  const toggleSpeaking = () => {
    try {
      setIsSpeaking(!isSpeaking)

      // Implement basic text-to-speech functionality
      if (!isSpeaking && typeof window !== "undefined" && "speechSynthesis" in window) {
        // Get the last assistant message
        const lastAssistantMessage = [...messages].reverse().find((msg) => msg.role === "assistant")

        if (lastAssistantMessage) {
          const utterance = new SpeechSynthesisUtterance(lastAssistantMessage.content)
          utterance.onend = () => setIsSpeaking(false)
          utterance.onerror = () => setIsSpeaking(false)
          window.speechSynthesis.speak(utterance)
        } else {
          setIsSpeaking(false)
        }
      } else if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel()
      }
    } catch (error) {
      console.error("Error toggling speaking:", error)
      setIsSpeaking(false)
    }
  }

  const toggleExpand = () => {
    setIsExpanded(!isExpanded)
  }

  if (!isOpen) return null

  return (
    <div
      className={`fixed bottom-4 right-4 z-50 bg-background border rounded-lg shadow-lg flex flex-col ${
        isExpanded ? "w-[80vw] h-[80vh] max-w-4xl" : "w-[350px] h-[500px]"
      } transition-all duration-300`}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b">
        <div className="flex items-center">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <h3 className="ml-2 font-medium">Kings Ark AI Assistant</h3>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" onClick={toggleExpand} className="h-8 w-8">
            {isExpanded ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message, index) => (
          <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
              }`}
            >
              <p className="text-sm">{message.content}</p>
              <p className="text-xs opacity-70 mt-1">
                {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="max-w-[80%] rounded-lg p-3 bg-muted">
              <div className="flex space-x-2">
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-75"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-150"></div>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-3 border-t">
        <div className="flex items-center gap-2">
          <Button
            variant={isRecording ? "destructive" : "outline"}
            size="icon"
            onClick={toggleRecording}
            className="h-9 w-9 flex-shrink-0"
          >
            {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
          <Button
            variant={isSpeaking ? "default" : "outline"}
            size="icon"
            onClick={toggleSpeaking}
            className="h-9 w-9 flex-shrink-0"
          >
            {isSpeaking ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </Button>
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1"
            onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
          />
          <Button
            onClick={handleSendMessage}
            size="icon"
            className="h-9 w-9 flex-shrink-0 glow-button"
            disabled={input.trim() === ""}
          >
            <Send className="h-4 w-4" />
          </Button>
          <Button onClick={onClose} size="icon" variant="destructive" className="h-9 w-9 flex-shrink-0 ml-1">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

