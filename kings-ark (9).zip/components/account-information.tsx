"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { User, Settings, Bell, Shield, CreditCard, Building, Users, FileText, Sun, Moon } from "lucide-react"

export default function AccountInformation() {
  const [activeTab, setActiveTab] = useState("profile")

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Account Management</h1>
          <p className="text-muted-foreground">Manage your profile and preferences</p>
        </div>
        <Button>Save Changes</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-6">
        {/* Sidebar */}
        <div className="space-y-4">
          <Card>
            <CardContent className="p-4 flex flex-col items-center text-center">
              <Avatar className="h-20 w-20 mb-4">
                <AvatarImage src="/placeholder.svg?height=80&width=80" alt="User" />
                <AvatarFallback>KA</AvatarFallback>
              </Avatar>
              <h3 className="font-medium">Guest User</h3>
              <p className="text-sm text-muted-foreground">guest@kingsark.com</p>
              <Badge className="mt-2">Free Account</Badge>
              <Button variant="outline" size="sm" className="mt-4 w-full">
                Upgrade to Premium
              </Button>
            </CardContent>
          </Card>

          <div className="hidden md:block">
            <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab} orientation="vertical">
              <TabsList className="flex flex-col h-auto">
                <TabsTrigger value="profile" className="justify-start">
                  <User className="h-4 w-4 mr-2" />
                  Profile
                </TabsTrigger>
                <TabsTrigger value="company" className="justify-start">
                  <Building className="h-4 w-4 mr-2" />
                  Company
                </TabsTrigger>
                <TabsTrigger value="team" className="justify-start">
                  <Users className="h-4 w-4 mr-2" />
                  Team Members
                </TabsTrigger>
                <TabsTrigger value="billing" className="justify-start">
                  <CreditCard className="h-4 w-4 mr-2" />
                  Billing
                </TabsTrigger>
                <TabsTrigger value="notifications" className="justify-start">
                  <Bell className="h-4 w-4 mr-2" />
                  Notifications
                </TabsTrigger>
                <TabsTrigger value="security" className="justify-start">
                  <Shield className="h-4 w-4 mr-2" />
                  Security
                </TabsTrigger>
                <TabsTrigger value="documents" className="justify-start">
                  <FileText className="h-4 w-4 mr-2" />
                  Documents
                </TabsTrigger>
                <TabsTrigger value="preferences" className="justify-start">
                  <Settings className="h-4 w-4 mr-2" />
                  Preferences
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="md:hidden">
            <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-4 gap-2">
                <TabsTrigger value="profile">
                  <User className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="company">
                  <Building className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="team">
                  <Users className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="billing">
                  <CreditCard className="h-4 w-4" />
                </TabsTrigger>
              </TabsList>
              <TabsList className="grid grid-cols-4 gap-2 mt-2">
                <TabsTrigger value="notifications">
                  <Bell className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="security">
                  <Shield className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="documents">
                  <FileText className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="preferences">
                  <Settings className="h-4 w-4" />
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Main content */}
        <div>
          <Tabs value={activeTab}>
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>Update your personal details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="first-name">First Name</Label>
                      <Input id="first-name" placeholder="Enter your first name" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name">Last Name</Label>
                      <Input id="last-name" placeholder="Enter your last name" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" value="guest@kingsark.com" disabled />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" placeholder="Enter your phone number" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <textarea
                      id="bio"
                      className="w-full min-h-[100px] p-2 border rounded-md bg-background"
                      placeholder="Tell us about yourself"
                    ></textarea>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button>Save Changes</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="company">
              <Card>
                <CardHeader>
                  <CardTitle>Company Information</CardTitle>
                  <CardDescription>Update your company details</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="company-name">Company Name</Label>
                    <Input id="company-name" placeholder="Enter your company name" />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="industry">Industry</Label>
                      <Input id="industry" placeholder="Select industry" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="company-size">Company Size</Label>
                      <Input id="company-size" placeholder="Number of employees" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company-website">Website</Label>
                    <Input id="company-website" placeholder="https://example.com" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company-description">Company Description</Label>
                    <textarea
                      id="company-description"
                      className="w-full min-h-[100px] p-2 border rounded-md bg-background"
                      placeholder="Describe your company"
                    ></textarea>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button>Save Changes</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="team">
              <Card>
                <CardHeader>
                  <CardTitle>Team Members</CardTitle>
                  <CardDescription>Manage your team members and their access</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-end">
                      <Button size="sm">Add Team Member</Button>
                    </div>
                    <div className="border rounded-md">
                      <div className="grid grid-cols-12 gap-2 p-4 border-b font-medium text-sm">
                        <div className="col-span-4">Name</div>
                        <div className="col-span-4">Email</div>
                        <div className="col-span-2">Role</div>
                        <div className="col-span-2">Status</div>
                      </div>
                      <div className="p-2 text-center text-muted-foreground">No team members added yet</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="billing">
              <Card>
                <CardHeader>
                  <CardTitle>Billing Information</CardTitle>
                  <CardDescription>Manage your billing details and subscription</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Current Plan</h3>
                    <div className="bg-muted p-4 rounded-md">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">Free Plan</p>
                          <p className="text-sm text-muted-foreground">Basic access to Kings Ark services</p>
                        </div>
                        <Badge>Active</Badge>
                      </div>
                      <div className="mt-4">
                        <Button>Upgrade to Premium</Button>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Payment Methods</h3>
                    <div className="bg-muted p-4 rounded-md text-center">
                      <p className="text-muted-foreground">No payment methods added yet</p>
                      <Button variant="outline" className="mt-2">
                        Add Payment Method
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium mb-2">Billing History</h3>
                    <div className="bg-muted p-4 rounded-md text-center">
                      <p className="text-muted-foreground">No billing history available</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                  <CardDescription>Manage how you receive notifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Email Notifications</h3>
                    <div className="space-y-2">
                      {[
                        "Market updates and news",
                        "Trade opportunities",
                        "Bidding alerts",
                        "Account activity",
                        "Security alerts",
                        "Newsletter and promotions",
                      ].map((item, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <Label htmlFor={`email-${index}`} className="flex-1">
                            {item}
                          </Label>
                          <Switch id={`email-${index}`} defaultChecked={index < 3} />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4 pt-4 border-t">
                    <h3 className="text-lg font-medium">In-App Notifications</h3>
                    <div className="space-y-2">
                      {[
                        "Market updates and news",
                        "Trade opportunities",
                        "Bidding alerts",
                        "Account activity",
                        "Security alerts",
                        "Newsletter and promotions",
                      ].map((item, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <Label htmlFor={`app-${index}`} className="flex-1">
                            {item}
                          </Label>
                          <Switch id={`app-${index}`} defaultChecked={index !== 5} />
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button>Save Preferences</Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="security">
              <Card>
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>Manage your account security</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Change Password</h3>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="current-password">Current Password</Label>
                        <Input id="current-password" type="password" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="new-password">New Password</Label>
                        <Input id="new-password" type="password" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirm-password">Confirm New Password</Label>
                        <Input id="confirm-password" type="password" />
                      </div>
                      <Button>Update Password</Button>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <h3 className="text-lg font-medium mb-2">Two-Factor Authentication</h3>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Protect your account with 2FA</p>
                        <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                      </div>
                      <Switch id="2fa" />
                    </div>
                    <Button variant="outline" className="mt-4">
                      Set Up 2FA
                    </Button>
                  </div>

                  <div className="pt-4 border-t">
                    <h3 className="text-lg font-medium mb-2">Login Sessions</h3>
                    <div className="space-y-2">
                      <div className="bg-muted p-4 rounded-md flex justify-between items-center">
                        <div>
                          <p className="font-medium">Current Session</p>
                          <p className="text-sm text-muted-foreground">Web Browser - Last active now</p>
                        </div>
                        <Badge className="bg-green-500">Active</Badge>
                      </div>
                    </div>
                    <Button variant="outline" className="mt-4">
                      Log Out All Devices
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="documents">
              <Card>
                <CardHeader>
                  <CardTitle>Documents</CardTitle>
                  <CardDescription>Manage your documents and files</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-end">
                      <Button size="sm">Upload Document</Button>
                    </div>
                    <div className="border rounded-md">
                      <div className="grid grid-cols-12 gap-2 p-4 border-b font-medium text-sm">
                        <div className="col-span-5">Name</div>
                        <div className="col-span-3">Date</div>
                        <div className="col-span-2">Size</div>
                        <div className="col-span-2">Actions</div>
                      </div>
                      <div className="p-2 text-center text-muted-foreground">No documents uploaded yet</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="preferences">
              <Card>
                <CardHeader>
                  <CardTitle>Preferences</CardTitle>
                  <CardDescription>Customize your experience</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Display Settings</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="theme-preference">Theme Preference</Label>
                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm" className="h-8 gap-1">
                            <Sun className="h-4 w-4" />
                            Light
                          </Button>
                          <Button variant="outline" size="sm" className="h-8 gap-1">
                            <Moon className="h-4 w-4" />
                            Dark
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="compact-view">Compact View</Label>
                        <Switch id="compact-view" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 pt-4 border-t">
                    <h3 className="text-lg font-medium">Regional Settings</h3>
                    <div className="space-y-2">
                      <div className="space-y-2">
                        <Label htmlFor="language">Language</Label>
                        <select id="language" className="w-full p-2 border rounded-md bg-background">
                          <option value="en">English</option>
                          <option value="es">Español</option>
                          <option value="fr">Français</option>
                          <option value="de">Deutsch</option>
                          <option value="zh">中文</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="timezone">Timezone</Label>
                        <select id="timezone" className="w-full p-2 border rounded-md bg-background">
                          <option value="utc">UTC (Coordinated Universal Time)</option>
                          <option value="est">EST (Eastern Standard Time)</option>
                          <option value="cst">CST (Central Standard Time)</option>
                          <option value="pst">PST (Pacific Standard Time)</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="date-format">Date Format</Label>
                        <select id="date-format" className="w-full p-2 border rounded-md bg-background">
                          <option value="mdy">MM/DD/YYYY</option>
                          <option value="dmy">DD/MM/YYYY</option>
                          <option value="ymd">YYYY/MM/DD</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4 pt-4 border-t">
                    <h3 className="text-lg font-medium">Accessibility</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="motion-reduced">Reduced Motion</Label>
                        <Switch id="motion-reduced" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="high-contrast">High Contrast</Label>
                        <Switch id="high-contrast" />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="text-to-speech">Enable Text to Speech</Label>
                        <Switch id="text-to-speech" />
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button>Save Preferences</Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

