"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Eye, Type, MousePointer, Contrast, Sparkles, Zap, X } from "lucide-react"
import type { AccessibilityPanelProps } from "@/types"

export default function AccessibilityPanel({ isOpen, onClose }: AccessibilityPanelProps) {
  const [fontSize, setFontSize] = useState(100)
  const [contrast, setContrast] = useState(false)
  const [reduceMotion, setReduceMotion] = useState(false)
  const [highlightLinks, setHighlightLinks] = useState(false)
  const [bigCursor, setBigCursor] = useState(false)
  const [readableFont, setReadableFont] = useState(false)

  const applySettings = () => {
    document.documentElement.style.fontSize = `${fontSize}%`

    if (contrast) {
      document.documentElement.classList.add("high-contrast")
    } else {
      document.documentElement.classList.remove("high-contrast")
    }

    if (reduceMotion) {
      document.documentElement.classList.add("reduce-motion")
    } else {
      document.documentElement.classList.remove("reduce-motion")
    }

    if (highlightLinks) {
      document.documentElement.classList.add("highlight-links")
    } else {
      document.documentElement.classList.remove("highlight-links")
    }

    if (bigCursor) {
      document.documentElement.classList.add("big-cursor")
    } else {
      document.documentElement.classList.remove("big-cursor")
    }

    if (readableFont) {
      document.documentElement.classList.add("readable-font")
    } else {
      document.documentElement.classList.remove("readable-font")
    }
  }

  // Apply settings whenever they change
  useEffect(() => {
    applySettings()
  }, [fontSize, contrast, reduceMotion, highlightLinks, bigCursor, readableFont])

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-background border border-border rounded-lg shadow-lg w-full max-w-md">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-bold">Accessibility Options</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
            <span className="sr-only">Close</span>
          </Button>
        </div>

        <div className="p-4 space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Type className="h-5 w-5" />
                <Label htmlFor="font-size">Font Size: {fontSize}%</Label>
              </div>
              <Button variant="outline" size="sm" onClick={() => setFontSize(100)}>
                Reset
              </Button>
            </div>
            <Slider
              id="font-size"
              min={75}
              max={200}
              step={5}
              value={[fontSize]}
              onValueChange={(value) => setFontSize(value[0])}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Contrast className="h-5 w-5" />
                <Label htmlFor="contrast">High Contrast</Label>
              </div>
              <Switch id="contrast" checked={contrast} onCheckedChange={setContrast} />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                <Label htmlFor="motion">Reduce Motion</Label>
              </div>
              <Switch id="motion" checked={reduceMotion} onCheckedChange={setReduceMotion} />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                <Label htmlFor="links">Highlight Links</Label>
              </div>
              <Switch id="links" checked={highlightLinks} onCheckedChange={setHighlightLinks} />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MousePointer className="h-5 w-5" />
                <Label htmlFor="cursor">Bigger Cursor</Label>
              </div>
              <Switch id="cursor" checked={bigCursor} onCheckedChange={setBigCursor} />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                <Label htmlFor="font">Readable Font</Label>
              </div>
              <Switch id="font" checked={readableFont} onCheckedChange={setReadableFont} />
            </div>
          </div>
        </div>

        <div className="p-4 border-t flex justify-end">
          <Button onClick={onClose}>Done</Button>
        </div>
      </div>
    </div>
  )
}

