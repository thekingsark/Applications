"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import {
  X,
  Send,
  Paperclip,
  ImageIcon,
  Video,
  Phone,
  VideoOff,
  MicOff,
  Mic,
  Monitor,
  MoreVertical,
  Download,
  File,
  FileText,
  Film,
  Music,
  Clock,
  Check,
  CheckCheck,
  Users,
  Search,
  Plus,
  Smile,
  Camera,
} from "lucide-react"
import Image from "next/image"
import type { Partner } from "@/types"

interface PartnerChatProps {
  isOpen: boolean
  onClose: () => void
  partner?: Partner
  currentUser?: {
    id: string
    name: string
    avatar?: string
    type: "buyer" | "seller" | "both"
  }
}

type MessageType = "text" | "image" | "file" | "video" | "audio"

interface Message {
  id: string
  senderId: string
  receiverId: string
  content: string
  type: MessageType
  timestamp: Date
  status: "sent" | "delivered" | "read"
  metadata?: {
    fileName?: string
    fileSize?: string
    fileType?: string
    duration?: string
    dimensions?: string
  }
}

interface Call {
  id: string
  type: "audio" | "video"
  status: "incoming" | "outgoing" | "ongoing" | "missed" | "ended"
  partnerId: string
  partnerName: string
  partnerAvatar?: string
  startTime?: Date
  endTime?: Date
  duration?: string
}

export default function PartnerChat({ isOpen, onClose, partner, currentUser }: PartnerChatProps) {
  const [activeTab, setActiveTab] = useState("chat")
  const [messages, setMessages] = useState<Message[]>([])
  const [messageInput, setMessageInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const [isVideoCallActive, setIsVideoCallActive] = useState(false)
  const [isAudioCallActive, setIsAudioCallActive] = useState(false)
  const [activeCall, setActiveCall] = useState<Call | null>(null)
  const [isMicMuted, setIsMicMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [isSharingScreen, setIsSharingScreen] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [recentCalls, setRecentCalls] = useState<Call[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Generate a sample conversation when the component mounts or partner changes
  useEffect(() => {
    if (partner && currentUser) {
      const sampleMessages: Message[] = [
        {
          id: "msg1",
          senderId: partner.id,
          receiverId: currentUser.id,
          content: `Hello! I'm ${partner.contactPerson} from ${partner.name}. Thank you for your interest in our products.`,
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
          status: "read",
        },
        {
          id: "msg2",
          senderId: currentUser.id,
          receiverId: partner.id,
          content: `Hi ${partner.contactPerson}, I'm interested in learning more about your ${partner.specialties[0]} offerings.`,
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 5), // 5 minutes after
          status: "read",
        },
        {
          id: "msg3",
          senderId: partner.id,
          receiverId: currentUser.id,
          content: `Great! We specialize in ${partner.specialties.join(", ")}. Would you like me to send you our product catalog?`,
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 10), // 10 minutes after
          status: "read",
        },
        {
          id: "msg4",
          senderId: currentUser.id,
          receiverId: partner.id,
          content: "Yes, please. That would be very helpful.",
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 15), // 15 minutes after
          status: "read",
        },
        {
          id: "msg5",
          senderId: partner.id,
          receiverId: currentUser.id,
          content: "product-catalog.pdf",
          type: "file",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 20), // 20 minutes after
          status: "read",
          metadata: {
            fileName: "product-catalog.pdf",
            fileSize: "2.4 MB",
            fileType: "application/pdf",
          },
        },
        {
          id: "msg6",
          senderId: partner.id,
          receiverId: currentUser.id,
          content: "Here's our latest product catalog. Let me know if you have any questions!",
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 21), // 21 minutes after
          status: "read",
        },
        {
          id: "msg7",
          senderId: currentUser.id,
          receiverId: partner.id,
          content: "Thank you! I'll review this and get back to you with any questions.",
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 30), // 30 minutes after
          status: "read",
        },
        {
          id: "msg8",
          senderId: currentUser.id,
          receiverId: partner.id,
          content:
            "I've reviewed the catalog and I'm particularly interested in your sustainable options. Do you have any samples available?",
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), // 3 hours ago
          status: "read",
        },
        {
          id: "msg9",
          senderId: partner.id,
          receiverId: currentUser.id,
          content: "product-sample.jpg",
          type: "image",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
          status: "read",
          metadata: {
            fileName: "product-sample.jpg",
            fileSize: "1.2 MB",
            fileType: "image/jpeg",
            dimensions: "1200x800",
          },
        },
        {
          id: "msg10",
          senderId: partner.id,
          receiverId: currentUser.id,
          content:
            "Yes, we do! Here's an image of our sustainable product line. We can arrange to send you physical samples as well.",
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2 + 1000 * 60), // 2 hours and 1 minute ago
          status: "read",
        },
        {
          id: "msg11",
          senderId: currentUser.id,
          receiverId: partner.id,
          content: "That looks great! I'd love to discuss this further. Are you available for a quick call tomorrow?",
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
          status: "delivered",
        },
        {
          id: "msg12",
          senderId: partner.id,
          receiverId: currentUser.id,
          content: "I'm available between 10 AM and 4 PM your time. Just let me know what works best for you.",
          type: "text",
          timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
          status: "delivered",
        },
      ]

      setMessages(sampleMessages)

      // Sample recent calls
      const sampleCalls: Call[] = [
        {
          id: "call1",
          type: "video",
          status: "ended",
          partnerId: partner.id,
          partnerName: partner.contactPerson,
          partnerAvatar: partner.logo,
          startTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3), // 3 days ago
          endTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3 + 1000 * 60 * 15), // 15 minutes later
          duration: "15:23",
        },
        {
          id: "call2",
          type: "audio",
          status: "missed",
          partnerId: partner.id,
          partnerName: partner.contactPerson,
          partnerAvatar: partner.logo,
          startTime: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
        },
        {
          id: "call3",
          type: "audio",
          status: "ended",
          partnerId: partner.id,
          partnerName: partner.contactPerson,
          partnerAvatar: partner.logo,
          startTime: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5 hours ago
          endTime: new Date(Date.now() - 1000 * 60 * 60 * 5 + 1000 * 60 * 8), // 8 minutes later
          duration: "8:12",
        },
      ]

      setRecentCalls(sampleCalls)
    }
  }, [partner, currentUser])

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Handle sending a message
  const handleSendMessage = () => {
    if (!messageInput.trim() && !selectedFile) return
    if (!partner || !currentUser) return

    const newMessage: Message = {
      id: `msg${Date.now()}`,
      senderId: currentUser.id,
      receiverId: partner.id,
      content: selectedFile ? selectedFile.name : messageInput,
      type: selectedFile ? getFileType(selectedFile) : "text",
      timestamp: new Date(),
      status: "sent",
      ...(selectedFile && {
        metadata: {
          fileName: selectedFile.name,
          fileSize: formatFileSize(selectedFile.size),
          fileType: selectedFile.type,
        },
      }),
    }

    setMessages([...messages, newMessage])
    setMessageInput("")
    setSelectedFile(null)

    // Simulate partner typing and response for demo purposes
    if (!selectedFile) {
      setTimeout(() => {
        setIsTyping(true)
      }, 1000)

      setTimeout(() => {
        setIsTyping(false)

        const responseMessage: Message = {
          id: `msg${Date.now() + 1}`,
          senderId: partner.id,
          receiverId: currentUser.id,
          content: getRandomResponse(messageInput, partner),
          type: "text",
          timestamp: new Date(),
          status: "delivered",
        }

        setMessages((prev) => [...prev, responseMessage])
      }, 3000)
    }
  }

  // Get a random response based on the input message
  const getRandomResponse = (input: string, partner: Partner): string => {
    const lowerInput = input.toLowerCase()

    if (lowerInput.includes("price") || lowerInput.includes("cost") || lowerInput.includes("quote")) {
      return `Our pricing varies based on volume and specifications. For your needs, I estimate it would be in the range of $5,000-7,500. I can prepare a detailed quote if you provide more specifics.`
    } else if (lowerInput.includes("delivery") || lowerInput.includes("shipping") || lowerInput.includes("timeline")) {
      return `We typically ship within 2-3 weeks after order confirmation. For your region, transit time is approximately 5-7 business days.`
    } else if (lowerInput.includes("sample") || lowerInput.includes("try")) {
      return `We'd be happy to provide samples! There's a nominal fee of $50 which is credited back on your first order. Would you like me to arrange this for you?`
    } else if (lowerInput.includes("thank")) {
      return `You're welcome! Please don't hesitate to reach out if you have any other questions.`
    } else if (lowerInput.includes("call") || lowerInput.includes("meeting") || lowerInput.includes("discuss")) {
      return `I'd be happy to schedule a call. How about tomorrow at 10 AM your time? We can discuss all the details then.`
    } else {
      return `Thank you for your message. I'll look into this and get back to you shortly. Is there anything specific about our ${partner.specialties[0]} that you'd like to know more about?`
    }
  }

  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])
    }
  }

  // Determine file type for message
  const getFileType = (file: File): MessageType => {
    if (file.type.startsWith("image/")) return "image"
    if (file.type.startsWith("video/")) return "video"
    if (file.type.startsWith("audio/")) return "audio"
    return "file"
  }

  // Format file size
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + " B"
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB"
    return (bytes / (1024 * 1024)).toFixed(1) + " MB"
  }

  // Start a video call
  const startVideoCall = () => {
    if (!partner || !currentUser) return

    setIsVideoCallActive(true)
    setActiveCall({
      id: `call${Date.now()}`,
      type: "video",
      status: "ongoing",
      partnerId: partner.id,
      partnerName: partner.contactPerson,
      partnerAvatar: partner.logo,
      startTime: new Date(),
    })
  }

  // Start an audio call
  const startAudioCall = () => {
    if (!partner || !currentUser) return

    setIsAudioCallActive(true)
    setActiveCall({
      id: `call${Date.now()}`,
      type: "audio",
      status: "ongoing",
      partnerId: partner.id,
      partnerName: partner.contactPerson,
      partnerAvatar: partner.logo,
      startTime: new Date(),
    })
  }

  // End the current call
  const endCall = () => {
    if (activeCall) {
      const endTime = new Date()
      const duration = formatCallDuration(activeCall.startTime ? endTime.getTime() - activeCall.startTime.getTime() : 0)

      const endedCall: Call = {
        ...activeCall,
        status: "ended",
        endTime,
        duration,
      }

      setRecentCalls([endedCall, ...recentCalls])
    }

    setIsVideoCallActive(false)
    setIsAudioCallActive(false)
    setActiveCall(null)
    setIsMicMuted(false)
    setIsVideoOff(false)
    setIsSharingScreen(false)
  }

  // Format call duration
  const formatCallDuration = (milliseconds: number): string => {
    const seconds = Math.floor(milliseconds / 1000)
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  // Format message timestamp
  const formatMessageTime = (date: Date): string => {
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (diffDays === 1) {
      return "Yesterday"
    } else if (diffDays < 7) {
      return date.toLocaleDateString([], { weekday: "short" })
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" })
    }
  }

  // Format call timestamp
  const formatCallTime = (date: Date): string => {
    const now = new Date()
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return `Today, ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
    } else if (diffDays === 1) {
      return `Yesterday, ${date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })
    }
  }

  // Render message status icon
  const renderMessageStatus = (status: string) => {
    switch (status) {
      case "sent":
        return <Check className="h-3 w-3 text-muted-foreground" />
      case "delivered":
        return <CheckCheck className="h-3 w-3 text-muted-foreground" />
      case "read":
        return <CheckCheck className="h-3 w-3 text-primary" />
      default:
        return <Clock className="h-3 w-3 text-muted-foreground" />
    }
  }

  // Render file icon based on type
  const renderFileIcon = (type: string) => {
    if (type.startsWith("image/")) return <ImageIcon className="h-5 w-5" />
    if (type.startsWith("video/")) return <Film className="h-5 w-5" />
    if (type.startsWith("audio/")) return <Music className="h-5 w-5" />
    if (type.includes("pdf")) return <FileText className="h-5 w-5" />
    return <File className="h-5 w-5" />
  }

  // Render message content based on type
  const renderMessageContent = (message: Message) => {
    switch (message.type) {
      case "image":
        return (
          <div className="relative">
            <Image
              src={`/placeholder.svg?height=200&width=300&text=Image`}
              alt="Image"
              width={300}
              height={200}
              className="rounded-md max-w-[240px] object-cover"
            />
            <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
              {message.metadata?.fileName}
            </div>
          </div>
        )
      case "file":
      case "video":
      case "audio":
        return (
          <div className="flex items-center gap-3 bg-muted/50 p-3 rounded-md">
            <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center text-primary">
              {renderFileIcon(message.metadata?.fileType || "")}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm truncate">{message.metadata?.fileName}</p>
              <p className="text-xs text-muted-foreground">{message.metadata?.fileSize}</p>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        )
      default:
        return <p className="text-sm">{message.content}</p>
    }
  }

  if (!isOpen) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh] p-0 gap-0">
        {/* Active Call UI */}
        {(isVideoCallActive || isAudioCallActive) && (
          <div className="absolute inset-0 z-50 bg-background flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={partner?.logo} />
                  <AvatarFallback>{partner?.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-medium">{partner?.contactPerson}</h3>
                  <p className="text-xs text-muted-foreground">
                    {isVideoCallActive ? "Video call" : "Audio call"} •{" "}
                    {activeCall?.startTime && (
                      <span className="tabular-nums">
                        {formatCallDuration(Date.now() - activeCall.startTime.getTime())}
                      </span>
                    )}
                  </p>
                </div>
              </div>
              <Button variant="destructive" size="sm" onClick={endCall}>
                End Call
              </Button>
            </div>

            <div className="flex-1 bg-black/90 relative flex items-center justify-center">
              {isVideoCallActive && !isVideoOff ? (
                <>
                  {/* Main video (partner) */}
                  <div className="w-full h-full">
                    <Image
                      src="/placeholder.svg?height=600&width=800&text=Partner+Video"
                      alt="Partner video"
                      fill
                      className="object-cover"
                    />
                  </div>

                  {/* Self video (picture-in-picture) */}
                  <div className="absolute bottom-4 right-4 w-48 h-36 rounded-lg overflow-hidden border-2 border-background shadow-lg">
                    <Image
                      src="/placeholder.svg?height=144&width=192&text=You"
                      alt="Your video"
                      fill
                      className="object-cover"
                    />
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center text-white">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage src={partner?.logo} />
                    <AvatarFallback className="text-3xl">{partner?.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-medium">{partner?.contactPerson}</h2>
                  <p className="text-white/70">{isVideoCallActive ? "Video call" : "Audio call"} in progress</p>
                </div>
              )}
            </div>

            <div className="p-4 bg-muted/30 flex items-center justify-center gap-4">
              <Button
                variant="outline"
                size="icon"
                className={`rounded-full h-12 w-12 ${isMicMuted ? "bg-destructive/10 text-destructive" : ""}`}
                onClick={() => setIsMicMuted(!isMicMuted)}
              >
                {isMicMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
              </Button>

              {isVideoCallActive && (
                <Button
                  variant="outline"
                  size="icon"
                  className={`rounded-full h-12 w-12 ${isVideoOff ? "bg-destructive/10 text-destructive" : ""}`}
                  onClick={() => setIsVideoOff(!isVideoOff)}
                >
                  {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
                </Button>
              )}

              {isVideoCallActive && (
                <Button
                  variant="outline"
                  size="icon"
                  className={`rounded-full h-12 w-12 ${isSharingScreen ? "bg-primary/10 text-primary" : ""}`}
                  onClick={() => setIsSharingScreen(!isSharingScreen)}
                >
                  <Monitor className="h-5 w-5" />
                </Button>
              )}

              <Button variant="destructive" size="icon" className="rounded-full h-12 w-12" onClick={endCall}>
                <Phone className="h-5 w-5 rotate-135" />
              </Button>
            </div>
          </div>
        )}

        {/* Chat UI */}
        <div className="flex h-full">
          {/* Sidebar */}
          <div className="w-64 border-r h-full flex flex-col">
            <div className="p-3 border-b flex items-center justify-between">
              <h2 className="font-semibold">Messages</h2>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <Search className="h-4 w-4" />
              </Button>
            </div>

            <Tabs defaultValue="chat" className="flex-1 flex flex-col">
              <TabsList className="grid grid-cols-2 mx-3 mt-2">
                <TabsTrigger value="chat" onClick={() => setActiveTab("chat")}>
                  Chats
                </TabsTrigger>
                <TabsTrigger value="calls" onClick={() => setActiveTab("calls")}>
                  Calls
                </TabsTrigger>
              </TabsList>

              <TabsContent
                value="chat"
                className="flex-1 overflow-y-auto p-0 data-[state=active]:flex data-[state=active]:flex-col"
              >
                <ScrollArea className="flex-1">
                  <div className="p-3">
                    <div className="relative p-3 rounded-md border bg-muted/50 hover:bg-muted cursor-pointer">
                      <div className="absolute top-3 right-3">
                        <Badge variant="secondary" className="text-xs">
                          New
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={partner?.logo} />
                          <AvatarFallback>{partner?.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{partner?.contactPerson}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {messages.length > 0 ? messages[messages.length - 1].content : "No messages yet"}
                          </p>
                        </div>
                      </div>
                      <div className="mt-1 flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">
                          {messages.length > 0 ? formatMessageTime(messages[messages.length - 1].timestamp) : ""}
                        </span>
                        <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center text-[10px] text-primary-foreground">
                          2
                        </div>
                      </div>
                    </div>
                  </div>
                </ScrollArea>

                <div className="p-3 mt-auto border-t">
                  <Button variant="outline" className="w-full gap-2">
                    <Plus className="h-4 w-4" />
                    New Message
                  </Button>
                </div>
              </TabsContent>

              <TabsContent
                value="calls"
                className="flex-1 overflow-y-auto p-0 data-[state=active]:flex data-[state=active]:flex-col"
              >
                <ScrollArea className="flex-1">
                  <div className="p-3 space-y-2">
                    {recentCalls.map((call) => (
                      <div key={call.id} className="p-3 rounded-md border hover:bg-muted cursor-pointer">
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarImage src={call.partnerAvatar} />
                            <AvatarFallback>{call.partnerName.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1">
                              <p className="font-medium truncate">{call.partnerName}</p>
                              {call.status === "missed" && (
                                <Badge variant="destructive" className="text-[10px] h-5">
                                  Missed
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              {call.type === "video" ? <Video className="h-3 w-3" /> : <Phone className="h-3 w-3" />}
                              <span>{call.startTime && formatCallTime(call.startTime)}</span>
                            </p>
                          </div>
                          <div>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              {call.type === "video" ? <Video className="h-4 w-4" /> : <Phone className="h-4 w-4" />}
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>

          {/* Main Chat Area */}
          <div className="flex-1 flex flex-col h-full">
            {/* Chat Header */}
            <div className="p-3 border-b flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={partner?.logo} />
                  <AvatarFallback>{partner?.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium">{partner?.contactPerson}</h3>
                    {partner?.verified && (
                      <Badge variant="secondary" className="h-5 text-[10px]">
                        Verified
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {partner?.name} • {partner?.city}, {partner?.country}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={startAudioCall}>
                        <Phone className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Audio Call</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={startVideoCall}>
                        <Video className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Video Call</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <Users className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Add Participants</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>More Options</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {/* Date separator */}
                <div className="flex items-center justify-center">
                  <div className="bg-muted text-xs px-3 py-1 rounded-full">
                    {messages.length > 0 &&
                      new Date(messages[0].timestamp).toLocaleDateString([], {
                        weekday: "long",
                        month: "long",
                        day: "numeric",
                      })}
                  </div>
                </div>

                {/* Messages */}
                {messages.map((message, index) => {
                  const isCurrentUser = message.senderId === currentUser?.id
                  const showAvatar =
                    !isCurrentUser && (index === 0 || messages[index - 1].senderId !== message.senderId)

                  return (
                    <div key={message.id} className={`flex ${isCurrentUser ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`flex ${isCurrentUser ? "flex-row-reverse" : "flex-row"} items-end gap-2 max-w-[80%]`}
                      >
                        {!isCurrentUser && showAvatar ? (
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={partner?.logo} />
                            <AvatarFallback>{partner?.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                        ) : (
                          <div className="w-8" />
                        )}

                        <div
                          className={`${
                            isCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted"
                          } rounded-lg p-3 ${message.type !== "text" ? "overflow-hidden" : ""}`}
                        >
                          {renderMessageContent(message)}
                          <div
                            className={`flex items-center gap-1 mt-1 text-xs ${isCurrentUser ? "text-primary-foreground/70" : "text-muted-foreground"}`}
                          >
                            <span>{formatMessageTime(message.timestamp)}</span>
                            {isCurrentUser && <span>{renderMessageStatus(message.status)}</span>}
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}

                {/* Typing indicator */}
                {isTyping && (
                  <div className="flex justify-start">
                    <div className="flex items-end gap-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={partner?.logo} />
                        <AvatarFallback>{partner?.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="bg-muted rounded-lg p-3">
                        <div className="flex space-x-2">
                          <div className="h-2 w-2 bg-primary rounded-full animate-bounce"></div>
                          <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-75"></div>
                          <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-150"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Selected File Preview */}
            {selectedFile && (
              <div className="p-3 border-t flex items-center justify-between bg-muted/30">
                <div className="flex items-center gap-2">
                  {renderFileIcon(selectedFile.type)}
                  <span className="text-sm truncate max-w-[200px]">{selectedFile.name}</span>
                  <span className="text-xs text-muted-foreground">{formatFileSize(selectedFile.size)}</span>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedFile(null)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}

            {/* Message Input */}
            <div className="p-3 border-t">
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Paperclip className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Attach File</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileSelect} />

                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-9 w-9">
                          <Camera className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Take Photo</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>

                <Input
                  placeholder="Type a message..."
                  className="flex-1"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                />

                <div className="flex gap-1">
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9"
                          onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                        >
                          <Smile className="h-5 w-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Emoji</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>

                  <Button
                    className="h-9 w-9"
                    size="icon"
                    onClick={handleSendMessage}
                    disabled={!messageInput.trim() && !selectedFile}
                  >
                    <Send className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

