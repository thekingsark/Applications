"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ExternalLink, MapPin, X } from "lucide-react"
import Image from "next/image"
import type { MapLocation } from "@/types"

export default function InteractiveMap() {
  const [selectedLocation, setSelectedLocation] = useState<MapLocation | null>(null)

  const locations: MapLocation[] = [
    {
      id: "na1",
      name: "New York",
      region: "North America",
      coordinates: { x: 25, y: 30 },
      description: "Major financial hub with numerous trade partners.",
    },
    {
      id: "eu1",
      name: "London",
      region: "Europe",
      coordinates: { x: 45, y: 25 },
      description: "Key European trade center with global connections.",
    },
    {
      id: "as1",
      name: "Tokyo",
      region: "Asia",
      coordinates: { x: 80, y: 30 },
      description: "Leading Asian market with strong technology sector.",
    },
    {
      id: "sa1",
      name: "São Paulo",
      region: "South America",
      coordinates: { x: 30, y: 60 },
      description: "Largest South American business center.",
    },
    {
      id: "af1",
      name: "Johannesburg",
      region: "Africa",
      coordinates: { x: 50, y: 60 },
      description: "Major African trade and mining hub.",
    },
    {
      id: "oc1",
      name: "Sydney",
      region: "Oceania",
      coordinates: { x: 85, y: 70 },
      description: "Key Pacific region business center.",
    },
  ]

  return (
    <div className="relative">
      <div className="aspect-[2/1] relative rounded-lg overflow-hidden border border-border">
        <Image
          src="/placeholder.svg?height=500&width=1000"
          alt="World Map"
          width={1000}
          height={500}
          className="w-full h-full object-cover z-0"
        />

        {/* Map pins */}
        {locations.map((location) => (
          <button
            key={location.id}
            className={`absolute z-10 group ${selectedLocation?.id === location.id ? "scale-125" : ""}`}
            style={{
              left: `${location.coordinates.x}%`,
              top: `${location.coordinates.y}%`,
              transform: "translate(-50%, -50%)",
            }}
            onClick={() => setSelectedLocation(location)}
            aria-label={`View details for ${location.name}`}
          >
            <div className="relative">
              <div className="h-3 w-3 bg-primary rounded-full animate-pulse" />
              <div className="absolute -inset-1 bg-primary/30 rounded-full animate-ping" />
            </div>
            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 whitespace-nowrap bg-background/80 backdrop-blur-sm px-2 py-0.5 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity">
              {location.name}
            </div>
          </button>
        ))}

        {/* Location info card - positioned differently on mobile vs desktop */}
        {selectedLocation && (
          <>
            {/* Mobile view - card at the bottom */}
            <Card className="absolute bottom-4 left-4 right-4 z-20 shadow-lg sm:hidden">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{selectedLocation.name}</h3>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setSelectedLocation(null)}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" />
                  <span>{selectedLocation.region}</span>
                </div>
                <p className="text-xs">{selectedLocation.description}</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full text-xs mt-2"
                  onClick={() => window.open("https://kingsideaconnections.org/friends-nearby/", "_blank")}
                >
                  View Detailed Information
                  <ExternalLink className="h-3 w-3 ml-1" />
                </Button>
              </CardContent>
            </Card>

            {/* Desktop view - card at the right */}
            <Card className="absolute bottom-4 right-4 w-64 z-20 shadow-lg hidden sm:block">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">{selectedLocation.name}</h3>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setSelectedLocation(null)}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3" />
                  <span>{selectedLocation.region}</span>
                </div>
                <p className="text-xs">{selectedLocation.description}</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full text-xs mt-2"
                  onClick={() => window.open("https://kingsideaconnections.org/friends-nearby/", "_blank")}
                >
                  View Detailed Information
                  <ExternalLink className="h-3 w-3 ml-1" />
                </Button>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <div className="mt-4 flex justify-end">
        <Button
          variant="outline"
          onClick={() => window.open("https://kingsideaconnections.org/friends-nearby/", "_blank")}
          className="gap-2 w-full sm:w-auto"
        >
          View Detailed Map
          <ExternalLink className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

