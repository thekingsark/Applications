"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search, MapPin, ExternalLink, BarChart2, TrendingUp, TrendingDown } from "lucide-react"
import Image from "next/image"
import { mediaAssets } from "@/components/media-assets"
import InteractiveMap from "./interactive-map"

// Market data
const marketTrendData = [
  { year: "2018", value: 1000, growth: 10 },
  { year: "2019", value: 1200, growth: 20 },
  { year: "2020", value: 900, growth: -25 },
  { year: "2021", value: 1500, growth: 67 },
  { year: "2022", value: 1800, growth: 20 },
  { year: "2023", value: 2200, growth: 22 },
  { year: "2024", value: 2800, growth: 27 },
  { year: "2025", value: 3500, growth: 25, forecast: true },
]

// Regional distribution data
const regionData = [
  { name: "North America", value: 35 },
  { name: "Europe", value: 25 },
  { name: "Asia", value: 20 },
  { name: "South America", value: 10 },
  { name: "Africa", value: 7 },
  { name: "Oceania", value: 3 },
]

// Industry sectors data
const sectorData = [
  { name: "Technology", value: 28 },
  { name: "Finance", value: 22 },
  { name: "Manufacturing", value: 18 },
  { name: "Agriculture", value: 12 },
  { name: "Energy", value: 10 },
  { name: "Healthcare", value: 7 },
  { name: "Other", value: 3 },
]

// Partner companies
const partnerCompanies = [
  {
    name: "Global Trade Solutions",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/gts",
    region: "North America",
    sector: "Technology",
  },
  {
    name: "EuroTrade Partners",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/eurotp",
    region: "Europe",
    sector: "Finance",
  },
  {
    name: "Asia Pacific Exchange",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/apex",
    region: "Asia",
    sector: "Manufacturing",
  },
  {
    name: "African Trade Alliance",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/ata",
    region: "Africa",
    sector: "Agriculture",
  },
  {
    name: "South American Commerce",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/sac",
    region: "South America",
    sector: "Energy",
  },
  {
    name: "Oceania Business Network",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/obn",
    region: "Oceania",
    sector: "Healthcare",
  },
  {
    name: "Global Finance Group",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/gfg",
    region: "North America",
    sector: "Finance",
  },
  {
    name: "Tech Innovations Inc",
    logo: "/placeholder.svg?height=60&width=120",
    website: "https://example.com/tii",
    region: "North America",
    sector: "Technology",
  },
]

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82CA9D", "#FFAF00", "#FF6B6B"]

// Market performance data
const marketPerformanceData = [
  { name: "Technology", current: 142.5, previous: 128.3, change: 11.1 },
  { name: "Finance", current: 98.7, previous: 102.4, change: -3.6 },
  { name: "Healthcare", current: 76.2, previous: 68.9, change: 10.6 },
  { name: "Energy", current: 112.8, previous: 105.6, change: 6.8 },
  { name: "Manufacturing", current: 84.3, previous: 86.1, change: -2.1 },
  { name: "Agriculture", current: 65.9, previous: 61.2, change: 7.7 },
  { name: "Retail", current: 72.4, previous: 75.8, change: -4.5 },
  { name: "Technology", current: 142.5, previous: 128.3, change: 11.1 },
]

export default function MarketInformation() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRegion, setSelectedRegion] = useState("All")
  const [selectedSector, setSelectedSector] = useState("All")
  const [activeMarketTab, setActiveMarketTab] = useState("overview")

  const filteredPartners = partnerCompanies.filter((partner) => {
    const matchesSearch = partner.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRegion = selectedRegion === "All" || partner.region === selectedRegion
    const matchesSector = selectedSector === "All" || partner.sector === selectedSector

    return matchesSearch && matchesRegion && matchesSector
  })

  return (
    <div className="space-y-8">
      {/* Enhanced Market Overview Section */}
      <Card>
        <CardHeader>
          <CardTitle>Market Overview</CardTitle>
          <CardDescription>Comprehensive market analysis and performance metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="overview" value={activeMarketTab} onValueChange={setActiveMarketTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="trends">Trends</TabsTrigger>
              <TabsTrigger value="distribution">Distribution</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="border rounded-lg p-4 flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Global Market Value</h3>
                      <p className="text-2xl font-bold">$3.5T</p>
                    </div>
                    <div className="flex items-center text-green-500">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span className="text-sm font-medium">+8.2%</span>
                    </div>
                  </div>
                  <div className="flex-1 mt-2 relative">
                    {/* Simulated Line Chart */}
                    <div className="w-full h-[80px]">
                      <svg viewBox="0 0 100 30" className="w-full h-full" preserveAspectRatio="none">
                        <path
                          d="M0,25 L5,22 L10,26 L15,20 L20,22 L25,18 L30,16 L35,14 L40,16 L45,13 L50,15 L55,10 L60,12 L65,8 L70,10 L75,6 L80,8 L85,4 L90,6 L95,2 L100,5"
                          fill="none"
                          stroke="hsl(var(--primary))"
                          strokeWidth="0.5"
                          vectorEffect="non-scaling-stroke"
                        />
                        <path
                          d="M0,25 L5,22 L10,26 L15,20 L20,22 L25,18 L30,16 L35,14 L40,16 L45,13 L50,15 L55,10 L60,12 L65,8 L70,10 L75,6 L80,8 L85,4 L90,6 L95,2 L100,5 V30 H0 Z"
                          fill="url(#gradient1)"
                          opacity="0.5"
                        />
                        <defs>
                          <linearGradient id="gradient1" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.2" />
                            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4 flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Active Markets</h3>
                      <p className="text-2xl font-bold">142</p>
                    </div>
                    <div className="flex items-center text-green-500">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span className="text-sm font-medium">+3</span>
                    </div>
                  </div>
                  <div className="flex-1 mt-2 relative">
                    {/* Simulated Bar Chart */}
                    <div className="w-full h-[80px] flex items-end justify-between">
                      {[35, 28, 42, 30, 38, 45, 40].map((height, i) => (
                        <div
                          key={i}
                          className="w-[8%] bg-primary/80 rounded-t-sm"
                          style={{ height: `${height}%` }}
                        ></div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4 flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Trading Volume (24h)</h3>
                      <p className="text-2xl font-bold">$42.8M</p>
                    </div>
                    <div className="flex items-center text-green-500">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span className="text-sm font-medium">+5.2%</span>
                    </div>
                  </div>
                  <div className="flex-1 mt-2 relative">
                    {/* Simulated Area Chart */}
                    <div className="w-full h-[80px]">
                      <svg viewBox="0 0 100 30" className="w-full h-full" preserveAspectRatio="none">
                        <path
                          d="M0,30 L0,20 C10,18 15,22 20,20 C25,18 30,15 40,16 C50,17 55,14 60,12 C65,10 70,8 80,10 C90,12 95,8 100,5 L100,30 Z"
                          fill="hsl(var(--primary))"
                          opacity="0.2"
                        />
                        <path
                          d="M0,20 C10,18 15,22 20,20 C25,18 30,15 40,16 C50,17 55,14 60,12 C65,10 70,8 80,10 C90,12 95,8 100,5"
                          fill="none"
                          stroke="hsl(var(--primary))"
                          strokeWidth="0.5"
                          vectorEffect="non-scaling-stroke"
                        />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Market Highlights</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3 p-3 border rounded-lg">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <TrendingUp className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">Technology Sector Leads Growth</h4>
                        <p className="text-sm text-muted-foreground">
                          Technology continues to lead market growth with a 11.1% increase in the last quarter, driven
                          by AI and cloud computing advancements.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 border rounded-lg">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <BarChart2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">Emerging Markets Expansion</h4>
                        <p className="text-sm text-muted-foreground">
                          Trade volume in emerging markets has increased by 15.3%, with Southeast Asia and Africa
                          showing the strongest growth potential.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 p-3 border rounded-lg">
                      <div className="p-2 bg-primary/10 rounded-full">
                        <TrendingDown className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">Finance Sector Adjustment</h4>
                        <p className="text-sm text-muted-foreground">
                          The finance sector is experiencing a temporary 3.6% decline as markets adjust to new
                          regulatory frameworks and interest rate changes.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Top Performing Markets</h3>
                  <div className="border rounded-lg overflow-hidden">
                    <div className="grid grid-cols-12 gap-2 p-3 border-b bg-muted/50 text-sm font-medium">
                      <div className="col-span-4">Market</div>
                      <div className="col-span-3 text-right">Current</div>
                      <div className="col-span-3 text-right">Previous</div>
                      <div className="col-span-2 text-right">Change</div>
                    </div>
                    <div className="divide-y">
                      {marketPerformanceData.slice(0, 5).map((market, index) => (
                        <div key={index} className="grid grid-cols-12 gap-2 p-3 text-sm hover:bg-muted/30">
                          <div className="col-span-4 font-medium">{market.name}</div>
                          <div className="col-span-3 text-right">{market.current.toFixed(1)}</div>
                          <div className="col-span-3 text-right">{market.previous.toFixed(1)}</div>
                          <div
                            className={`col-span-2 text-right font-medium ${market.change >= 0 ? "text-green-500" : "text-red-500"}`}
                          >
                            {market.change >= 0 ? "+" : ""}
                            {market.change.toFixed(1)}%
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="performance" className="space-y-6">
              <div className="h-[400px] relative border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Market Performance by Sector</h3>
                {/* Simulated Bar Chart */}
                <div className="absolute inset-0 pt-12 pb-8 px-8">
                  <div className="h-full flex items-end justify-around">
                    {sectorData.map((sector, index) => (
                      <div key={sector.name} className="flex flex-col items-center gap-2 w-[10%]">
                        <div
                          className="w-full rounded-t-md transition-all duration-500 hover:opacity-80"
                          style={{
                            height: `${sector.value * 10}px`,
                            backgroundColor: COLORS[index % COLORS.length],
                          }}
                        ></div>
                        <span className="text-xs font-medium text-center">{sector.name}</span>
                        <span className="text-xs">{sector.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="h-[300px] relative border rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-4">Growth Trends (2018-2025)</h3>
                  {/* Simulated Line Chart */}
                  <div className="absolute inset-0 pt-12 pb-8 px-8">
                    <div className="h-full relative">
                      <svg viewBox="0 0 100 30" className="w-full h-full" preserveAspectRatio="none">
                        <path
                          d="M0,25 L12.5,22 L25,26 L37.5,10 L50,15 L62.5,8 L75,5 L87.5,3 L100,2"
                          fill="none"
                          stroke="hsl(var(--primary))"
                          strokeWidth="0.5"
                          vectorEffect="non-scaling-stroke"
                        />
                        <path
                          d="M0,25 L12.5,22 L25,26 L37.5,10 L50,15 L62.5,8 L75,5 L87.5,3 L100,2 V30 H0 Z"
                          fill="url(#gradient2)"
                          opacity="0.3"
                        />
                        <defs>
                          <linearGradient id="gradient2" x1="0%" y1="0%" x2="0%" y2="100%">
                            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.3" />
                            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                      </svg>

                      {/* X-axis labels */}
                      <div className="absolute bottom-[-20px] left-0 w-full flex justify-between text-xs">
                        {marketTrendData.map((data, index) => (
                          <span key={index} className={data.forecast ? "text-muted-foreground italic" : ""}>
                            {data.year}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="h-[300px] relative border rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-4">Regional Distribution</h3>
                  {/* Simulated Pie Chart */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-[200px] h-[200px]">
                      <svg viewBox="0 0 100 100" className="w-full h-full">
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[0]}
                          strokeWidth="20"
                          strokeDasharray="75 25"
                          strokeDashoffset="0"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[1]}
                          strokeWidth="20"
                          strokeDasharray="50 50"
                          strokeDashoffset="-25"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[2]}
                          strokeWidth="20"
                          strokeDasharray="35 65"
                          strokeDashoffset="-75"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[3]}
                          strokeWidth="20"
                          strokeDasharray="25 75"
                          strokeDashoffset="-110"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[4]}
                          strokeWidth="20"
                          strokeDasharray="15 85"
                          strokeDashoffset="-135"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[5]}
                          strokeWidth="20"
                          strokeDasharray="10 90"
                          strokeDashoffset="-150"
                        />
                      </svg>
                    </div>

                    {/* Legend */}
                    <div className="absolute right-4 top-12 space-y-1">
                      {regionData.map((region, index) => (
                        <div key={region.name} className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          ></div>
                          <span className="text-xs">
                            {region.name} ({region.value}%)
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="trends" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-4">Quarterly Growth Rates</h3>
                  {/* Simulated Quarterly Growth Chart */}
                  <div className="h-[250px] relative">
                    <div className="absolute inset-0 flex items-end justify-between">
                      {[
                        { quarter: "Q1 2024", growth: 5.2 },
                        { quarter: "Q2 2024", growth: 7.8 },
                        { quarter: "Q3 2024", growth: 6.5 },
                        { quarter: "Q4 2024", growth: 8.2 },
                        { quarter: "Q1 2025", growth: 9.1 },
                      ].map((item, index) => (
                        <div key={index} className="flex flex-col items-center w-[15%]">
                          <div
                            className="w-full bg-primary/80 rounded-t-md"
                            style={{ height: `${item.growth * 20}px` }}
                          ></div>
                          <div className="mt-2 text-center">
                            <p className="text-xs font-medium">{item.quarter}</p>
                            <p className="text-xs text-green-500">+{item.growth}%</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-4">Market Volatility Index</h3>
                  {/* Simulated Volatility Chart */}
                  <div className="h-[250px] relative">
                    <svg viewBox="0 0 100 30" className="w-full h-full" preserveAspectRatio="none">
                      <path
                        d="M0,15 L5,10 L10,20 L15,5 L20,25 L25,10 L30,15 L35,5 L40,20 L45,10 L50,15 L55,5 L60,25 L65,10 L70,20 L75,5 L80,15 L85,10 L90,20 L95,5 L100,15"
                        fill="none"
                        stroke="hsl(var(--primary))"
                        strokeWidth="0.5"
                        vectorEffect="non-scaling-stroke"
                      />
                    </svg>

                    <div className="absolute bottom-[-20px] left-0 w-full flex justify-between text-xs">
                      <span>Jan</span>
                      <span>Feb</span>
                      <span>Mar</span>
                      <span>Apr</span>
                      <span>May</span>
                      <span>Jun</span>
                    </div>

                    <div className="absolute top-2 right-2 flex items-center gap-2">
                      <div className="w-3 h-3 bg-primary rounded-full"></div>
                      <span className="text-xs font-medium">Volatility</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Emerging Market Trends</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    { region: "Southeast Asia", growth: 18.5, trend: "up" },
                    { region: "Africa", growth: 15.2, trend: "up" },
                    { region: "Latin America", growth: 12.8, trend: "up" },
                    { region: "Eastern Europe", growth: 9.5, trend: "up" },
                    { region: "Middle East", growth: 11.3, trend: "up" },
                    { region: "South Asia", growth: 14.7, trend: "up" },
                  ].map((market, index) => (
                    <div key={index} className="border rounded-md p-3">
                      <div className="flex justify-between items-start">
                        <h4 className="font-medium">{market.region}</h4>
                        <div className="flex items-center text-green-500">
                          <TrendingUp className="h-4 w-4 mr-1" />
                          <span className="text-sm font-medium">+{market.growth}%</span>
                        </div>
                      </div>
                      <div className="mt-2 h-[60px]">
                        {/* Mini Sparkline */}
                        <svg viewBox="0 0 100 30" className="w-full h-full" preserveAspectRatio="none">
                          <path
                            d={`M0,${20 - index * 2} L20,${15 + index} L40,${18 - index} L60,${12 + index * 0.5} L80,${10 - index * 0.3} L100,${8 + index * 0.2}`}
                            fill="none"
                            stroke="hsl(var(--primary))"
                            strokeWidth="1"
                            vectorEffect="non-scaling-stroke"
                          />
                        </svg>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="distribution" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="border rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-4">Sector Distribution</h3>
                  <div className="h-[300px] relative">
                    {/* Horizontal Bar Chart */}
                    <div className="absolute inset-0 flex flex-col justify-around p-4">
                      {sectorData.map((sector, index) => (
                        <div key={sector.name} className="flex items-center gap-2">
                          <span className="text-sm w-28">{sector.name}</span>
                          <div className="flex-1 h-6 bg-muted/30 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full transition-all duration-1000"
                              style={{
                                width: `${sector.value * 2}%`,
                                backgroundColor: COLORS[index % COLORS.length],
                              }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-12 text-right">{sector.value}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <h3 className="text-lg font-semibold mb-4">Regional Distribution</h3>
                  <div className="h-[300px] relative">
                    {/* Horizontal Bar Chart */}
                    <div className="absolute inset-0 flex flex-col justify-around p-4">
                      {regionData.map((region, index) => (
                        <div key={region.name} className="flex items-center gap-2">
                          <span className="text-sm w-28">{region.name}</span>
                          <div className="flex-1 h-6 bg-muted/30 rounded-full overflow-hidden">
                            <div
                              className="h-full rounded-full transition-all duration-1000"
                              style={{
                                width: `${region.value * 2}%`,
                                backgroundColor: COLORS[index % COLORS.length],
                              }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-12 text-right">{region.value}%</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="text-lg font-semibold mb-4">Market Distribution by Trade Volume</h3>
                <div className="h-[300px] relative">
                  {/* Treemap Visualization */}
                  <div className="absolute inset-0 grid grid-cols-4 grid-rows-3 gap-2 p-4">
                    {[
                      { name: "Tech - NA", volume: 28, color: COLORS[0] },
                      { name: "Finance - EU", volume: 22, color: COLORS[1] },
                      { name: "Energy - APAC", volume: 18, color: COLORS[2] },
                      { name: "Tech - EU", volume: 15, color: COLORS[0] },
                      { name: "Healthcare - NA", volume: 12, color: COLORS[3] },
                      { name: "Mfg - APAC", volume: 10, color: COLORS[4] },
                      { name: "Finance - NA", volume: 8, color: COLORS[1] },
                      { name: "Agri - SA", volume: 7, color: COLORS[5] },
                      { name: "Tech - APAC", volume: 6, color: COLORS[0] },
                      { name: "Energy - ME", volume: 5, color: COLORS[2] },
                      { name: "Mfg - EU", volume: 4, color: COLORS[4] },
                      { name: "Healthcare - APAC", volume: 3, color: COLORS[3] },
                    ].map((item, i) => (
                      <div
                        key={i}
                        className="rounded-md flex flex-col items-center justify-center p-2 text-center transition-colors duration-500"
                        style={{
                          backgroundColor: item.color,
                          gridColumn: item.volume > 15 ? "span 2" : "span 1",
                          gridRow: item.volume > 20 ? "span 2" : "span 1",
                          color: "white",
                        }}
                      >
                        <p className="text-xs font-medium">{item.name}</p>
                        <p className="text-sm font-bold">{item.volume}%</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Global Market Trends</CardTitle>
            <CardDescription>Annual market value and growth rate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[350px] flex items-center justify-center">
              <div className="w-full h-full relative">
                {/* Line Chart for Market Trends */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg viewBox="0 0 100 50" className="w-full h-full" preserveAspectRatio="none">
                    {/* Grid lines */}
                    <line x1="0" y1="10" x2="100" y2="10" stroke="hsl(var(--border))" strokeWidth="0.2" />
                    <line x1="0" y1="20" x2="100" y2="20" stroke="hsl(var(--border))" strokeWidth="0.2" />
                    <line x1="0" y1="30" x2="100" y2="30" stroke="hsl(var(--border))" strokeWidth="0.2" />
                    <line x1="0" y1="40" x2="100" y2="40" stroke="hsl(var(--border))" strokeWidth="0.2" />

                    {/* Value line */}
                    <path
                      d="M0,40 L14.3,35 L28.6,30 L42.9,42 L57.1,25 L71.4,20 L85.7,15 L100,10"
                      fill="none"
                      stroke="hsl(var(--primary))"
                      strokeWidth="0.5"
                      vectorEffect="non-scaling-stroke"
                    />

                    {/* Growth line */}
                    <path
                      d="M0,35 L14.3,30 L28.6,25 L42.9,45 L57.1,15 L71.4,25 L85.7,20 L100,15"
                      fill="none"
                      stroke="hsl(var(--primary)/0.5)"
                      strokeWidth="0.5"
                      strokeDasharray="2,1"
                      vectorEffect="non-scaling-stroke"
                    />

                    {/* Data points */}
                    {marketTrendData.map((data, index) => {
                      const x = index * (100 / (marketTrendData.length - 1))
                      const y1 = 50 - data.value / 100
                      const y2 = 50 - (data.growth + 30) / 2

                      return (
                        <g key={index}>
                          <circle cx={x} cy={y1} r="0.8" fill="hsl(var(--primary))" />
                          <circle cx={x} cy={y2} r="0.8" fill="hsl(var(--primary)/0.5)" />
                        </g>
                      )
                    })}
                  </svg>

                  {/* Legend */}
                  <div className="absolute top-2 right-2 flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-0.5 bg-primary"></div>
                      <span className="text-xs">Market Value</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-0.5 bg-primary/50 border-dashed border-primary"></div>
                      <span className="text-xs">Growth Rate</span>
                    </div>
                  </div>

                  {/* X-axis labels */}
                  <div className="absolute bottom-0 left-0 w-full flex justify-between text-xs">
                    {marketTrendData.map((data, index) => (
                      <span key={index} className={data.forecast ? "text-muted-foreground italic" : ""}>
                        {data.year}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-sm text-muted-foreground">
              Source: Kings Global Funding Market Analysis, 2024. Values for 2025 are forecasted.
            </p>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Market Distribution</CardTitle>
            <CardDescription>By region and industry sector</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="region">
              <TabsList className="mb-4">
                <TabsTrigger value="region">By Region</TabsTrigger>
                <TabsTrigger value="sector">By Sector</TabsTrigger>
              </TabsList>

              <TabsContent value="region" className="h-[300px] flex items-center justify-center">
                <div className="w-full h-full relative">
                  {/* Pie Chart for Regional Distribution */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="relative w-[250px] h-[250px]">
                      <svg viewBox="0 0 100 100" className="w-full h-full">
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[0]}
                          strokeWidth="20"
                          strokeDasharray="75 25"
                          strokeDashoffset="0"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[1]}
                          strokeWidth="20"
                          strokeDasharray="50 50"
                          strokeDashoffset="-25"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[2]}
                          strokeWidth="20"
                          strokeDasharray="35 65"
                          strokeDashoffset="-75"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[3]}
                          strokeWidth="20"
                          strokeDasharray="25 75"
                          strokeDashoffset="-110"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[4]}
                          strokeWidth="20"
                          strokeDasharray="15 85"
                          strokeDashoffset="-135"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="40"
                          fill="transparent"
                          stroke={COLORS[5]}
                          strokeWidth="20"
                          strokeDasharray="10 90"
                          strokeDashoffset="-150"
                        />
                      </svg>
                    </div>

                    {/* Legend */}
                    <div className="absolute right-4 top-1/2 -translate-y-1/2 space-y-1">
                      {regionData.map((region, index) => (
                        <div key={region.name} className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: COLORS[index % COLORS.length] }}
                          ></div>
                          <span className="text-xs">
                            {region.name} ({region.value}%)
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="sector" className="h-[300px] flex items-center justify-center">
                <div className="w-full h-full relative">
                  {/* Bar Chart for Sector Distribution */}
                  <div className="absolute inset-0 flex items-end justify-around p-8">
                    {sectorData.map((sector, index) => (
                      <div key={sector.name} className="flex flex-col items-center gap-2 w-[10%]">
                        <div
                          className="w-full rounded-t-md transition-all duration-500 hover:opacity-80"
                          style={{
                            height: `${sector.value * 8}px`,
                            backgroundColor: COLORS[index % COLORS.length],
                          }}
                        ></div>
                        <span className="text-xs font-medium text-center">{sector.name}</span>
                        <span className="text-xs">{sector.value}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Market Analysis</CardTitle>
          <CardDescription>Current trends and future outlook</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <h3 className="text-lg font-semibold">Global Trade Landscape</h3>
          <p>
            The global trade landscape continues to evolve rapidly, with Kings Global Funding positioned at the
            forefront of facilitating international commerce. Our analysis indicates a steady growth trajectory in
            global trade volumes, with a projected increase of 25% by 2025, despite ongoing geopolitical challenges and
            supply chain disruptions.
          </p>
          <div className="relative w-full h-[200px] sm:h-[300px] rounded-lg overflow-hidden">
            <Image
              src={mediaAssets.business.trading || "/placeholder.svg?height=300&width=500"}
              alt="Global Market Analysis"
              fill
              className="object-cover"
            />
          </div>

          <h3 className="text-lg font-semibold mt-4">Key Market Insights</h3>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <strong>Digital Transformation:</strong> E-commerce and digital trade platforms are experiencing
              unprecedented growth, with a 35% year-over-year increase in transaction volumes.
            </li>
            <li>
              <strong>Sustainable Trade:</strong> Green initiatives and sustainable business practices are becoming
              increasingly important, with 68% of businesses prioritizing environmental considerations in their trade
              decisions.
            </li>
            <li>
              <strong>Emerging Markets:</strong> Developing economies, particularly in Southeast Asia and Africa, are
              showing robust growth potential, with trade volumes increasing by 42% since 2020.
            </li>
            <li>
              <strong>B2B Connections:</strong> Business-to-business networking platforms are facilitating more
              efficient trade relationships, reducing transaction costs by an average of 23%.
            </li>
          </ul>

          <h3 className="text-lg font-semibold mt-4">Future Outlook</h3>
          <p>
            Looking ahead, we anticipate continued growth in global trade, driven by technological innovation, strategic
            partnerships, and the increasing integration of emerging markets into the global economy. The Kings Ark
            World Trade Center is uniquely positioned to capitalize on these trends, offering a comprehensive ecosystem
            for businesses to connect, trade, and thrive in the evolving global marketplace.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <CardTitle>Partner Network</CardTitle>
            <CardDescription>Our global trade partners and connections</CardDescription>
          </div>
          <div className="w-full sm:w-auto">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search partners..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 w-full"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-wrap gap-4">
            <div className="space-y-1 w-full sm:w-auto">
              <p className="text-sm font-medium">Filter by Region:</p>
              <select
                className="p-2 rounded-md border bg-background w-full sm:w-auto"
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
              >
                <option value="All">All Regions</option>
                {regionData.map((region) => (
                  <option key={region.name} value={region.name}>
                    {region.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1 w-full sm:w-auto">
              <p className="text-sm font-medium">Filter by Sector:</p>
              <select
                className="p-2 rounded-md border bg-background w-full sm:w-auto"
                value={selectedSector}
                onChange={(e) => setSelectedSector(e.target.value)}
              >
                <option value="All">All Sectors</option>
                {sectorData.map((sector) => (
                  <option key={sector.name} value={sector.name}>
                    {sector.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {filteredPartners.length > 0 ? (
              filteredPartners.map((partner, index) => (
                <div key={index} className="border rounded-lg p-4 flex flex-col items-center">
                  <Image
                    src={partner.logo || "/placeholder.svg"}
                    alt={partner.name}
                    width={120}
                    height={60}
                    className="mb-2"
                  />
                  <h3 className="font-medium text-center">{partner.name}</h3>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                    <MapPin className="h-3 w-3" />
                    <span>{partner.region}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{partner.sector}</p>
                  <a
                    href={partner.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-2 text-xs text-primary flex items-center gap-1 hover:underline"
                  >
                    Visit Website
                    <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-8 text-muted-foreground">
                No partners found matching your filters. Try adjusting your search criteria.
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" onClick={() => window.open("https://kingsglobalfunding.world", "_blank")}>
            For Full Experience: Enter Application
            <ExternalLink className="h-4 w-4 ml-2" />
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Global Partner Map</CardTitle>
          <CardDescription>Interactive map of our worldwide network</CardDescription>
        </CardHeader>
        <CardContent>
          <InteractiveMap />
        </CardContent>
        <CardFooter className="flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">Data updated: March 2025</p>
          <Button
            variant="outline"
            onClick={() => window.open("https://kingsideaconnections.org/friends-nearby/", "_blank")}
            className="glow-button w-full sm:w-auto"
          >
            View Detailed Map
            <ExternalLink className="h-4 w-4 ml-2" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

