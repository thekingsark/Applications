"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Filter, Clock, DollarSign, Globe, Users, ExternalLink } from "lucide-react"

export default function BiddingInformation() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  const biddingOpportunities = [
    {
      id: "bid-001",
      title: "Global Supply Chain Management System",
      category: "Technology",
      budget: "$250,000 - $500,000",
      deadline: "April 15, 2025",
      location: "Global",
      participants: 12,
      status: "open",
      description:
        "Seeking proposals for implementing an enterprise-level supply chain management system with global tracking capabilities.",
    },
    {
      id: "bid-002",
      title: "Sustainable Agriculture Equipment",
      category: "Agriculture",
      budget: "$100,000 - $300,000",
      deadline: "May 2, 2025",
      location: "Africa",
      participants: 8,
      status: "open",
      description:
        "Looking for suppliers of sustainable farming equipment suitable for small-scale farmers in developing regions.",
    },
    {
      id: "bid-003",
      title: "Renewable Energy Installation",
      category: "Energy",
      budget: "$1M - $2.5M",
      deadline: "June 10, 2025",
      location: "Asia",
      participants: 15,
      status: "open",
      description:
        "Bidding for installation of solar and wind energy systems across multiple commercial properties in Southeast Asia.",
    },
    {
      id: "bid-004",
      title: "Medical Supplies Distribution",
      category: "Healthcare",
      budget: "$500,000 - $750,000",
      deadline: "March 30, 2025",
      location: "Europe",
      participants: 7,
      status: "closing-soon",
      description: "Distribution contract for medical supplies to hospitals and clinics across European markets.",
    },
    {
      id: "bid-005",
      title: "Smart City Infrastructure",
      category: "Technology",
      budget: "$5M - $10M",
      deadline: "August 22, 2025",
      location: "North America",
      participants: 23,
      status: "open",
      description:
        "Comprehensive smart city infrastructure implementation including IoT sensors, data analytics, and management systems.",
    },
    {
      id: "bid-006",
      title: "Educational Technology Platform",
      category: "Education",
      budget: "$200,000 - $400,000",
      deadline: "April 5, 2025",
      location: "Global",
      participants: 19,
      status: "closing-soon",
      description:
        "Development of a comprehensive educational technology platform for remote and hybrid learning environments.",
    },
  ]

  const filteredOpportunities = biddingOpportunities.filter((opportunity) => {
    // Filter by search query
    if (
      searchQuery &&
      !opportunity.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !opportunity.description.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !opportunity.category.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    // Filter by tab
    if (activeTab === "closing-soon" && opportunity.status !== "closing-soon") {
      return false
    }

    return true
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold">Bidding Platform</h1>
          <p className="text-muted-foreground">Discover global bidding opportunities</p>
        </div>
        <Button>Create New Bid</Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search opportunities..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Opportunities</TabsTrigger>
          <TabsTrigger value="closing-soon">Closing Soon</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredOpportunities.map((opportunity) => (
              <Card key={opportunity.id} className="h-full flex flex-col">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{opportunity.title}</CardTitle>
                    <Badge variant={opportunity.status === "closing-soon" ? "destructive" : "secondary"}>
                      {opportunity.status === "closing-soon" ? "Closing Soon" : "Open"}
                    </Badge>
                  </div>
                  <CardDescription>{opportunity.category}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm mb-4">{opportunity.description}</p>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{opportunity.budget}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>Deadline: {opportunity.deadline}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Globe className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{opportunity.location}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{opportunity.participants} participants</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">View Details</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="closing-soon" className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredOpportunities.map((opportunity) => (
              <Card key={opportunity.id} className="h-full flex flex-col">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{opportunity.title}</CardTitle>
                    <Badge variant="destructive">Closing Soon</Badge>
                  </div>
                  <CardDescription>{opportunity.category}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm mb-4">{opportunity.description}</p>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{opportunity.budget}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>Deadline: {opportunity.deadline}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Globe className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{opportunity.location}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{opportunity.participants} participants</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">View Details</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <div className="flex justify-center mt-8">
        <Button variant="outline" className="gap-2">
          View All Opportunities
          <ExternalLink className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

