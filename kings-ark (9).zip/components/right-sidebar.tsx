"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import {
  BookOpen,
  MessageSquare,
  Bell,
  Calendar,
  ChevronRight,
  ExternalLink,
  Info,
  HelpCircle,
  FileText,
  Settings,
  ChevronLeft,
  Globe,
  Video,
  ShoppingBag,
} from "lucide-react"
import Link from "next/link"
import type { RightTabLink } from "@/types"

export default function RightSidebar() {
  const [activeItem, setActiveItem] = useState<string | null>(null)
  const [collapsed, setCollapsed] = useState(false)
  const [isMobile, setIsMobile] = useState(false)

  // Check if mobile on mount and when window resizes
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 1024)
      // Make sidebar visible by default on all devices
      setCollapsed(window.innerWidth < 1024)
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  const rightTabLinks: RightTabLink[] = [
    {
      name: "Knowledge Base",
      path: "/knowledge-base",
      icon: <BookOpen className="h-5 w-5" />,
      description: "Access comprehensive guides and documentation",
    },
    {
      name: "AI Support Chat",
      path: "/ai-support-chat",
      icon: <MessageSquare className="h-5 w-5" />,
      description: "Get instant help from our AI assistant for buyers and sellers",
    },
    {
      name: "Global Map",
      path: "/global-map",
      icon: <Globe className="h-5 w-5" />,
      description: "Find partners worldwide on our interactive global map",
    },
    {
      name: "Marketplace",
      path: "/marketplace",
      icon: <ShoppingBag className="h-5 w-5" />,
      description: "Buy and sell products, post deals, and find business opportunities",
    },
    {
      name: "Notifications",
      path: "/notifications",
      icon: <Bell className="h-5 w-5" />,
      description: "View your latest notifications and alerts",
    },
    {
      name: "Calendar",
      path: "/calendar",
      icon: <Calendar className="h-5 w-5" />,
      description: "Schedule and manage your meetings",
    },
  ]

  const quickLinks = [
    {
      name: "Market Reports",
      path: "/market-reports",
      icon: <FileText className="h-4 w-4" />,
    },
    {
      name: "Help Center",
      path: "/help-center",
      icon: <HelpCircle className="h-4 w-4" />,
    },
    {
      name: "About Us",
      path: "/about-us",
      icon: <Info className="h-4 w-4" />,
    },
    {
      name: "Media",
      path: "/media",
      icon: <Video className="h-4 w-4" />,
    },
    {
      name: "Preferences",
      path: "/preferences",
      icon: <Settings className="h-4 w-4" />,
    },
  ]

  return (
    <div
      className={`${collapsed ? "w-16" : "w-64"} h-screen border-l bg-background flex flex-col overflow-y-auto transition-all duration-300 relative`}
    >
      {/* Collapse/Expand Button */}
      <Button
        variant="outline"
        size="icon"
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -left-3 top-20 z-10 h-8 w-8 rounded-full border bg-primary/10 shadow-md shadow-primary/20 glow-button animate-pulse"
      >
        {collapsed ? (
          <ChevronLeft className="h-4 w-4 text-primary" />
        ) : (
          <ChevronRight className="h-4 w-4 text-primary" />
        )}
      </Button>

      <div className={`p-4 border-b ${collapsed ? "text-center" : ""}`}>
        {collapsed ? (
          <div className="flex justify-center">
            <BookOpen className="h-5 w-5" />
          </div>
        ) : (
          <h2 className="font-semibold">Resources & Support</h2>
        )}
      </div>

      <div className="flex-1 p-4 space-y-4">
        {collapsed ? (
          <div className="flex flex-col items-center gap-4">
            {rightTabLinks.map((link) => (
              <Link key={link.name} href={link.path}>
                <Button
                  variant="ghost"
                  size="icon"
                  className={`glow-button hover:bg-primary/10 hover:text-primary ${activeItem === link.name ? "bg-primary/20 text-primary shadow-md shadow-primary/20" : ""}`}
                  onClick={() => setActiveItem(link.name)}
                  title={link.name}
                >
                  <span className={`menu-icon ${activeItem === link.name ? "gold-glow-icon" : ""}`}>{link.icon}</span>
                </Button>
              </Link>
            ))}

            <div className="border-t w-full my-2"></div>

            {quickLinks.map((link) => (
              <Link key={link.name} href={link.path}>
                <Button variant="ghost" size="icon" className="glow-button" title={link.name}>
                  <span className="menu-icon">{link.icon}</span>
                </Button>
              </Link>
            ))}
          </div>
        ) : (
          <>
            {rightTabLinks.map((link) => (
              <Link key={link.name} href={link.path}>
                <Card
                  className={`hover:shadow-md transition-all cursor-pointer glow-border ${
                    activeItem === link.name ? "border-primary" : ""
                  }`}
                  onClick={() => setActiveItem(link.name)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start">
                      <div
                        className={`p-2 rounded-full bg-primary/10 ${activeItem === link.name ? "gold-glow-icon" : "text-primary"}`}
                      >
                        {link.icon}
                      </div>
                      <div className="ml-3">
                        <h3 className="font-medium">{link.name}</h3>
                        <p className="text-xs text-muted-foreground mt-1">{link.description}</p>
                      </div>
                      <ChevronRight className="h-4 w-4 ml-auto text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}

            <div className="mt-6">
              <h3 className="text-sm font-medium mb-2 px-1">Quick Links</h3>
              <div className="space-y-1">
                {quickLinks.map((link) => (
                  <Link
                    key={link.name}
                    href={link.path}
                    className="flex items-center px-2 py-1.5 text-sm rounded-md hover:bg-accent hover:text-accent-foreground transition-colors"
                  >
                    <span className="menu-icon">{link.icon}</span>
                    <span className="ml-2">{link.name}</span>
                  </Link>
                ))}
              </div>
            </div>
          </>
        )}
      </div>

      <div className={`p-4 border-t ${collapsed ? "text-center" : ""}`}>
        {collapsed ? (
          <div className="flex justify-center">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="ml-2 text-sm">System Status: Online</span>
            </div>
            <a href="#" className="text-xs text-primary flex items-center">
              Details
              <ExternalLink className="h-3 w-3 ml-1" />
            </a>
          </div>
        )}
      </div>
    </div>
  )
}

