"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Play, Pause, VolumeX, Volume2, Mic, X } from "lucide-react"
import type { TextToSpeechProps } from "@/types"

export default function TextToSpeech({ isOpen, onClose }: TextToSpeechProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(80)
  const [rate, setRate] = useState(1)
  const [pitch, setPitch] = useState(1)
  const [isMuted, setIsMuted] = useState(false)
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null)

  useEffect(() => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      // Get available voices
      const getVoices = () => {
        const availableVoices = window.speechSynthesis.getVoices()
        if (availableVoices.length > 0) {
          setVoices(availableVoices)
          setSelectedVoice(availableVoices[0])
        }
      }

      getVoices()

      // Chrome loads voices asynchronously
      window.speechSynthesis.onvoiceschanged = getVoices

      // Cleanup
      return () => {
        if (typeof window !== "undefined" && "speechSynthesis" in window) {
          try {
            window.speechSynthesis.cancel()
          } catch (error) {
            console.error("Error canceling speech synthesis:", error)
          }
        }
      }
    }
  }, [])

  // Improve the text-to-speech functionality
  const togglePlayPause = () => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      try {
        if (isPlaying) {
          window.speechSynthesis.pause()
        } else {
          if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume()
          } else {
            // Start reading the page content
            const textToRead = document.body.textContent || ""
            const utterance = new SpeechSynthesisUtterance(textToRead)

            if (selectedVoice) {
              utterance.voice = selectedVoice
            }

            utterance.volume = isMuted ? 0 : volume / 100
            utterance.rate = rate
            utterance.pitch = pitch
            utterance.lang = "en-US" // Default language

            utterance.onend = () => setIsPlaying(false)
            utterance.onerror = (event) => {
              console.error("Speech synthesis error:", event)
              setIsPlaying(false)
            }

            window.speechSynthesis.speak(utterance)
          }
        }
        setIsPlaying(!isPlaying)
      } catch (error) {
        console.error("Error with speech synthesis:", error)
        setIsPlaying(false)
      }
    }
  }

  // Add a function to speak selected text
  const speakSelectedText = () => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      try {
        const selection = window.getSelection()
        const selectedText = selection ? selection.toString() : ""

        if (selectedText) {
          const utterance = new SpeechSynthesisUtterance(selectedText)

          if (selectedVoice) {
            utterance.voice = selectedVoice
          }

          utterance.volume = isMuted ? 0 : volume / 100
          utterance.rate = rate
          utterance.pitch = pitch

          utterance.onend = () => setIsPlaying(false)
          utterance.onerror = (event) => {
            console.error("Speech synthesis error:", event)
            setIsPlaying(false)
          }

          window.speechSynthesis.speak(utterance)
          setIsPlaying(true)
        }
      } catch (error) {
        console.error("Error with speech synthesis:", error)
        setIsPlaying(false)
      }
    }
  }

  const stopSpeaking = () => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel()
      setIsPlaying(false)
    }
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      // Update current utterance if any
      const utterances = window.speechSynthesis.getVoices()
      if (utterances.length > 0) {
        utterances[0].volume = !isMuted ? 0 : volume / 100
      }
    }
  }

  const handleVoiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedIndex = e.target.selectedIndex
    setSelectedVoice(voices[selectedIndex])
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-background border border-border rounded-lg shadow-lg w-full max-w-md">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Mic className="h-5 w-5" />
            Text to Speech
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
            <span className="sr-only">Close</span>
          </Button>
        </div>

        <div className="p-4 space-y-6">
          <div className="space-y-2">
            <label htmlFor="voice-select" className="block text-sm font-medium">
              Voice
            </label>
            <select
              id="voice-select"
              className="w-full p-2 border rounded-md bg-background"
              onChange={handleVoiceChange}
              value={selectedVoice?.name}
            >
              {voices.map((voice) => (
                <option key={voice.name} value={voice.name}>
                  {voice.name} ({voice.lang})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Volume: {volume}%</label>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={toggleMute} aria-label={isMuted ? "Unmute" : "Mute"}>
                {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
              <Slider
                value={[volume]}
                min={0}
                max={100}
                step={1}
                onValueChange={(value) => setVolume(value[0])}
                className="flex-1"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Rate: {rate.toFixed(1)}x</label>
            <Slider value={[rate]} min={0.5} max={2} step={0.1} onValueChange={(value) => setRate(value[0])} />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Pitch: {pitch.toFixed(1)}</label>
            <Slider value={[pitch]} min={0.5} max={2} step={0.1} onValueChange={(value) => setPitch(value[0])} />
          </div>
        </div>

        <div className="p-4 border-t flex justify-between">
          <Button
            variant={isPlaying ? "destructive" : "default"}
            onClick={isPlaying ? stopSpeaking : togglePlayPause}
            className="gap-2"
          >
            {isPlaying ? (
              <>
                <Pause className="h-4 w-4" /> Stop
              </>
            ) : (
              <>
                <Play className="h-4 w-4" /> Read Page
              </>
            )}
          </Button>
          <Button variant="outline" onClick={onClose}>
            Done
          </Button>
          {/* Add a button to speak selected text */}
          <Button variant="outline" onClick={speakSelectedText} className="gap-2 glow-button">
            <Volume2 className="h-4 w-4" /> Speak Selected Text
          </Button>
        </div>
      </div>
    </div>
  )
}

