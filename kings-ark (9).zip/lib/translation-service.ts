import type { SupportedLanguage, LanguageMap } from "@/types"

// Basic translations for demonstration
export const translations: LanguageMap = {
  en: {
    dashboard: "Dashboard",
    markets: "Markets",
    trade: "Trade",
    social: "B2B Social",
    tv: "Kings Ark TV",
    bidding: "Bidding",
    account: "Account",
    welcome: "Your gateway to global trade and investment opportunities",
    search: "Search",
    settings: "Settings",
    language: "Language",
    accessibility: "Accessibility",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
  },
  es: {
    dashboard: "Panel",
    markets: "Mercados",
    trade: "Comercio",
    social: "Social B2B",
    tv: "Kings Ark TV",
    bidding: "Licitación",
    account: "Cuenta",
    welcome: "Su puerta de entrada a oportunidades globales de comercio e inversión",
    search: "Buscar",
    settings: "Configuración",
    language: "Idioma",
    accessibility: "Accesibilidad",
    darkMode: "Modo Oscuro",
    lightMode: "Modo Claro",
  },
  fr: {
    dashboard: "Tableau de bord",
    markets: "Marchés",
    trade: "Commerce",
    social: "Social B2B",
    tv: "Kings Ark TV",
    bidding: "Enchères",
    account: "Compte",
    welcome: "Votre passerelle vers des opportunités mondiales de commerce et d'investissement",
    search: "Rechercher",
    settings: "Paramètres",
    language: "Langue",
    accessibility: "Accessibilité",
    darkMode: "Mode Sombre",
    lightMode: "Mode Clair",
  },
}

export function translate(key: string, language: SupportedLanguage = "en"): string {
  if (!translations[language]) {
    return key
  }

  return translations[language]?.[key] || key
}

export function detectBrowserLanguage(): SupportedLanguage {
  if (typeof window === "undefined") {
    return "en"
  }

  const browserLang = navigator.language.split("-")[0]

  // Check if the browser language is supported
  if (browserLang in translations) {
    return browserLang as SupportedLanguage
  }

  return "en"
}

export function applyTranslations(language: SupportedLanguage): void {
  if (!translations[language]) return

  const currentTranslations = translations[language] || {}

  // Translate elements with data-translate attribute
  document.querySelectorAll("[data-translate]").forEach((element) => {
    const key = element.getAttribute("data-translate")
    if (key && element instanceof HTMLElement) {
      element.textContent = currentTranslations[key] || key
    }
  })
}

