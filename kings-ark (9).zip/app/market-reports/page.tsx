"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Filter,
  Download,
  BarChart2,
  TrendingUp,
  TrendingDown,
  Calendar,
  Globe,
  FileText,
  ArrowLeft,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

// Sample market reports data
const marketReports = [
  {
    id: "mr-001",
    title: "Global Market Trends 2025",
    category: "Global",
    date: "March 15, 2025",
    summary: "Comprehensive analysis of global market trends and predictions for the coming year across major sectors.",
    image: "/placeholder.svg?height=200&width=400&text=Global+Market+Trends",
    trending: true,
    premium: false,
  },
  {
    id: "mr-002",
    title: "Technology Sector Analysis",
    category: "Technology",
    date: "March 10, 2025",
    summary:
      "In-depth analysis of the technology sector, including emerging trends, key players, and investment opportunities.",
    image: "/placeholder.svg?height=200&width=400&text=Technology+Sector",
    trending: true,
    premium: true,
  },
  {
    id: "mr-003",
    title: "Renewable Energy Market Outlook",
    category: "Energy",
    date: "March 5, 2025",
    summary:
      "Analysis of the renewable energy market, including solar, wind, and hydroelectric power trends and forecasts.",
    image: "/placeholder.svg?height=200&width=400&text=Renewable+Energy",
    trending: false,
    premium: false,
  },
  {
    id: "mr-004",
    title: "Healthcare Industry Report",
    category: "Healthcare",
    date: "February 28, 2025",
    summary:
      "Comprehensive report on the healthcare industry, including pharmaceuticals, medical devices, and healthcare services.",
    image: "/placeholder.svg?height=200&width=400&text=Healthcare+Industry",
    trending: false,
    premium: true,
  },
  {
    id: "mr-005",
    title: "Financial Services Trends",
    category: "Finance",
    date: "February 25, 2025",
    summary: "Analysis of trends in financial services, including banking, insurance, and fintech innovations.",
    image: "/placeholder.svg?height=200&width=400&text=Financial+Services",
    trending: false,
    premium: false,
  },
  {
    id: "mr-006",
    title: "Manufacturing Sector Outlook",
    category: "Manufacturing",
    date: "February 20, 2025",
    summary:
      "Outlook for the manufacturing sector, including automation, supply chain innovations, and sustainability practices.",
    image: "/placeholder.svg?height=200&width=400&text=Manufacturing+Sector",
    trending: false,
    premium: false,
  },
  {
    id: "mr-007",
    title: "Agricultural Market Analysis",
    category: "Agriculture",
    date: "February 15, 2025",
    summary:
      "Analysis of agricultural markets, including crop production, livestock, and agricultural technology trends.",
    image: "/placeholder.svg?height=200&width=400&text=Agricultural+Market",
    trending: false,
    premium: false,
  },
  {
    id: "mr-008",
    title: "Retail Industry Transformation",
    category: "Retail",
    date: "February 10, 2025",
    summary:
      "Analysis of the transformation in the retail industry, including e-commerce trends, omnichannel strategies, and consumer behavior shifts.",
    image: "/placeholder.svg?height=200&width=400&text=Retail+Industry",
    trending: false,
    premium: true,
  },
]

export default function MarketReportsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [filteredReports, setFilteredReports] = useState(marketReports)

  // Filter reports based on search query and active tab
  const handleSearch = (query: string) => {
    setSearchQuery(query)
    filterReports(query, activeTab)
  }

  const handleTabChange = (tab: string) => {
    setActiveTab(tab)
    filterReports(searchQuery, tab)
  }

  const filterReports = (query: string, tab: string) => {
    let filtered = marketReports.filter(
      (report) =>
        report.title.toLowerCase().includes(query.toLowerCase()) ||
        report.summary.toLowerCase().includes(query.toLowerCase()) ||
        report.category.toLowerCase().includes(query.toLowerCase()),
    )

    if (tab === "trending") {
      filtered = filtered.filter((report) => report.trending)
    } else if (tab === "premium") {
      filtered = filtered.filter((report) => report.premium)
    }

    setFilteredReports(filtered)
  }

  return (
    <div className="container mx-auto py-6 px-4 md:px-6 max-w-6xl">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Market Reports</h1>
          <p className="text-muted-foreground">Comprehensive market analysis and insights</p>
        </div>
        <Button className="gap-2">
          <Download className="h-4 w-4" />
          Download All Reports
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search reports by title, category, or content..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2 w-full sm:w-auto">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={handleTabChange}>
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Reports</TabsTrigger>
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="premium">Premium</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredReports.map((report) => (
              <Card key={report.id} className="flex flex-col h-full overflow-hidden">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src={report.image || "/placeholder.svg"}
                    alt={report.title}
                    fill
                    className="object-cover transition-transform hover:scale-105 glow-image"
                  />
                  {report.trending && (
                    <Badge className="absolute top-2 right-2 bg-primary">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Trending
                    </Badge>
                  )}
                  {report.premium && <Badge className="absolute top-2 left-2 bg-amber-500">Premium</Badge>}
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <Badge variant="outline">{report.category}</Badge>
                    <div className="flex items-center text-muted-foreground text-xs">
                      <Calendar className="h-3 w-3 mr-1" />
                      {report.date}
                    </div>
                  </div>
                  <CardTitle className="text-lg mt-2">{report.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground">{report.summary}</p>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button variant="outline" className="w-full">
                    Read Report
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {filteredReports.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No reports found</h3>
              <p className="text-muted-foreground">Try adjusting your search or filters</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="trending" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredReports.map((report) => (
              <Card key={report.id} className="flex flex-col h-full overflow-hidden">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src={report.image || "/placeholder.svg"}
                    alt={report.title}
                    fill
                    className="object-cover transition-transform hover:scale-105 glow-image"
                  />
                  <Badge className="absolute top-2 right-2 bg-primary">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    Trending
                  </Badge>
                  {report.premium && <Badge className="absolute top-2 left-2 bg-amber-500">Premium</Badge>}
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <Badge variant="outline">{report.category}</Badge>
                    <div className="flex items-center text-muted-foreground text-xs">
                      <Calendar className="h-3 w-3 mr-1" />
                      {report.date}
                    </div>
                  </div>
                  <CardTitle className="text-lg mt-2">{report.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground">{report.summary}</p>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button variant="outline" className="w-full">
                    Read Report
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {filteredReports.length === 0 && (
            <div className="text-center py-12">
              <TrendingUp className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No trending reports found</h3>
              <p className="text-muted-foreground">Check back later for new trending reports</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="premium" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredReports.map((report) => (
              <Card key={report.id} className="flex flex-col h-full overflow-hidden">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src={report.image || "/placeholder.svg"}
                    alt={report.title}
                    fill
                    className="object-cover transition-transform hover:scale-105 glow-image"
                  />
                  {report.trending && (
                    <Badge className="absolute top-2 right-2 bg-primary">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      Trending
                    </Badge>
                  )}
                  <Badge className="absolute top-2 left-2 bg-amber-500">Premium</Badge>
                </div>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <Badge variant="outline">{report.category}</Badge>
                    <div className="flex items-center text-muted-foreground text-xs">
                      <Calendar className="h-3 w-3 mr-1" />
                      {report.date}
                    </div>
                  </div>
                  <CardTitle className="text-lg mt-2">{report.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground">{report.summary}</p>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button className="w-full">Read Premium Report</Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {filteredReports.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No premium reports found</h3>
              <p className="text-muted-foreground">Upgrade to access premium market reports</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <div className="mt-12 border-t pt-8">
        <h2 className="text-2xl font-bold mb-6">Market Insights</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart2 className="h-5 w-5 text-primary" />
                Market Performance
              </CardTitle>
              <CardDescription>Key market indicators and performance metrics</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] relative">
              <div className="absolute inset-0 flex items-end justify-between p-4">
                {["Tech", "Finance", "Energy", "Health", "Mfg", "Agri", "Retail"].map((market, i) => {
                  const heights = [75, 60, 85, 50, 65, 40, 55]
                  const colors = [
                    "bg-blue-500",
                    "bg-green-500",
                    "bg-purple-500",
                    "bg-yellow-500",
                    "bg-red-500",
                    "bg-emerald-500",
                    "bg-pink-500",
                  ]
                  return (
                    <div key={market} className="flex flex-col items-center gap-2 w-[10%]">
                      <div
                        className={`w-full rounded-t-md transition-all duration-500 hover:opacity-80 ${colors[i]}`}
                        style={{ height: `${heights[i]}%` }}
                      ></div>
                      <span className="text-xs font-medium">{market}</span>
                    </div>
                  )
                })}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View Detailed Analysis
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-primary" />
                Regional Insights
              </CardTitle>
              <CardDescription>Market performance by region</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] relative">
              <div className="absolute inset-0 grid grid-cols-2 grid-rows-3 gap-2 p-4">
                {[
                  { region: "North America", growth: "+8.5%", trend: "up" },
                  { region: "Europe", growth: "+5.2%", trend: "up" },
                  { region: "Asia Pacific", growth: "+12.3%", trend: "up" },
                  { region: "Latin America", growth: "+3.8%", trend: "up" },
                  { region: "Africa", growth: "+7.1%", trend: "up" },
                  { region: "Middle East", growth: "-2.4%", trend: "down" },
                ].map((item, i) => (
                  <div
                    key={item.region}
                    className="border rounded-md p-3 flex flex-col justify-between transition-colors hover:bg-muted/50"
                  >
                    <h4 className="font-medium">{item.region}</h4>
                    <div className="flex items-center mt-2">
                      {item.trend === "up" ? (
                        <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      )}
                      <span className={item.trend === "up" ? "text-green-500" : "text-red-500"}>{item.growth}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View Regional Reports
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

