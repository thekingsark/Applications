"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { PlusCircle, Building, Users } from "lucide-react"
import SpinningCrownLogo from "@/components/spinning-crown-logo"
import { FundingInstitutionCard } from "./components/funding-institution-card"
import { FundingRequestCard } from "./components/funding-request-card"
import { FundingFilters } from "./components/funding-filters"
import { FundingChat } from "./components/funding-chat"
import { InstitutionDetails } from "./components/institution-details"
import { RequestDetails } from "./components/request-details"
import { FundingApplicationForm } from "./components/funding-application-form"
import { FundingRequestForm } from "./components/funding-request-form"
import type { FundingInstitution, FundingRequest } from "@/types/funding"
import { mockFundingInstitutions, mockFundingRequests } from "./mock-data"
import { getUniqueCountries, getUniqueRegions, getUniqueCategories, getUniqueIndustries } from "./utils"

export default function GlobalFundingsPage() {
  const [activeTab, setActiveTab] = useState("institutions")
  const [institutions, setInstitutions] = useState<FundingInstitution[]>(mockFundingInstitutions)
  const [filteredInstitutions, setFilteredInstitutions] = useState<FundingInstitution[]>(mockFundingInstitutions)
  const [requests, setRequests] = useState<FundingRequest[]>(mockFundingRequests)
  const [filteredRequests, setFilteredRequests] = useState<FundingRequest[]>(mockFundingRequests)

  const [selectedInstitution, setSelectedInstitution] = useState<FundingInstitution | null>(null)
  const [selectedRequest, setSelectedRequest] = useState<FundingRequest | null>(null)
  const [chatEntity, setChatEntity] = useState<{
    name: string
    logo?: string
    type: "business" | "institution"
  } | null>(null)

  const [showInstitutionDetails, setShowInstitutionDetails] = useState(false)
  const [showRequestDetails, setShowRequestDetails] = useState(false)
  const [showChat, setShowChat] = useState(false)
  const [showApplicationForm, setShowApplicationForm] = useState(false)
  const [showRequestForm, setShowRequestForm] = useState(false)

  // Get unique values for filters
  const countries = getUniqueCountries([...institutions, ...requests])
  const regions = getUniqueRegions([...institutions, ...requests])
  const categories = getUniqueCategories(institutions)
  const industries = getUniqueIndustries([...institutions, ...requests])

  const handleInstitutionFilter = (filters: any) => {
    let filtered = [...institutions]

    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase()
      filtered = filtered.filter(
        (inst) => inst.name.toLowerCase().includes(searchLower) || inst.description.toLowerCase().includes(searchLower),
      )
    }

    if (filters.region) {
      filtered = filtered.filter((inst) => inst.regions.includes(filters.region))
    }

    if (filters.country) {
      filtered = filtered.filter((inst) => inst.countries.includes(filters.country))
    }

    if (filters.categories.length > 0) {
      filtered = filtered.filter((inst) => filters.categories.some((cat: string) => inst.category.includes(cat)))
    }

    if (filters.industries.length > 0) {
      filtered = filtered.filter((inst) => filters.industries.some((ind: string) => inst.industries.includes(ind)))
    }

    if (filters.institutionTypes.length > 0) {
      filtered = filtered.filter((inst) => filters.institutionTypes.includes(inst.type))
    }

    if (filters.fundingRange) {
      filtered = filtered.filter(
        (inst) => inst.minimumFunding <= filters.fundingRange[1] && inst.maximumFunding >= filters.fundingRange[0],
      )
    }

    setFilteredInstitutions(filtered)
  }

  const handleRequestFilter = (filters: any) => {
    let filtered = [...requests]

    if (filters.searchTerm) {
      const searchLower = filters.searchTerm.toLowerCase()
      filtered = filtered.filter(
        (req) =>
          req.businessName.toLowerCase().includes(searchLower) || req.description.toLowerCase().includes(searchLower),
      )
    }

    if (filters.region) {
      filtered = filtered.filter((req) => req.region.toLowerCase().includes(filters.region.toLowerCase()))
    }

    if (filters.country) {
      filtered = filtered.filter((req) => req.country === filters.country)
    }

    if (filters.industries.length > 0) {
      filtered = filtered.filter((req) => filters.industries.some((ind: string) => req.industry.includes(ind)))
    }

    if (filters.fundingRange) {
      filtered = filtered.filter(
        (req) => req.fundingAmount >= filters.fundingRange[0] && req.fundingAmount <= filters.fundingRange[1],
      )
    }

    setFilteredRequests(filtered)
  }

  const handleInstitutionContact = (institution: FundingInstitution) => {
    setSelectedInstitution(institution)
    setShowInstitutionDetails(true)
  }

  const handleInstitutionChat = (institution: FundingInstitution) => {
    setChatEntity({
      name: institution.name,
      logo: institution.logo,
      type: "institution",
    })
    setShowChat(true)
  }

  const handleRequestContact = (request: FundingRequest) => {
    setSelectedRequest(request)
    setShowRequestDetails(true)
  }

  const handleRequestChat = (request: FundingRequest) => {
    setChatEntity({
      name: request.businessName,
      logo: request.logo,
      type: "business",
    })
    setShowChat(true)
  }

  const handleApplyForFunding = (institution: FundingInstitution) => {
    setSelectedInstitution(institution)
    setShowApplicationForm(true)
  }

  const handleApplicationSubmit = (formData: any) => {
    console.log("Application submitted:", formData)
    // Here you would typically send this data to your backend
    alert("Your funding application has been submitted successfully!")
  }

  const handleRequestSubmit = (formData: any) => {
    console.log("Funding request submitted:", formData)

    // Create a new request object
    const newRequest: FundingRequest = {
      id: `req-${Date.now()}`,
      businessName: formData.businessName,
      businessType: formData.businessType,
      industry: formData.industry,
      description: formData.description,
      logo: formData.logo ? URL.createObjectURL(formData.logo) : undefined,
      website: formData.website,
      foundedYear: Number.parseInt(formData.foundedYear),
      headquarters: formData.headquarters,
      country: formData.country,
      region: formData.region,
      employeeCount: formData.employeeCount,
      annualRevenue: formData.annualRevenue,
      fundingAmount: Number.parseInt(formData.fundingAmount),
      fundingPurpose: formData.fundingPurpose,
      timeframe: formData.timeframe,
      equityOffered: formData.equityOffered ? Number.parseInt(formData.equityOffered) : undefined,
      collateralAvailable: formData.collateralAvailable,
      businessPlan: formData.businessPlan,
      financialStatements: formData.financialStatements,
      contactPerson: formData.contactPerson,
      contactEmail: formData.contactEmail,
      contactPhone: formData.contactPhone,
      postedDate: new Date(),
      status: "active",
    }

    // Add the new request to the list
    const updatedRequests = [newRequest, ...requests]
    setRequests(updatedRequests)
    setFilteredRequests(updatedRequests)

    alert("Your funding request has been posted successfully!")
  }

  return (
    <div className="container mx-auto py-6 px-4 max-w-7xl">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <SpinningCrownLogo size={40} />
          <h1 className="text-3xl font-bold">Kings Global Fundings</h1>
        </div>
        <Button onClick={() => setShowRequestForm(true)}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Post Funding Request
        </Button>
      </div>

      <Tabs defaultValue="institutions" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="flex justify-between items-center">
          <TabsList>
            <TabsTrigger value="institutions" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              Funding Institutions
            </TabsTrigger>
            <TabsTrigger value="requests" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Funding Requests
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="institutions" className="space-y-6">
          <FundingFilters
            type="institutions"
            countries={countries}
            regions={regions}
            categories={categories}
            industries={industries}
            onFilterChange={handleInstitutionFilter}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredInstitutions.length > 0 ? (
              filteredInstitutions.map((institution) => (
                <FundingInstitutionCard
                  key={institution.id}
                  institution={institution}
                  onContactClick={handleInstitutionContact}
                  onChatClick={handleInstitutionChat}
                />
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-muted-foreground">No funding institutions match your filters.</p>
                <Button variant="link" onClick={() => handleInstitutionFilter({})} className="mt-2">
                  Clear filters
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="requests" className="space-y-6">
          <FundingFilters
            type="requests"
            countries={countries}
            regions={regions}
            categories={categories}
            industries={industries}
            onFilterChange={handleRequestFilter}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRequests.length > 0 ? (
              filteredRequests.map((request) => (
                <FundingRequestCard
                  key={request.id}
                  request={request}
                  onContactClick={handleRequestContact}
                  onChatClick={handleRequestChat}
                />
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-muted-foreground">No funding requests match your filters.</p>
                <Button variant="link" onClick={() => handleRequestFilter({})} className="mt-2">
                  Clear filters
                </Button>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Details and Forms */}
      {selectedInstitution && (
        <InstitutionDetails
          institution={selectedInstitution}
          isOpen={showInstitutionDetails}
          onClose={() => setShowInstitutionDetails(false)}
          onApply={handleApplyForFunding}
          onChat={handleInstitutionChat}
        />
      )}

      {selectedRequest && (
        <RequestDetails
          request={selectedRequest}
          isOpen={showRequestDetails}
          onClose={() => setShowRequestDetails(false)}
          onContact={handleRequestChat}
        />
      )}

      {selectedInstitution && (
        <FundingApplicationForm
          institution={selectedInstitution}
          isOpen={showApplicationForm}
          onClose={() => setShowApplicationForm(false)}
          onSubmit={handleApplicationSubmit}
        />
      )}

      <FundingRequestForm
        isOpen={showRequestForm}
        onClose={() => setShowRequestForm(false)}
        onSubmit={handleRequestSubmit}
      />

      {chatEntity && (
        <FundingChat
          entityName={chatEntity.name}
          entityLogo={chatEntity.logo}
          entityType={chatEntity.type}
          isOpen={showChat}
          onClose={() => setShowChat(false)}
        />
      )}
    </div>
  )
}

