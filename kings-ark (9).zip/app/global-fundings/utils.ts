export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  }).format(date)
}

export function getUniqueCountries(items: Array<{ countries?: string[]; country?: string }>): string[] {
  const countries = new Set<string>()

  items.forEach((item) => {
    if (item.countries) {
      item.countries.forEach((country) => countries.add(country))
    }
    if (item.country) {
      countries.add(item.country)
    }
  })

  return Array.from(countries).sort()
}

export function getUniqueRegions(items: Array<{ regions?: string[]; region?: string }>): string[] {
  const regions = new Set<string>()

  items.forEach((item) => {
    if (item.regions) {
      item.regions.forEach((region) => regions.add(region))
    }
    if (item.region) {
      regions.add(item.region)
    }
  })

  return Array.from(regions).sort()
}

export function getUniqueCategories(items: Array<{ category?: string[] }>): string[] {
  const categories = new Set<string>()

  items.forEach((item) => {
    if (item.category) {
      item.category.forEach((cat) => categories.add(cat))
    }
  })

  return Array.from(categories).sort()
}

export function getUniqueIndustries(items: Array<{ industries?: string[]; industry?: string[] }>): string[] {
  const industries = new Set<string>()

  items.forEach((item) => {
    if (item.industries) {
      item.industries.forEach((ind) => industries.add(ind))
    }
    if (item.industry) {
      item.industry.forEach((ind) => industries.add(ind))
    }
  })

  return Array.from(industries).sort()
}

