"use client"

import { useState } from "react"
import Image from "next/image"
import { Calendar, MessageCircle, Info, Building } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { FundingRequest } from "@/types/funding"
import { formatCurrency, formatDate } from "../utils"

interface FundingRequestCardProps {
  request: FundingRequest
  onContactClick: (request: FundingRequest) => void
  onChatClick: (request: FundingRequest) => void
}

export function FundingRequestCard({ request, onContactClick, onChatClick }: FundingRequestCardProps) {
  const [expanded, setExpanded] = useState(false)

  return (
    <Card className="h-full flex flex-col overflow-hidden transition-all duration-200 hover:shadow-md hover:border-primary/50">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="relative h-12 w-12 overflow-hidden rounded-md">
              <Image
                src={request.logo || "/placeholder.svg?height=80&width=80"}
                alt={request.businessName}
                fill
                className="object-cover"
              />
            </div>
            <div>
              <CardTitle className="text-lg">{request.businessName}</CardTitle>
              <CardDescription className="flex items-center gap-1">
                <Building className="h-3 w-3" />
                {request.businessType}
              </CardDescription>
            </div>
          </div>
          <Badge
            variant={request.status === "active" ? "default" : request.status === "funded" ? "success" : "secondary"}
          >
            {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <div className="space-y-3">
          <div className="flex flex-wrap gap-1 mb-2">
            {request.industry.slice(0, 3).map((ind) => (
              <Badge key={ind} variant="secondary" className="capitalize">
                {ind}
              </Badge>
            ))}
            {request.industry.length > 3 && <Badge variant="outline">+{request.industry.length - 3}</Badge>}
          </div>

          <div className="flex items-center text-sm text-muted-foreground gap-1 mb-2">
            <Calendar className="h-3 w-3" />
            <span>Posted: {formatDate(request.postedDate)}</span>
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2">{request.description}</p>

          <div className="bg-muted/50 p-2 rounded-md">
            <div className="flex justify-between">
              <span className="text-sm font-medium">Funding Needed:</span>
              <span className="text-sm font-bold">{formatCurrency(request.fundingAmount)}</span>
            </div>
          </div>

          <div className={`space-y-3 transition-all duration-300 ${expanded ? "block" : "hidden"}`}>
            <div>
              <h4 className="text-sm font-medium mb-1">Location</h4>
              <p className="text-sm">
                {request.headquarters}, {request.country} ({request.region})
              </p>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Funding Purpose</h4>
              <p className="text-sm">{request.fundingPurpose}</p>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Timeframe</h4>
              <p className="text-sm">{request.timeframe}</p>
            </div>

            {request.equityOffered && (
              <div>
                <h4 className="text-sm font-medium mb-1">Equity Offered</h4>
                <p className="text-sm">{request.equityOffered}%</p>
              </div>
            )}

            <div>
              <h4 className="text-sm font-medium mb-1">Company Size</h4>
              <p className="text-sm">
                {request.employeeCount} employees
                {request.annualRevenue ? `, ${request.annualRevenue} annual revenue` : ""}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-2 pt-2">
        <Button variant="ghost" size="sm" className="w-full justify-center" onClick={() => setExpanded(!expanded)}>
          {expanded ? "Show Less" : "Show More"}
        </Button>
        <div className="flex gap-2 w-full">
          <Button variant="outline" size="sm" className="flex-1" onClick={() => onContactClick(request)}>
            <Info className="mr-2 h-4 w-4" />
            Details
          </Button>
          <Button variant="default" size="sm" className="flex-1" onClick={() => onChatClick(request)}>
            <MessageCircle className="mr-2 h-4 w-4" />
            Contact
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

