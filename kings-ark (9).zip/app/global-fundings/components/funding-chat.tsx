"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, X, Paperclip } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { FundingMessage } from "@/types/funding"

interface FundingChatProps {
  entityName: string
  entityLogo?: string
  entityType: "business" | "institution"
  isOpen: boolean
  onClose: () => void
}

export function FundingChat({ entityName, entityLogo, entityType, isOpen, onClose }: FundingChatProps) {
  const [messages, setMessages] = useState<FundingMessage[]>([
    {
      id: "welcome",
      senderId: entityType === "business" ? "institution" : "business",
      senderType: entityType === "business" ? "institution" : "business",
      senderName: entityName,
      receiverId: "user",
      receiverType: entityType === "business" ? "business" : "institution",
      receiverName: "You",
      content: `Hello! Thanks for reaching out to ${entityName}. How can we help you today?`,
      timestamp: new Date(),
      read: true,
    },
  ])
  const [newMessage, setNewMessage] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages, isOpen])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    // Add user message
    const userMessage: FundingMessage = {
      id: `msg-${Date.now()}`,
      senderId: "user",
      senderType: entityType === "business" ? "business" : "institution",
      senderName: "You",
      receiverId: entityType === "business" ? "business-id" : "institution-id",
      receiverType: entityType === "business" ? "business" : "institution",
      receiverName: entityName,
      content: newMessage,
      timestamp: new Date(),
      read: true,
    }

    setMessages((prev) => [...prev, userMessage])
    setNewMessage("")

    // Simulate response after a delay
    setTimeout(() => {
      const responseMessage: FundingMessage = {
        id: `msg-${Date.now() + 1}`,
        senderId: entityType === "business" ? "business-id" : "institution-id",
        senderType: entityType === "business" ? "business" : "institution",
        senderName: entityName,
        receiverId: "user",
        receiverType: entityType === "business" ? "institution" : "business",
        receiverName: "You",
        content: getAutoResponse(newMessage),
        timestamp: new Date(),
        read: true,
      }
      setMessages((prev) => [...prev, responseMessage])
    }, 1000)
  }

  const getAutoResponse = (message: string): string => {
    const lowerMessage = message.toLowerCase()

    if (lowerMessage.includes("funding") || lowerMessage.includes("finance")) {
      return `Thank you for your inquiry about funding. At ${entityName}, we offer various funding solutions tailored to your needs. Could you please provide more details about your specific requirements?`
    } else if (lowerMessage.includes("interest") || lowerMessage.includes("rate")) {
      return "Our interest rates vary based on the funding type, amount, term, and risk assessment. We'd be happy to provide you with a personalized quote after learning more about your business needs."
    } else if (lowerMessage.includes("document") || lowerMessage.includes("apply")) {
      return "To apply, you'll need to submit business registration documents, financial statements for the past 2-3 years, a business plan, and proof of collateral if applicable. Would you like me to send you our complete application checklist?"
    } else if (lowerMessage.includes("time") || lowerMessage.includes("process")) {
      return "Our funding process typically takes 2-4 weeks from application to disbursement, depending on the complexity and completeness of your application. We strive to make the process as efficient as possible."
    } else {
      return "Thank you for your message. A representative from our team will review your inquiry and get back to you shortly. Is there anything specific you'd like to know about our funding solutions in the meantime?"
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed bottom-4 right-4 w-80 sm:w-96 h-[500px] bg-background border rounded-lg shadow-lg flex flex-col z-50">
      <div className="p-3 border-b flex items-center justify-between bg-primary/10">
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarImage src={entityLogo || "/placeholder.svg?height=32&width=32"} alt={entityName} />
            <AvatarFallback>{entityName.substring(0, 2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="text-sm font-medium">{entityName}</h3>
            <p className="text-xs text-muted-foreground">
              {entityType === "business" ? "Business" : "Funding Institution"}
            </p>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-grow p-3">
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.senderName === "You" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.senderName === "You" ? "bg-primary text-primary-foreground" : "bg-muted"
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <form onSubmit={handleSendMessage} className="p-3 border-t flex gap-2">
        <Button type="button" variant="ghost" size="icon" className="shrink-0" title="Attach file">
          <Paperclip className="h-4 w-4" />
        </Button>
        <Input
          placeholder="Type your message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          className="flex-grow"
        />
        <Button type="submit" size="icon" className="shrink-0">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  )
}

