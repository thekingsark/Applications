"use client"

import type React from "react"

import { useState } from "react"
import { X, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Checkbox } from "@/components/ui/checkbox"
import { fundingRegions } from "../mock-data"

interface FundingRequestFormProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (formData: any) => void
}

export function FundingRequestForm({ isOpen, onClose, onSubmit }: FundingRequestFormProps) {
  const [formData, setFormData] = useState({
    businessName: "",
    businessType: "",
    industry: [] as string[],
    description: "",
    website: "",
    foundedYear: "",
    headquarters: "",
    country: "",
    region: "",
    employeeCount: "",
    annualRevenue: "",
    fundingAmount: "",
    fundingPurpose: "",
    timeframe: "",
    equityOffered: "",
    collateralAvailable: "",
    businessPlan: false,
    financialStatements: false,
    contactPerson: "",
    contactEmail: "",
    contactPhone: "",
    logo: null as File | null,
  })

  const [selectedIndustries, setSelectedIndustries] = useState<string[]>([])
  const [customIndustry, setCustomIndustry] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData((prev) => ({ ...prev, logo: e.target.files![0] }))
    }
  }

  const addIndustry = () => {
    if (customIndustry && !selectedIndustries.includes(customIndustry)) {
      setSelectedIndustries([...selectedIndustries, customIndustry])
      setFormData((prev) => ({
        ...prev,
        industry: [...prev.industry, customIndustry],
      }))
      setCustomIndustry("")
    }
  }

  const removeIndustry = (industry: string) => {
    setSelectedIndustries(selectedIndustries.filter((ind) => ind !== industry))
    setFormData((prev) => ({
      ...prev,
      industry: prev.industry.filter((ind) => ind !== industry),
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
    onClose()
  }

  const industryOptions = [
    "Technology",
    "Healthcare",
    "Financial Services",
    "Manufacturing",
    "Retail",
    "Energy",
    "Education",
    "Agriculture",
    "Transportation",
    "Construction",
    "Real Estate",
    "Media & Entertainment",
    "Hospitality",
    "Professional Services",
    "Telecommunications",
  ]

  const businessTypeOptions = [
    "Startup",
    "Small Business",
    "Medium Enterprise",
    "Large Corporation",
    "Nonprofit",
    "Sole Proprietorship",
    "Partnership",
    "LLC",
    "Corporation",
  ]

  const timeframeOptions = [
    "Immediate (< 1 month)",
    "Short-term (1-3 months)",
    "Medium-term (3-6 months)",
    "Long-term (6-12 months)",
    "Strategic (> 12 months)",
  ]

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-background border rounded-lg shadow-lg w-full max-w-3xl max-h-[90vh] flex flex-col">
        <div className="p-4 border-b flex items-center justify-between sticky top-0 bg-background z-10">
          <h2 className="text-xl font-bold">Create Funding Request</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <ScrollArea className="flex-grow p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="logo">Business Logo</Label>
              <div className="border-2 border-dashed rounded-md p-4 text-center">
                <Upload className="h-6 w-6 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground mb-2">Upload your business logo</p>
                <Input id="logo" type="file" accept="image/*" className="hidden" onChange={handleLogoChange} />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => document.getElementById("logo")?.click()}
                >
                  Select Logo
                </Button>
                {formData.logo && <p className="text-sm mt-2">Selected: {formData.logo.name}</p>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="businessName">Business Name *</Label>
                <Input
                  id="businessName"
                  name="businessName"
                  value={formData.businessName}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="businessType">Business Type *</Label>
                <Select
                  value={formData.businessType}
                  onValueChange={(value) => handleSelectChange("businessType", value)}
                  required
                >
                  <SelectTrigger id="businessType">
                    <SelectValue placeholder="Select business type" />
                  </SelectTrigger>
                  <SelectContent>
                    {businessTypeOptions.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="foundedYear">Year Founded *</Label>
                <Input
                  id="foundedYear"
                  name="foundedYear"
                  type="number"
                  min="1900"
                  max={new Date().getFullYear()}
                  value={formData.foundedYear}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Business Website</Label>
                <Input id="website" name="website" value={formData.website} onChange={handleChange} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="region">Region *</Label>
                <Select value={formData.region} onValueChange={(value) => handleSelectChange("region", value)} required>
                  <SelectTrigger id="region">
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    {fundingRegions.map((region) => (
                      <SelectItem key={region.id} value={region.name}>
                        {region.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="country">Country *</Label>
                <Select
                  value={formData.country}
                  onValueChange={(value) => handleSelectChange("country", value)}
                  required
                >
                  <SelectTrigger id="country">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    {formData.region
                      ? fundingRegions
                          .find((r) => r.name === formData.region)
                          ?.countries.map((country) => (
                            <SelectItem key={country} value={country}>
                              {country}
                            </SelectItem>
                          ))
                      : []}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="headquarters">Headquarters City *</Label>
                <Input
                  id="headquarters"
                  name="headquarters"
                  value={formData.headquarters}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="employeeCount">Number of Employees *</Label>
                <Select
                  value={formData.employeeCount}
                  onValueChange={(value) => handleSelectChange("employeeCount", value)}
                  required
                >
                  <SelectTrigger id="employeeCount">
                    <SelectValue placeholder="Select employee count" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1-10">1-10</SelectItem>
                    <SelectItem value="11-50">11-50</SelectItem>
                    <SelectItem value="51-200">51-200</SelectItem>
                    <SelectItem value="201-500">201-500</SelectItem>
                    <SelectItem value="501+">501+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="annualRevenue">Annual Revenue</Label>
                <Select
                  value={formData.annualRevenue}
                  onValueChange={(value) => handleSelectChange("annualRevenue", value)}
                >
                  <SelectTrigger id="annualRevenue">
                    <SelectValue placeholder="Select annual revenue" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="< $100K">Less than $100K</SelectItem>
                    <SelectItem value="$100K - $500K">$100K - $500K</SelectItem>
                    <SelectItem value="$500K - $1M">$500K - $1M</SelectItem>
                    <SelectItem value="$1M - $5M">$1M - $5M</SelectItem>
                    <SelectItem value="$5M - $10M">$5M - $10M</SelectItem>
                    <SelectItem value="$10M - $50M">$10M - $50M</SelectItem>
                    <SelectItem value="$50M+">$50M+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Industry *</Label>
              <div className="flex gap-2">
                <Select
                  value=""
                  onValueChange={(value) => {
                    if (value && !selectedIndustries.includes(value)) {
                      setSelectedIndustries([...selectedIndustries, value])
                      setFormData((prev) => ({
                        ...prev,
                        industry: [...prev.industry, value],
                      }))
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {industryOptions.map((industry) => (
                      <SelectItem key={industry} value={industry}>
                        {industry}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Input
                    placeholder="Custom industry"
                    value={customIndustry}
                    onChange={(e) => setCustomIndustry(e.target.value)}
                  />
                  <Button type="button" onClick={addIndustry}>
                    Add
                  </Button>
                </div>
              </div>
              {selectedIndustries.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedIndustries.map((industry) => (
                    <div key={industry} className="bg-muted px-3 py-1 rounded-full text-sm flex items-center gap-1">
                      {industry}
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-4 w-4 p-0"
                        onClick={() => removeIndustry(industry)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Business Description *</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                rows={4}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fundingAmount">Funding Amount Requested (USD) *</Label>
                <Input
                  id="fundingAmount"
                  name="fundingAmount"
                  type="number"
                  min="10000"
                  value={formData.fundingAmount}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="timeframe">Funding Timeframe *</Label>
                <Select
                  value={formData.timeframe}
                  onValueChange={(value) => handleSelectChange("timeframe", value)}
                  required
                >
                  <SelectTrigger id="timeframe">
                    <SelectValue placeholder="Select timeframe" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeframeOptions.map((timeframe) => (
                      <SelectItem key={timeframe} value={timeframe}>
                        {timeframe}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="equityOffered">Equity Offered (%)</Label>
                <Input
                  id="equityOffered"
                  name="equityOffered"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.equityOffered}
                  onChange={handleChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="collateralAvailable">Collateral Available</Label>
                <Input
                  id="collateralAvailable"
                  name="collateralAvailable"
                  value={formData.collateralAvailable}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="fundingPurpose">Funding Purpose *</Label>
              <Textarea
                id="fundingPurpose"
                name="fundingPurpose"
                value={formData.fundingPurpose}
                onChange={handleChange}
                required
                rows={3}
              />
            </div>

            <div className="space-y-4">
              <Label>Available Documentation</Label>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="businessPlan"
                  checked={formData.businessPlan}
                  onCheckedChange={(checked) => handleCheckboxChange("businessPlan", checked as boolean)}
                />
                <Label htmlFor="businessPlan" className="text-sm cursor-pointer">
                  Business Plan
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="financialStatements"
                  checked={formData.financialStatements}
                  onCheckedChange={(checked) => handleCheckboxChange("financialStatements", checked as boolean)}
                />
                <Label htmlFor="financialStatements" className="text-sm cursor-pointer">
                  Financial Statements
                </Label>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="contactPerson">Contact Person *</Label>
                <Input
                  id="contactPerson"
                  name="contactPerson"
                  value={formData.contactPerson}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contactEmail">Contact Email *</Label>
                <Input
                  id="contactEmail"
                  name="contactEmail"
                  type="email"
                  value={formData.contactEmail}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="contactPhone">Contact Phone *</Label>
                <Input
                  id="contactPhone"
                  name="contactPhone"
                  value={formData.contactPhone}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
          </form>
        </ScrollArea>

        <div className="p-4 border-t flex flex-wrap gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>Submit Request</Button>
        </div>
      </div>
    </div>
  )
}

