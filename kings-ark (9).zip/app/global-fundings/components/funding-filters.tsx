"use client"

import type React from "react"

import { useState } from "react"
import { Search, Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetFooter,
  SheetClose,
} from "@/components/ui/sheet"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { formatCurrency } from "../utils"

interface FundingFiltersProps {
  type: "institutions" | "requests"
  countries: string[]
  regions: string[]
  categories: string[]
  industries: string[]
  onFilterChange: (filters: any) => void
}

export function FundingFilters({
  type,
  countries,
  regions,
  categories,
  industries,
  onFilterChange,
}: FundingFiltersProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedRegion, setSelectedRegion] = useState<string>("")
  const [selectedCountry, setSelectedCountry] = useState<string>("")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedIndustries, setSelectedIndustries] = useState<string[]>([])
  const [fundingRange, setFundingRange] = useState<[number, number]>([0, 10000000])
  const [institutionTypes, setInstitutionTypes] = useState<string[]>([])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    applyFilters()
  }

  const applyFilters = () => {
    onFilterChange({
      searchTerm,
      region: selectedRegion,
      country: selectedCountry,
      categories: selectedCategories,
      industries: selectedIndustries,
      fundingRange,
      institutionTypes,
    })
  }

  const resetFilters = () => {
    setSearchTerm("")
    setSelectedRegion("")
    setSelectedCountry("")
    setSelectedCategories([])
    setSelectedIndustries([])
    setFundingRange([0, 10000000])
    setInstitutionTypes([])

    onFilterChange({
      searchTerm: "",
      region: "",
      country: "",
      categories: [],
      industries: [],
      fundingRange: [0, 10000000],
      institutionTypes: [],
    })
  }

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const toggleIndustry = (industry: string) => {
    setSelectedIndustries((prev) =>
      prev.includes(industry) ? prev.filter((i) => i !== industry) : [...prev, industry],
    )
  }

  const toggleInstitutionType = (instType: string) => {
    setInstitutionTypes((prev) => (prev.includes(instType) ? prev.filter((t) => t !== instType) : [...prev, instType]))
  }

  const institutionTypeOptions = [
    { value: "bank", label: "Bank" },
    { value: "venture_capital", label: "Venture Capital" },
    { value: "angel_investor", label: "Angel Investor" },
    { value: "government", label: "Government" },
    { value: "crowdfunding", label: "Crowdfunding" },
    { value: "private_equity", label: "Private Equity" },
    { value: "other", label: "Other" },
  ]

  return (
    <div className="space-y-4">
      <form onSubmit={handleSearch} className="flex gap-2">
        <div className="relative flex-grow">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder={`Search ${type === "institutions" ? "funding institutions" : "funding requests"}...`}
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" size="icon" type="button">
              <Filter className="h-4 w-4" />
            </Button>
          </SheetTrigger>
          <SheetContent className="overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Filter Options</SheetTitle>
              <SheetDescription>Refine your search with the following filters</SheetDescription>
            </SheetHeader>
            <div className="py-4 space-y-6">
              <div className="space-y-2">
                <Label>Region</Label>
                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Regions</SelectItem>
                    {regions.map((region) => (
                      <SelectItem key={region} value={region}>
                        {region.replace("-", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Country</Label>
                <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Countries</SelectItem>
                    {countries.map((country) => (
                      <SelectItem key={country} value={country}>
                        {country}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Funding Range</Label>
                <div className="pt-4 px-2">
                  <Slider
                    defaultValue={fundingRange}
                    max={10000000}
                    step={100000}
                    onValueChange={(value) => setFundingRange(value as [number, number])}
                  />
                  <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                    <span>{formatCurrency(fundingRange[0])}</span>
                    <span>{formatCurrency(fundingRange[1])}</span>
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Categories</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {categories.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={`category-${category}`}
                        checked={selectedCategories.includes(category)}
                        onCheckedChange={() => toggleCategory(category)}
                      />
                      <Label htmlFor={`category-${category}`} className="text-sm capitalize cursor-pointer">
                        {category.replace("-", " ")}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label>Industries</Label>
                <div className="grid grid-cols-2 gap-2 mt-2">
                  {industries.slice(0, 10).map((industry) => (
                    <div key={industry} className="flex items-center space-x-2">
                      <Checkbox
                        id={`industry-${industry}`}
                        checked={selectedIndustries.includes(industry)}
                        onCheckedChange={() => toggleIndustry(industry)}
                      />
                      <Label htmlFor={`industry-${industry}`} className="text-sm cursor-pointer">
                        {industry}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {type === "institutions" && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <Label>Institution Type</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {institutionTypeOptions.map((option) => (
                        <div key={option.value} className="flex items-center space-x-2">
                          <Checkbox
                            id={`type-${option.value}`}
                            checked={institutionTypes.includes(option.value)}
                            onCheckedChange={() => toggleInstitutionType(option.value)}
                          />
                          <Label htmlFor={`type-${option.value}`} className="text-sm cursor-pointer">
                            {option.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
            <SheetFooter>
              <Button variant="outline" onClick={resetFilters} type="button">
                Reset Filters
              </Button>
              <SheetClose asChild>
                <Button onClick={applyFilters}>Apply Filters</Button>
              </SheetClose>
            </SheetFooter>
          </SheetContent>
        </Sheet>
        <Button type="submit">Search</Button>
      </form>

      {/* Active filters */}
      <div className="flex flex-wrap gap-2">
        {selectedRegion && (
          <Badge variant="secondary" className="flex items-center gap-1">
            Region: {selectedRegion.replace("-", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
            <X className="h-3 w-3 cursor-pointer" onClick={() => setSelectedRegion("")} />
          </Badge>
        )}
        {selectedCountry && (
          <Badge variant="secondary" className="flex items-center gap-1">
            Country: {selectedCountry}
            <X className="h-3 w-3 cursor-pointer" onClick={() => setSelectedCountry("")} />
          </Badge>
        )}
        {selectedCategories.map((category) => (
          <Badge key={category} variant="secondary" className="flex items-center gap-1 capitalize">
            {category.replace("-", " ")}
            <X className="h-3 w-3 cursor-pointer" onClick={() => toggleCategory(category)} />
          </Badge>
        ))}
        {selectedIndustries.map((industry) => (
          <Badge key={industry} variant="secondary" className="flex items-center gap-1">
            {industry}
            <X className="h-3 w-3 cursor-pointer" onClick={() => toggleIndustry(industry)} />
          </Badge>
        ))}
        {institutionTypes.map((type) => (
          <Badge key={type} variant="secondary" className="flex items-center gap-1 capitalize">
            {type.replace("_", " ")}
            <X className="h-3 w-3 cursor-pointer" onClick={() => toggleInstitutionType(type)} />
          </Badge>
        ))}
        {(selectedRegion ||
          selectedCountry ||
          selectedCategories.length > 0 ||
          selectedIndustries.length > 0 ||
          institutionTypes.length > 0) && (
          <Button variant="ghost" size="sm" onClick={resetFilters} className="h-6 px-2">
            Clear All
          </Button>
        )}
      </div>
    </div>
  )
}

