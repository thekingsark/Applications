"use client"

import { X, Globe, Mail, Phone, Calendar, DollarSign, Clock, Building, Users, Briefcase, FileText } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import type { FundingRequest } from "@/types/funding"
import { formatCurrency, formatDate } from "../utils"

interface RequestDetailsProps {
  request: FundingRequest
  isOpen: boolean
  onClose: () => void
  onContact: (request: FundingRequest) => void
}

export function RequestDetails({ request, isOpen, onClose, onContact }: RequestDetailsProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-background border rounded-lg shadow-lg w-full max-w-3xl max-h-[90vh] flex flex-col">
        <div className="p-4 border-b flex items-center justify-between sticky top-0 bg-background z-10">
          <h2 className="text-xl font-bold">{request.businessName}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <ScrollArea className="flex-grow p-6">
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-6">
              <div className="relative h-32 w-32 overflow-hidden rounded-md shrink-0 mx-auto sm:mx-0">
                <Image
                  src={request.logo || "/placeholder.svg?height=80&width=80"}
                  alt={request.businessName}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="space-y-2 flex-grow">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">{request.businessName}</h3>
                  <Badge
                    variant={
                      request.status === "active" ? "default" : request.status === "funded" ? "success" : "secondary"
                    }
                  >
                    {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                  </Badge>
                </div>
                <p className="text-muted-foreground">{request.description}</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="bg-primary/10">
                    {request.businessType}
                  </Badge>
                  {request.industry.map((ind) => (
                    <Badge key={ind} variant="secondary">
                      {ind}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Contact Information</h4>
                  <div className="space-y-2">
                    {request.website && (
                      <div className="flex items-center gap-2">
                        <Globe className="h-4 w-4 text-muted-foreground" />
                        <a
                          href={request.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm hover:underline text-primary"
                        >
                          {request.website.replace(/(^\w+:|^)\/\//, "")}
                        </a>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <a href={`mailto:${request.contactEmail}`} className="text-sm hover:underline text-primary">
                        {request.contactEmail}
                      </a>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <a href={`tel:${request.contactPhone}`} className="text-sm hover:underline text-primary">
                        {request.contactPhone}
                      </a>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Location</h4>
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {request.headquarters}, {request.country} ({request.region})
                    </span>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Established</h4>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{request.foundedYear}</span>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Company Size</h4>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{request.employeeCount} employees</span>
                  </div>
                  {request.annualRevenue && (
                    <div className="mt-1 text-sm text-muted-foreground">Annual Revenue: {request.annualRevenue}</div>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Funding Request</h4>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-bold">{formatCurrency(request.fundingAmount)}</span>
                  </div>
                  <div className="mt-1 text-sm">
                    <span className="font-medium">Purpose:</span> {request.fundingPurpose}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Timeframe</h4>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{request.timeframe}</span>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Posted</h4>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{formatDate(request.postedDate)}</span>
                  </div>
                </div>

                {request.equityOffered && (
                  <div>
                    <h4 className="text-sm font-medium text-muted-foreground mb-2">Equity Offered</h4>
                    <span className="text-sm">{request.equityOffered}%</span>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {request.collateralAvailable && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">Collateral Available</h4>
                <p className="text-sm">{request.collateralAvailable}</p>
              </div>
            )}

            <div className="space-y-2">
              <h4 className="text-sm font-medium text-muted-foreground">Documentation Available</h4>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-1">
                  <Briefcase
                    className={`h-4 w-4 ${request.businessPlan ? "text-green-500" : "text-muted-foreground"}`}
                  />
                  <span className="text-sm">Business Plan</span>
                </div>
                <div className="flex items-center gap-1">
                  <FileText
                    className={`h-4 w-4 ${request.financialStatements ? "text-green-500" : "text-muted-foreground"}`}
                  />
                  <span className="text-sm">Financial Statements</span>
                </div>
              </div>
            </div>

            {request.previousFunding && request.previousFunding.length > 0 && (
              <div className="space-y-4">
                <h4 className="text-sm font-medium text-muted-foreground">Previous Funding</h4>
                <ul className="list-disc pl-5 space-y-1">
                  {request.previousFunding.map((funding, index) => (
                    <li key={index} className="text-sm">
                      {funding}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {request.creditScore && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">Credit Score</h4>
                <p className="text-sm">{request.creditScore}</p>
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="p-4 border-t flex flex-wrap gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <Button onClick={() => onContact(request)}>Contact Business</Button>
        </div>
      </div>
    </div>
  )
}

