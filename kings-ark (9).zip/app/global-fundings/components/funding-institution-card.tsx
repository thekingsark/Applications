"use client"

import { useState } from "react"
import Image from "next/image"
import { MessageCircle, Info, Star, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { FundingInstitution } from "@/types/funding"
import { formatCurrency } from "../utils"

interface FundingInstitutionCardProps {
  institution: FundingInstitution
  onContactClick: (institution: FundingInstitution) => void
  onChatClick: (institution: FundingInstitution) => void
}

export function FundingInstitutionCard({ institution, onContactClick, onChatClick }: FundingInstitutionCardProps) {
  const [expanded, setExpanded] = useState(false)

  return (
    <Card className="h-full flex flex-col overflow-hidden transition-all duration-200 hover:shadow-md hover:border-primary/50">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="relative h-12 w-12 overflow-hidden rounded-md">
              <Image
                src={institution.logo || "/placeholder.svg"}
                alt={institution.name}
                fill
                className="object-cover"
              />
            </div>
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                {institution.name}
                {institution.verified && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <CheckCircle className="h-4 w-4 text-primary" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Verified Institution</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </CardTitle>
              <CardDescription>{institution.headquarters}</CardDescription>
            </div>
          </div>
          <div className="flex items-center">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < Math.floor(institution.rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                }`}
              />
            ))}
            <span className="ml-1 text-sm">{institution.rating.toFixed(1)}</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-grow">
        <div className="space-y-3">
          <div className="flex flex-wrap gap-1 mb-2">
            <Badge variant="outline" className="bg-primary/10">
              {institution.type.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
            </Badge>
            {institution.category.slice(0, 3).map((cat) => (
              <Badge key={cat} variant="secondary" className="capitalize">
                {cat.replace("-", " ")}
              </Badge>
            ))}
            {institution.category.length > 3 && <Badge variant="outline">+{institution.category.length - 3}</Badge>}
          </div>

          <p className="text-sm text-muted-foreground line-clamp-2">{institution.description}</p>

          <div className={`space-y-3 transition-all duration-300 ${expanded ? "block" : "hidden"}`}>
            <div>
              <h4 className="text-sm font-medium mb-1">Funding Range</h4>
              <p className="text-sm">
                {formatCurrency(institution.minimumFunding)} - {formatCurrency(institution.maximumFunding)}
              </p>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Regions</h4>
              <div className="flex flex-wrap gap-1">
                {institution.regions.map((region) => (
                  <Badge key={region} variant="outline" className="capitalize">
                    {region.replace("-", " ")}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Industries</h4>
              <p className="text-sm line-clamp-1">{institution.industries.slice(0, 5).join(", ")}</p>
            </div>

            <div>
              <h4 className="text-sm font-medium mb-1">Time to Funding</h4>
              <p className="text-sm">{institution.timeToFunding}</p>
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-2 pt-2">
        <Button variant="ghost" size="sm" className="w-full justify-center" onClick={() => setExpanded(!expanded)}>
          {expanded ? "Show Less" : "Show More"}
        </Button>
        <div className="flex gap-2 w-full">
          <Button variant="outline" size="sm" className="flex-1" onClick={() => onContactClick(institution)}>
            <Info className="mr-2 h-4 w-4" />
            Learn More
          </Button>
          <Button variant="default" size="sm" className="flex-1" onClick={() => onChatClick(institution)}>
            <MessageCircle className="mr-2 h-4 w-4" />
            Chat Now
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

