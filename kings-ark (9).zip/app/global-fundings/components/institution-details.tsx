"use client"

import { X, Globe, Mail, Phone, Calendar, DollarSign, Clock, Building } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import type { FundingInstitution } from "@/types/funding"
import { formatCurrency } from "../utils"

interface InstitutionDetailsProps {
  institution: FundingInstitution
  isOpen: boolean
  onClose: () => void
  onApply: (institution: FundingInstitution) => void
  onChat: (institution: FundingInstitution) => void
}

export function InstitutionDetails({ institution, isOpen, onClose, onApply, onChat }: InstitutionDetailsProps) {
  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-background border rounded-lg shadow-lg w-full max-w-3xl max-h-[90vh] flex flex-col">
        <div className="p-4 border-b flex items-center justify-between sticky top-0 bg-background z-10">
          <h2 className="text-xl font-bold">{institution.name}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <ScrollArea className="flex-grow p-6">
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-6">
              <div className="relative h-32 w-32 overflow-hidden rounded-md shrink-0 mx-auto sm:mx-0">
                <Image
                  src={institution.logo || "/placeholder.svg"}
                  alt={institution.name}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="space-y-2 flex-grow">
                <h3 className="text-lg font-medium">{institution.name}</h3>
                <p className="text-muted-foreground">{institution.description}</p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="bg-primary/10 capitalize">
                    {institution.type.replace("_", " ")}
                  </Badge>
                  {institution.category.map((cat) => (
                    <Badge key={cat} variant="secondary" className="capitalize">
                      {cat.replace("-", " ")}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Contact Information</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      <a
                        href={institution.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm hover:underline text-primary"
                      >
                        {institution.website.replace(/(^\w+:|^)\/\//, "")}
                      </a>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <a href={`mailto:${institution.contactEmail}`} className="text-sm hover:underline text-primary">
                        {institution.contactEmail}
                      </a>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <a href={`tel:${institution.contactPhone}`} className="text-sm hover:underline text-primary">
                        {institution.contactPhone}
                      </a>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Location</h4>
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{institution.headquarters}</span>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Established</h4>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{institution.foundedYear}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Funding Range</h4>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">
                      {formatCurrency(institution.minimumFunding)} - {formatCurrency(institution.maximumFunding)}
                    </span>
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Average: {formatCurrency(institution.averageFundingSize)}
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Time to Funding</h4>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{institution.timeToFunding}</span>
                  </div>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-2">Regions</h4>
                  <div className="flex flex-wrap gap-1">
                    {institution.regions.map((region) => (
                      <Badge key={region} variant="outline" className="capitalize">
                        {region.replace("-", " ")}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground">Industries</h4>
              <div className="flex flex-wrap gap-1">
                {institution.industries.map((industry) => (
                  <Badge key={industry} variant="secondary">
                    {industry}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground">Funding Criteria</h4>
              <ul className="list-disc pl-5 space-y-1">
                {institution.fundingCriteria.map((criteria, index) => (
                  <li key={index} className="text-sm">
                    {criteria}
                  </li>
                ))}
              </ul>
            </div>

            {institution.interestRates && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">Interest Rates</h4>
                <p className="text-sm">{institution.interestRates}</p>
              </div>
            )}

            {institution.equityRequirements && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">Equity Requirements</h4>
                <p className="text-sm">{institution.equityRequirements}</p>
              </div>
            )}

            {institution.collateralRequirements && (
              <div className="space-y-2">
                <h4 className="text-sm font-medium text-muted-foreground">Collateral Requirements</h4>
                <p className="text-sm">{institution.collateralRequirements}</p>
              </div>
            )}

            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground">Application Process</h4>
              <p className="text-sm">{institution.applicationProcess}</p>
            </div>

            <div className="space-y-4">
              <h4 className="text-sm font-medium text-muted-foreground">Success Stories</h4>
              <ul className="list-disc pl-5 space-y-1">
                {institution.successStories.map((story, index) => (
                  <li key={index} className="text-sm">
                    {story}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </ScrollArea>

        <div className="p-4 border-t flex flex-wrap gap-2 justify-end">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <Button variant="outline" onClick={() => onChat(institution)}>
            Chat Now
          </Button>
          <Button onClick={() => onApply(institution)}>Apply for Funding</Button>
        </div>
      </div>
    </div>
  )
}

