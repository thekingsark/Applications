"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Send, Mic, MicOff, Volume2, VolumeX, ArrowLeft, Bot, User } from "lucide-react"
import Link from "next/link"

// Knowledge base for the AI chat
const knowledgeBase = {
  platform: [
    "Kings Ark World Trade Center is a global B2B platform connecting businesses worldwide.",
    "The platform offers market insights, trading opportunities, and business networking.",
    "Users can access real-time market data, analytics, and trade performance metrics.",
    "The platform supports multiple languages and has accessibility features.",
    "Kings Ark WTC was founded by Kingsley Michael Uhiara to facilitate global trade.",
  ],
  features: [
    "Real-time market data and analytics",
    "B2B social networking and messaging",
    "Trade opportunity matching",
    "Bidding system for contracts and deals",
    "AI-powered market insights and recommendations",
    "Document management for trade agreements",
    "Project collaboration tools",
    "Organization directory and profiles",
    "Deal closing and transaction management",
  ],
  buyers: [
    "Buyers can search for products and services globally.",
    "The platform offers verified seller profiles and ratings.",
    "Buyers can post requirements and receive quotes from multiple sellers.",
    "The bidding system allows for competitive pricing and terms.",
    "Buyers can access market reports to make informed decisions.",
    "The platform offers escrow services for secure transactions.",
    "Buyers can communicate directly with sellers through the messaging system.",
  ],
  sellers: [
    "Sellers can showcase their products and services to a global audience.",
    "The platform offers market insights to help target the right buyers.",
    "Sellers can participate in bidding for contracts and deals.",
    "The platform provides tools for managing customer relationships.",
    "Sellers can access trade finance and logistics support.",
    "The platform offers marketing tools to promote offerings.",
    "Sellers can analyze market trends to optimize pricing and offerings.",
  ],
  externalSites: [
    "Kings Global Funding (https://kingsglobalfunding.world) offers trade finance solutions.",
    "Kings Idea Connections (https://kingsideaconnections.org) is a B2B social networking platform.",
    "Close Deals Cloud (https://closedeals.cloud) facilitates transaction completion.",
    "World Trade Center (https://worldtradecenter.cloud) provides global trade resources.",
    "The World Trade Center Cloud (https://theworldtradecenter.cloud) offers cloud-based trade services.",
    "Meet The Founder (https://www.kingsleymichaeluhiara.org) provides information about the founder.",
  ],
}

type Message = {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export default function AISupportChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Welcome to the Kings Ark AI Support Chat! I'm here to help buyers and sellers navigate our platform. How can I assist you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isRecording, setIsRecording] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [userType, setUserType] = useState<"buyer" | "seller" | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // AI response generation based on knowledge base
  const generateAIResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase()

    // Check if user is identifying as buyer or seller
    if (lowerQuery.includes("buyer") && !userType) {
      setUserType("buyer")
      return "Great! As a buyer, you can use our platform to find products and services, connect with verified sellers, and secure the best deals. What specific aspect of buying would you like to learn more about?"
    }

    if (lowerQuery.includes("seller") && !userType) {
      setUserType("seller")
      return "Excellent! As a seller, our platform helps you showcase your products to a global audience, find qualified buyers, and close deals efficiently. What aspect of selling would you like to explore?"
    }

    // Check for specific topics in the knowledge base
    if (lowerQuery.includes("platform") || lowerQuery.includes("kings ark") || lowerQuery.includes("about")) {
      return knowledgeBase.platform[Math.floor(Math.random() * knowledgeBase.platform.length)]
    }

    if (lowerQuery.includes("feature") || lowerQuery.includes("can do") || lowerQuery.includes("offer")) {
      return knowledgeBase.features.slice(0, 3).join("\n\n")
    }

    if (lowerQuery.includes("buy") || lowerQuery.includes("purchase") || lowerQuery.includes("find product")) {
      return knowledgeBase.buyers[Math.floor(Math.random() * knowledgeBase.buyers.length)]
    }

    if (lowerQuery.includes("sell") || lowerQuery.includes("market") || lowerQuery.includes("my product")) {
      return knowledgeBase.sellers[Math.floor(Math.random() * knowledgeBase.sellers.length)]
    }

    if (lowerQuery.includes("website") || lowerQuery.includes("external") || lowerQuery.includes("other site")) {
      return knowledgeBase.externalSites.slice(0, 3).join("\n\n")
    }

    // Default responses
    const defaultResponses = [
      "I understand you're interested in this topic. Could you provide more details about what you're looking for?",
      "That's an interesting question. The Kings Ark platform offers various tools to help with that. Would you like me to explain more about our specific features?",
      "I'd be happy to help with that. The Kings Ark World Trade Center platform connects buyers and sellers globally, offering tools for market analysis, networking, and deal closing.",
      "Great question! Our platform is designed to make global trade accessible and efficient. Would you like to know more about how it works for your specific business needs?",
    ]

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)]
  }

  const handleSendMessage = () => {
    if (input.trim() === "") return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Generate AI response after a delay
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: generateAIResponse(input),
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiResponse])
      setIsLoading(false)
    }, 1000)
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    // In a real app, this would start/stop speech recognition
    if (!isRecording) {
      // Simulate speech recognition
      setTimeout(() => {
        setInput("Tell me about the Kings Ark platform")
        setIsRecording(false)
      }, 2000)
    }
  }

  const toggleSpeaking = () => {
    setIsSpeaking(!isSpeaking)
    // In a real app, this would start/stop text-to-speech
    if (!isSpeaking) {
      // Get the last assistant message
      const lastAssistantMessage = [...messages].reverse().find((m) => m.role === "assistant")
      if (lastAssistantMessage && window.speechSynthesis) {
        const utterance = new SpeechSynthesisUtterance(lastAssistantMessage.content)
        window.speechSynthesis.speak(utterance)
      }
    } else {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel()
      }
    }
  }

  return (
    <div className="container mx-auto py-6 px-4 md:px-6 max-w-6xl">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-6">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                AI Support
              </CardTitle>
              <CardDescription>Get instant help for buyers and sellers</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="topics">
                <TabsList className="w-full">
                  <TabsTrigger value="topics">Topics</TabsTrigger>
                  <TabsTrigger value="faq">FAQ</TabsTrigger>
                </TabsList>
                <TabsContent value="topics" className="mt-4 space-y-3">
                  {[
                    "Platform Overview",
                    "For Buyers",
                    "For Sellers",
                    "Features & Tools",
                    "Getting Started",
                    "Account Setup",
                    "Finding Products",
                    "Listing Products",
                    "Closing Deals",
                    "Payment Options",
                  ].map((topic) => (
                    <Button
                      key={topic}
                      variant="outline"
                      className="w-full justify-start text-left"
                      onClick={() => {
                        setInput(`Tell me about ${topic.toLowerCase()}`)
                      }}
                    >
                      {topic}
                    </Button>
                  ))}
                </TabsContent>
                <TabsContent value="faq" className="mt-4 space-y-3">
                  {[
                    "How do I create an account?",
                    "How do I find products?",
                    "How do I list my products?",
                    "How do payments work?",
                    "Is my data secure?",
                    "How do I contact support?",
                    "What are the fees?",
                    "How do I close a deal?",
                    "Can I integrate with my systems?",
                    "How do I get verified?",
                  ].map((faq) => (
                    <Button
                      key={faq}
                      variant="outline"
                      className="w-full justify-start text-left"
                      onClick={() => {
                        setInput(faq)
                      }}
                    >
                      {faq}
                    </Button>
                  ))}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>I am a...</CardTitle>
              <CardDescription>Tell us who you are for personalized support</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button
                variant={userType === "buyer" ? "default" : "outline"}
                className="w-full justify-start"
                onClick={() => {
                  setUserType("buyer")
                  setInput("I am a buyer looking for help")
                  setTimeout(() => handleSendMessage(), 100)
                }}
              >
                <User className="h-4 w-4 mr-2" />
                Buyer
              </Button>
              <Button
                variant={userType === "seller" ? "default" : "outline"}
                className="w-full justify-start"
                onClick={() => {
                  setUserType("seller")
                  setInput("I am a seller looking for help")
                  setTimeout(() => handleSendMessage(), 100)
                }}
              >
                <User className="h-4 w-4 mr-2" />
                Seller
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card className="flex flex-col h-[calc(100vh-200px)]">
          <CardHeader className="border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="h-10 w-10 border-2 border-primary">
                  <AvatarImage src="/placeholder.svg?height=40&width=40" alt="AI Assistant" />
                  <AvatarFallback className="bg-primary/10 text-primary">AI</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle>Kings Ark AI Assistant</CardTitle>
                  <CardDescription>
                    <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                      Online
                    </Badge>
                  </CardDescription>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant={isSpeaking ? "default" : "outline"}
                  size="icon"
                  onClick={toggleSpeaking}
                  className="h-8 w-8"
                >
                  {isSpeaking ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  <p className="text-sm whitespace-pre-line">{message.content}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="max-w-[80%] rounded-lg p-3 bg-muted">
                  <div className="flex space-x-2">
                    <div className="h-2 w-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-75"></div>
                    <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-150"></div>
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </CardContent>

          <CardFooter className="border-t p-3">
            <div className="flex items-center gap-2 w-full">
              <Button
                variant={isRecording ? "destructive" : "outline"}
                size="icon"
                onClick={toggleRecording}
                className="h-9 w-9 flex-shrink-0"
              >
                {isRecording ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your message..."
                className="flex-1"
                onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
              />
              <Button
                onClick={handleSendMessage}
                size="icon"
                className="h-9 w-9 flex-shrink-0 glow-button"
                disabled={input.trim() === ""}
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

