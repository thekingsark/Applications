"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { Search, ArrowLeft, HelpCircle, Book, FileText, MessageSquare, Video } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function HelpCenterPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("guides")

  // FAQ data
  const faqCategories = [
    {
      id: "general",
      title: "General Questions",
      faqs: [
        {
          question: "What is Kings Ark World Trade Center?",
          answer:
            "Kings Ark World Trade Center is a global B2B platform that connects businesses worldwide, offering market insights, trading opportunities, and business networking capabilities. It serves as a comprehensive ecosystem for international trade and commerce.",
        },
        {
          question: "How do I create an account?",
          answer:
            "To create an account, click on the 'Sign Up' button in the top right corner of the homepage. Fill in your business details, verify your email address, and complete your profile. You can choose between buyer, seller, or both account types depending on your business needs.",
        },
        {
          question: "Is Kings Ark available worldwide?",
          answer:
            "Yes, Kings Ark World Trade Center is available globally and supports businesses from all countries. The platform is available in multiple languages and accommodates various regional business practices and regulations.",
        },
        {
          question: "What are the fees for using the platform?",
          answer:
            "Kings Ark offers a tiered membership model. Basic accounts are free and provide access to essential features. Premium and Enterprise accounts offer additional features and benefits for a monthly or annual subscription fee. Transaction fees may apply for certain services.",
        },
      ],
    },
    {
      id: "buyers",
      title: "For Buyers",
      faqs: [
        {
          question: "How do I find products or services?",
          answer:
            "Use the search function in the Markets tab to find products or services. You can filter results by category, region, price range, and other criteria. The platform also offers AI-powered recommendations based on your business profile and browsing history.",
        },
        {
          question: "How do I verify seller credibility?",
          answer:
            "Seller profiles include verification badges, ratings, and reviews from other buyers. You can also view their business history, certifications, and compliance information. Kings Ark verifies all premium sellers through a rigorous authentication process.",
        },
        {
          question: "How do payments work?",
          answer:
            "Kings Ark offers secure payment processing through our integrated payment system. We also provide escrow services for large transactions to ensure both parties are protected. Multiple payment methods and currencies are supported.",
        },
      ],
    },
    {
      id: "sellers",
      title: "For Sellers",
      faqs: [
        {
          question: "How do I list my products or services?",
          answer:
            "Navigate to the 'My Products' section in your account dashboard and click 'Add New Product'. Fill in the product details, upload images, set pricing, and specify shipping options. Your listings will be reviewed and published within 24 hours.",
        },
        {
          question: "How do I manage orders?",
          answer:
            "All orders are managed through the 'Orders' section in your dashboard. You'll receive notifications for new orders, and you can track fulfillment, shipping, and payment status. The system also provides order analytics and reporting.",
        },
        {
          question: "How can I promote my products?",
          answer:
            "Kings Ark offers various promotional tools including featured listings, sponsored products, and targeted advertising. You can also participate in virtual trade shows and industry events hosted on the platform.",
        },
      ],
    },
    {
      id: "technical",
      title: "Technical Support",
      faqs: [
        {
          question: "How do I reset my password?",
          answer:
            "Click on 'Forgot Password' on the login page. Enter your registered email address, and we'll send you a password reset link. For security reasons, the link expires after 24 hours.",
        },
        {
          question: "Can I integrate Kings Ark with my existing systems?",
          answer:
            "Yes, Kings Ark provides API access for Enterprise accounts, allowing integration with your ERP, CRM, or inventory management systems. Our developer documentation provides detailed integration guides.",
        },
        {
          question: "Is my data secure?",
          answer:
            "Kings Ark employs industry-leading security measures including end-to-end encryption, secure data centers, and regular security audits. We comply with global data protection regulations including GDPR and CCPA.",
        },
      ],
    },
  ]

  // Guides data
  const guides = [
    {
      id: "g1",
      title: "Getting Started with Kings Ark",
      category: "Beginner",
      image: "/placeholder.svg?height=200&width=400&text=Getting+Started",
      description: "A comprehensive guide to setting up your account and navigating the platform.",
    },
    {
      id: "g2",
      title: "Finding and Evaluating Suppliers",
      category: "Buyers",
      image: "/placeholder.svg?height=200&width=400&text=Finding+Suppliers",
      description: "Learn how to search for, evaluate, and connect with reliable suppliers worldwide.",
    },
    {
      id: "g3",
      title: "Creating Effective Product Listings",
      category: "Sellers",
      image: "/placeholder.svg?height=200&width=400&text=Product+Listings",
      description: "Best practices for creating product listings that attract buyers and drive sales.",
    },
    {
      id: "g4",
      title: "Understanding Market Analytics",
      category: "Advanced",
      image: "/placeholder.svg?height=200&width=400&text=Market+Analytics",
      description: "How to use Kings Ark's market analytics tools to gain competitive insights.",
    },
    {
      id: "g5",
      title: "Secure Payment Methods",
      category: "Transactions",
      image: "/placeholder.svg?height=200&width=400&text=Secure+Payments",
      description: "A guide to the various payment methods and security features available on the platform.",
    },
    {
      id: "g6",
      title: "International Shipping and Logistics",
      category: "Logistics",
      image: "/placeholder.svg?height=200&width=400&text=Shipping+Logistics",
      description: "Navigate the complexities of international shipping, customs, and logistics.",
    },
  ]

  // Video tutorials data
  const videoTutorials = [
    {
      id: "v1",
      title: "Platform Overview",
      duration: "5:24",
      thumbnail: "/placeholder.svg?height=200&width=400&text=Platform+Overview",
      description: "A quick tour of the Kings Ark World Trade Center platform and its key features.",
    },
    {
      id: "v2",
      title: "Buyer's Guide to Finding Products",
      duration: "8:15",
      thumbnail: "/placeholder.svg?height=200&width=400&text=Buyers+Guide",
      description: "Step-by-step tutorial on searching for and purchasing products on Kings Ark.",
    },
    {
      id: "v3",
      title: "Seller's Guide to Listing Products",
      duration: "7:42",
      thumbnail: "/placeholder.svg?height=200&width=400&text=Sellers+Guide",
      description: "Learn how to create effective product listings that attract global buyers.",
    },
    {
      id: "v4",
      title: "Using Market Analytics Tools",
      duration: "10:18",
      thumbnail: "/placeholder.svg?height=200&width=400&text=Analytics+Tools",
      description: "How to leverage Kings Ark's analytics tools to make data-driven business decisions.",
    },
  ]

  // Filter content based on search query
  const filteredFAQs = faqCategories
    .map((category) => ({
      ...category,
      faqs: category.faqs.filter(
        (faq) =>
          faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          faq.answer.toLowerCase().includes(searchQuery.toLowerCase()),
      ),
    }))
    .filter((category) => category.faqs.length > 0)

  const filteredGuides = guides.filter(
    (guide) =>
      guide.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      guide.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      guide.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredVideos = videoTutorials.filter(
    (video) =>
      video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto py-6 px-4 md:px-6 max-w-6xl">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Help Center</h1>
          <p className="text-muted-foreground">Find answers and learn how to use the platform</p>
        </div>
        <Button className="gap-2" onClick={() => (window.location.href = "/ai-support-chat")}>
          <MessageSquare className="h-4 w-4" />
          Chat with AI Support
        </Button>
      </div>

      <div className="relative mb-8">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg blur-xl"></div>
        <Card className="relative overflow-hidden border-0 shadow-lg">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold mb-2">How can we help you today?</h2>
              <p className="text-muted-foreground">Search our knowledge base for answers</p>
            </div>
            <div className="max-w-2xl mx-auto relative">
              <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search for guides, FAQs, or topics..."
                className="pl-10 py-6 text-lg"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="guides" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="guides" className="gap-2">
            <Book className="h-4 w-4" />
            Guides
          </TabsTrigger>
          <TabsTrigger value="faq" className="gap-2">
            <HelpCircle className="h-4 w-4" />
            FAQ
          </TabsTrigger>
          <TabsTrigger value="videos" className="gap-2">
            <Video className="h-4 w-4" />
            Video Tutorials
          </TabsTrigger>
        </TabsList>

        <TabsContent value="guides" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGuides.map((guide) => (
              <Card key={guide.id} className="flex flex-col h-full overflow-hidden">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src={guide.image || "/placeholder.svg"}
                    alt={guide.title}
                    fill
                    className="object-cover transition-transform hover:scale-105 glow-image"
                  />
                  <Badge className="absolute top-2 right-2">{guide.category}</Badge>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{guide.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground">{guide.description}</p>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button variant="outline" className="w-full">
                    Read Guide
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {filteredGuides.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No guides found</h3>
              <p className="text-muted-foreground">Try adjusting your search query</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="faq" className="space-y-8">
          {filteredFAQs.map((category) => (
            <div key={category.id}>
              <h2 className="text-xl font-bold mb-4">{category.title}</h2>
              <Accordion type="single" collapsible className="w-full">
                {category.faqs.map((faq, index) => (
                  <AccordionItem key={index} value={`${category.id}-${index}`}>
                    <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                    <AccordionContent>
                      <p className="text-muted-foreground">{faq.answer}</p>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}

          {filteredFAQs.length === 0 && (
            <div className="text-center py-12">
              <HelpCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No FAQs found</h3>
              <p className="text-muted-foreground">Try adjusting your search query</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="videos" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredVideos.map((video) => (
              <Card key={video.id} className="flex flex-col h-full overflow-hidden">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    fill
                    className="object-cover transition-transform hover:scale-105 glow-image"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <Button variant="secondary" size="icon" className="h-12 w-12 rounded-full">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="w-6 h-6"
                      >
                        <path
                          fillRule="evenodd"
                          d="M4.5 5.653c0-1.426 1.529-2.33 2.779-1.643l11.54 6.348c1.295.712 1.295 2.573 0 3.285L7.28 19.991c-1.25.687-2.779-.217-2.779-1.643V5.653z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </Button>
                  </div>
                  <Badge className="absolute bottom-2 right-2 bg-black/70">{video.duration}</Badge>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{video.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-1">
                  <p className="text-sm text-muted-foreground">{video.description}</p>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button variant="outline" className="w-full">
                    Watch Tutorial
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {filteredVideos.length === 0 && (
            <div className="text-center py-12">
              <Video className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium">No video tutorials found</h3>
              <p className="text-muted-foreground">Try adjusting your search query</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <div className="mt-12 border-t pt-8">
        <h2 className="text-2xl font-bold mb-6">Still Need Help?</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Chat Support
              </CardTitle>
              <CardDescription>Get instant help from our AI assistant</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Our AI assistant is available 24/7 to answer your questions and guide you through the platform.
              </p>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={() => (window.location.href = "/ai-support-chat")}>
                Start Chat
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" />
                Contact Support
              </CardTitle>
              <CardDescription>Reach out to our human support team</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Our support team is available Monday to Friday, 9 AM to 5 PM UTC to assist with complex issues.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                Contact Support
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Book className="h-5 w-5 text-primary" />
                Documentation
              </CardTitle>
              <CardDescription>Comprehensive platform documentation</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Access detailed documentation covering all aspects of the Kings Ark platform.
              </p>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View Documentation
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

