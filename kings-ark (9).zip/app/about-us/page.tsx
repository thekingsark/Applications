"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Globe, Users, Award, ExternalLink, Mail, MapPin, Phone } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import SpinningCrownLogo from "@/components/spinning-crown-logo"

export default function AboutUsPage() {
  return (
    <div className="container mx-auto py-6 px-4 md:px-6 max-w-6xl">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      {/* Hero Section */}
      <div className="relative rounded-lg overflow-hidden mb-12">
        <div className="absolute inset-0">
          <Image
            src="/placeholder.svg?height=500&width=1200&text=Kings+Ark+World+Trade+Center"
            alt="Kings Ark World Trade Center"
            fill
            className="object-cover glow-image"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background/90 to-background/70"></div>
        </div>
        <div className="relative py-16 px-6 md:px-12 flex flex-col items-start">
          <div className="flex items-center gap-3 mb-4">
            <SpinningCrownLogo size={48} />
            <h1 className="text-4xl md:text-5xl font-bold">Kings Ark</h1>
          </div>
          <h2 className="text-2xl md:text-3xl font-bold mb-4 max-w-2xl">
            Connecting Businesses Worldwide Through Innovation and Trust
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mb-6">
            Kings Ark World Trade Center is a global B2B platform revolutionizing how businesses connect, trade, and
            grow internationally.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button size="lg" className="gap-2">
              <Globe className="h-5 w-5" />
              Our Mission
            </Button>
            <Button variant="outline" size="lg" className="gap-2">
              <Users className="h-5 w-5" />
              Meet Our Team
            </Button>
          </div>
        </div>
      </div>

      {/* Mission and Vision */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <Card className="border-0 shadow-lg bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader>
            <CardTitle className="text-2xl">Our Mission</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              To create a seamless global trade ecosystem that empowers businesses of all sizes to access international
              markets, connect with trusted partners, and grow their operations worldwide. We aim to remove barriers to
              global trade and foster economic growth through technology and innovation.
            </p>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader>
            <CardTitle className="text-2xl">Our Vision</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              To become the world's leading platform for international trade, where businesses from every corner of the
              globe can discover opportunities, build relationships, and conduct transactions with confidence and ease.
              We envision a world where geographic boundaries no longer limit business potential.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Our Story */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-6">Our Story</h2>
        <div className="grid grid-cols-1 md:grid-cols-[2fr_3fr] gap-8 items-center">
          <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden">
            <Image
              src="/placeholder.svg?height=400&width=600&text=Founder+Image"
              alt="Kingsley Michael Uhiara"
              fill
              className="object-cover glow-image"
            />
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-4">From Vision to Reality</h3>
            <p className="text-muted-foreground mb-4">
              Kings Ark World Trade Center was founded by Kingsley Michael Uhiara, a visionary entrepreneur with a
              passion for global trade and economic development. Recognizing the challenges businesses face when
              expanding internationally, Kingsley set out to create a platform that would democratize access to global
              markets.
            </p>
            <p className="text-muted-foreground mb-4">
              What began as a simple idea in 2020 has grown into a comprehensive ecosystem serving thousands of
              businesses across 78 countries. Through strategic partnerships, technological innovation, and a deep
              understanding of international trade dynamics, Kings Ark has evolved into the platform it is today.
            </p>
            <p className="text-muted-foreground mb-6">
              Our journey has been guided by a commitment to transparency, security, and user-centric design. We
              continue to innovate and expand our offerings to meet the evolving needs of the global business community.
            </p>
            <Button
              variant="outline"
              className="gap-2"
              onClick={() => window.open("https://www.kingsleymichaeluhiara.org", "_blank")}
            >
              <ExternalLink className="h-4 w-4" />
              Meet The Founder
            </Button>
          </div>
        </div>
      </div>

      {/* Our Values */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-8">Our Values</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              title: "Innovation",
              icon: (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-8 w-8 text-primary"
                >
                  <path d="M12 2v8M12 18v4M4.93 10.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 10.93l-1.41 1.41"></path>
                  <circle cx="12" cy="12" r="4"></circle>
                </svg>
              ),
              description: "We embrace new technologies and ideas to continuously improve our platform and services.",
            },
            {
              title: "Trust",
              icon: (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-8 w-8 text-primary"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                </svg>
              ),
              description: "We build trust through transparency, security, and reliability in all our operations.",
            },
            {
              title: "Inclusivity",
              icon: (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-8 w-8 text-primary"
                >
                  <circle cx="12" cy="12" r="10"></circle>
                  <circle cx="12" cy="10" r="3"></circle>
                  <path d="M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662"></path>
                </svg>
              ),
              description: "We create opportunities for businesses of all sizes, from all regions of the world.",
            },
            {
              title: "Excellence",
              icon: (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-8 w-8 text-primary"
                >
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                </svg>
              ),
              description: "We strive for excellence in every aspect of our platform and customer service.",
            },
          ].map((value, index) => (
            <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="p-2 w-fit rounded-full bg-primary/10 mb-2">{value.icon}</div>
                <CardTitle>{value.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{value.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Our Team */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-8">Our Leadership Team</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              name: "Kingsley Michael Uhiara",
              role: "Founder & CEO",
              image: "/placeholder.svg?height=300&width=300&text=KMU",
              bio: "Visionary entrepreneur with extensive experience in international trade and business development.",
            },
            {
              name: "Sarah Johnson",
              role: "Chief Technology Officer",
              image: "/placeholder.svg?height=300&width=300&text=SJ",
              bio: "Technology leader with expertise in building scalable platforms and innovative solutions.",
            },
            {
              name: "David Chen",
              role: "Chief Operations Officer",
              image: "/placeholder.svg?height=300&width=300&text=DC",
              bio: "Operations expert with a background in global supply chain management and logistics.",
            },
            {
              name: "Maria Rodriguez",
              role: "Chief Marketing Officer",
              image: "/placeholder.svg?height=300&width=300&text=MR",
              bio: "Marketing strategist specializing in global brand development and digital marketing.",
            },
            {
              name: "James Wilson",
              role: "Chief Financial Officer",
              image: "/placeholder.svg?height=300&width=300&text=JW",
              bio: "Financial expert with experience in international finance and investment strategies.",
            },
            {
              name: "Aisha Patel",
              role: "Head of Global Partnerships",
              image: "/placeholder.svg?height=300&width=300&text=AP",
              bio: "Relationship builder focused on creating strategic partnerships worldwide.",
            },
          ].map((member, index) => (
            <Card key={index} className="overflow-hidden border-0 shadow-md hover:shadow-lg transition-shadow">
              <div className="relative h-[200px]">
                <Image
                  src={member.image || "/placeholder.svg"}
                  alt={member.name}
                  fill
                  className="object-cover glow-image"
                />
              </div>
              <CardHeader>
                <CardTitle>{member.name}</CardTitle>
                <CardDescription>{member.role}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{member.bio}</p>
              </CardContent>
              <CardFooter>
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-4 w-4"
                    >
                      <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                      <rect x="2" y="9" width="4" height="12"></rect>
                      <circle cx="4" cy="4" r="2"></circle>
                    </svg>
                  </Button>
                  <Button variant="ghost" size="icon">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="h-4 w-4"
                    >
                      <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                    </svg>
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      {/* Global Presence */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-8">Our Global Presence</h2>
        <div className="relative h-[400px] rounded-lg overflow-hidden mb-6">
          <Image
            src="/placeholder.svg?height=400&width=1200&text=World+Map"
            alt="Global Presence"
            fill
            className="object-cover glow-image"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <h3 className="text-2xl font-bold mb-2">Serving Businesses in 78 Countries</h3>
            <p className="text-muted-foreground max-w-2xl">
              With users across six continents, Kings Ark World Trade Center is truly a global platform connecting
              businesses worldwide.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { region: "North America", businesses: "4,250+", growth: "+15%" },
            { region: "Europe", businesses: "3,800+", growth: "+12%" },
            { region: "Asia Pacific", businesses: "2,900+", growth: "+18%" },
            { region: "Rest of World", businesses: "1,500+", growth: "+22%" },
          ].map((region, index) => (
            <Card key={index}>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{region.region}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold">{region.businesses}</p>
                <p className="text-sm text-green-500">{region.growth} YoY</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Achievements */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-8">Achievements & Recognition</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                Awards & Honors
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                {
                  year: "2024",
                  award: "Global Trade Innovator of the Year",
                  organization: "International Trade Association",
                },
                { year: "2023", award: "Best B2B Platform", organization: "Tech Innovation Awards" },
                { year: "2023", award: "Excellence in User Experience", organization: "Digital Business Awards" },
                { year: "2022", award: "Rising Star in Global Commerce", organization: "World Trade Organization" },
              ].map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <Badge variant="outline">{item.year}</Badge>
                  <div>
                    <p className="font-medium">{item.award}</p>
                    <p className="text-sm text-muted-foreground">{item.organization}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-5 w-5 text-primary"
                >
                  <path d="M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06z"></path>
                  <path d="M10 2c1 .5 2 2 2 5"></path>
                </svg>
                Impact & Growth
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="border rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-primary">$1.2B+</p>
                  <p className="text-sm text-muted-foreground">Trading Volume</p>
                </div>
                <div className="border rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-primary">12,450+</p>
                  <p className="text-sm text-muted-foreground">Businesses Connected</p>
                </div>
                <div className="border rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-primary">78</p>
                  <p className="text-sm text-muted-foreground">Countries Served</p>
                </div>
                <div className="border rounded-lg p-4 text-center">
                  <p className="text-3xl font-bold text-primary">142</p>
                  <p className="text-sm text-muted-foreground">Active Markets</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Contact Section */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold mb-8">Get in Touch</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                Email Us
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                For general inquiries, support, or partnership opportunities.
              </p>
              <p className="font-medium">info@kingsark.com</p>
              <p className="font-medium">support@kingsark.com</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-primary" />
                Call Us
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">
                Our support team is available Monday to Friday, 9 AM to 5 PM UTC.
              </p>
              <p className="font-medium">+1 (555) 123-4567</p>
              <p className="font-medium">+44 (20) 1234 5678</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Visit Us
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground mb-4">Our headquarters and regional offices.</p>
              <p className="font-medium">Kings Ark Tower</p>
              <p className="text-muted-foreground">123 Global Trade Avenue</p>
              <p className="text-muted-foreground">New York, NY 10001</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* CTA Section */}
      <div className="relative rounded-lg overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/placeholder.svg?height=300&width=1200&text=Join+Kings+Ark"
            alt="Join Kings Ark"
            fill
            className="object-cover glow-image"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-primary/40"></div>
        </div>
        <div className="relative py-12 px-6 md:px-12 text-center">
          <h2 className="text-3xl font-bold mb-4 text-white">Join the Kings Ark Global Community</h2>
          <p className="text-white/90 max-w-2xl mx-auto mb-6">
            Connect with businesses worldwide, access global markets, and grow your international presence.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" variant="secondary">
              Sign Up Now
            </Button>
            <Button size="lg" variant="outline" className="bg-transparent text-white border-white hover:bg-white/10">
              Request a Demo
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

