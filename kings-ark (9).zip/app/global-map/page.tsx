"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import {
  ArrowLeft,
  Search,
  Filter,
  MessageSquare,
  ExternalLink,
  User,
  Star,
  MapPin,
  Phone,
  Mail,
  X,
  Zap,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import PartnerChat from "@/components/partner-chat"
import type { Partner } from "@/types"

// Partner data type
// type Partner = {
//   id: string
//   name: string
//   type: "buyer" | "seller" | "both"
//   category: string
//   subcategory: string
//   country: string
//   city: string
//   coordinates: [number, number] // [latitude, longitude]
//   rating: number
//   verified: boolean
//   description: string
//   logo: string
//   website: string
//   contactPerson: string
//   contactEmail: string
//   contactPhone: string
//   yearEstablished: number
//   employeeCount: string
//   specialties: string[]
//   languages: string[]
// }

// Sample partner data (50 partners from different countries)
const partnersData: Partner[] = [
  {
    id: "p1",
    name: "Global Tech Solutions",
    type: "seller",
    category: "Technology",
    subcategory: "Software",
    country: "United States",
    city: "San Francisco",
    coordinates: [37.7749, -122.4194],
    rating: 4.8,
    verified: true,
    description: "Leading provider of enterprise software solutions with global reach and innovative products.",
    logo: "/placeholder.svg?height=80&width=80&text=GTS",
    website: "https://example.com/gts",
    contactPerson: "John Smith",
    contactEmail: "contact@gts.com",
    contactPhone: "+1 (555) 123-4567",
    yearEstablished: 2010,
    employeeCount: "100-500",
    specialties: ["Cloud Computing", "AI Solutions", "Enterprise Software"],
    languages: ["English", "Spanish", "Mandarin"],
  },
  {
    id: "p2",
    name: "EcoFarm Produce",
    type: "seller",
    category: "Agriculture",
    subcategory: "Organic Produce",
    country: "Brazil",
    city: "São Paulo",
    coordinates: [-23.5505, -46.6333],
    rating: 4.5,
    verified: true,
    description: "Sustainable organic farm producing high-quality fruits and vegetables for global export.",
    logo: "/placeholder.svg?height=80&width=80&text=EFP",
    website: "https://example.com/ecofarm",
    contactPerson: "Maria Santos",
    contactEmail: "contact@ecofarm.com",
    contactPhone: "+55 (11) 9876-5432",
    yearEstablished: 2008,
    employeeCount: "50-100",
    specialties: ["Organic Farming", "Sustainable Agriculture", "Export"],
    languages: ["Portuguese", "English", "Spanish"],
  },
  {
    id: "p3",
    name: "Nordic Furniture Design",
    type: "seller",
    category: "Manufacturing",
    subcategory: "Furniture",
    country: "Sweden",
    city: "Stockholm",
    coordinates: [59.3293, 18.0686],
    rating: 4.9,
    verified: true,
    description: "Premium Scandinavian furniture design and manufacturing for commercial and residential spaces.",
    logo: "/placeholder.svg?height=80&width=80&text=NFD",
    website: "https://example.com/nordic",
    contactPerson: "Erik Johansson",
    contactEmail: "contact@nordicdesign.com",
    contactPhone: "+46 (8) 123-4567",
    yearEstablished: 1995,
    employeeCount: "100-500",
    specialties: ["Scandinavian Design", "Sustainable Materials", "Custom Furniture"],
    languages: ["Swedish", "English", "German"],
  },
  {
    id: "p4",
    name: "African Textiles Co.",
    type: "seller",
    category: "Textiles",
    subcategory: "Fabrics",
    country: "Ghana",
    city: "Accra",
    coordinates: [5.6037, -0.187],
    rating: 4.3,
    verified: true,
    description: "Traditional and modern African textiles with authentic designs and sustainable production.",
    logo: "/placeholder.svg?height=80&width=80&text=ATC",
    website: "https://example.com/africantextiles",
    contactPerson: "Kwame Mensah",
    contactEmail: "contact@africantextiles.com",
    contactPhone: "+233 (302) 123-456",
    yearEstablished: 2005,
    employeeCount: "50-100",
    specialties: ["Kente Cloth", "Batik", "Handwoven Textiles"],
    languages: ["English", "Twi", "French"],
  },
  {
    id: "p5",
    name: "Tokyo Electronics Ltd.",
    type: "seller",
    category: "Electronics",
    subcategory: "Consumer Electronics",
    country: "Japan",
    city: "Tokyo",
    coordinates: [35.6762, 139.6503],
    rating: 4.7,
    verified: true,
    description: "Innovative consumer electronics with cutting-edge technology and exceptional quality.",
    logo: "/placeholder.svg?height=80&width=80&text=TEL",
    website: "https://example.com/tokyoelectronics",
    contactPerson: "Hiroshi Tanaka",
    contactEmail: "contact@tokyoelectronics.com",
    contactPhone: "+81 (3) 1234-5678",
    yearEstablished: 1985,
    employeeCount: "1000+",
    specialties: ["Smart Devices", "Audio Equipment", "Home Automation"],
    languages: ["Japanese", "English", "Korean"],
  },
  {
    id: "p6",
    name: "Aussie Mining Supplies",
    type: "seller",
    category: "Mining",
    subcategory: "Equipment",
    country: "Australia",
    city: "Perth",
    coordinates: [-31.9505, 115.8605],
    rating: 4.6,
    verified: true,
    description: "Comprehensive mining equipment and supplies for large-scale operations worldwide.",
    logo: "/placeholder.svg?height=80&width=80&text=AMS",
    website: "https://example.com/aussiemining",
    contactPerson: "Sarah Johnson",
    contactEmail: "contact@aussiemining.com",
    contactPhone: "+61 (8) 9876-5432",
    yearEstablished: 1998,
    employeeCount: "100-500",
    specialties: ["Heavy Equipment", "Safety Gear", "Mining Tools"],
    languages: ["English"],
  },
  {
    id: "p7",
    name: "Dubai Global Traders",
    type: "both",
    category: "Trading",
    subcategory: "General Merchandise",
    country: "United Arab Emirates",
    city: "Dubai",
    coordinates: [25.2048, 55.2708],
    rating: 4.4,
    verified: true,
    description: "International trading company specializing in diverse product categories and global logistics.",
    logo: "/placeholder.svg?height=80&width=80&text=DGT",
    website: "https://example.com/dubaitraders",
    contactPerson: "Ahmed Al-Mansour",
    contactEmail: "contact@dubaitraders.com",
    contactPhone: "+971 (4) 123-4567",
    yearEstablished: 2003,
    employeeCount: "50-100",
    specialties: ["Import/Export", "Logistics", "Distribution"],
    languages: ["Arabic", "English", "Hindi", "Urdu"],
  },
  {
    id: "p8",
    name: "Canadian Timber Products",
    type: "seller",
    category: "Forestry",
    subcategory: "Lumber",
    country: "Canada",
    city: "Vancouver",
    coordinates: [49.2827, -123.1207],
    rating: 4.5,
    verified: true,
    description: "Sustainable timber and wood products from responsibly managed Canadian forests.",
    logo: "/placeholder.svg?height=80&width=80&text=CTP",
    website: "https://example.com/canadiantimber",
    contactPerson: "Michael Thompson",
    contactEmail: "contact@canadiantimber.com",
    contactPhone: "+1 (604) 987-6543",
    yearEstablished: 1992,
    employeeCount: "100-500",
    specialties: ["Lumber", "Plywood", "Sustainable Forestry"],
    languages: ["English", "French"],
  },
  {
    id: "p9",
    name: "Indian Spice Exporters",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Spices",
    country: "India",
    city: "Mumbai",
    coordinates: [19.076, 72.8777],
    rating: 4.7,
    verified: true,
    description: "Premium quality spices and herbs sourced from across India for global culinary markets.",
    logo: "/placeholder.svg?height=80&width=80&text=ISE",
    website: "https://example.com/indianspices",
    contactPerson: "Raj Patel",
    contactEmail: "contact@indianspices.com",
    contactPhone: "+91 (22) 2345-6789",
    yearEstablished: 2001,
    employeeCount: "50-100",
    specialties: ["Organic Spices", "Herbs", "Spice Blends"],
    languages: ["Hindi", "English", "Gujarati", "Marathi"],
  },
  {
    id: "p10",
    name: "German Automotive Parts",
    type: "seller",
    category: "Automotive",
    subcategory: "Parts & Components",
    country: "Germany",
    city: "Munich",
    coordinates: [48.1351, 11.582],
    rating: 4.9,
    verified: true,
    description: "High-precision automotive components and parts with German engineering excellence.",
    logo: "/placeholder.svg?height=80&width=80&text=GAP",
    website: "https://example.com/germanparts",
    contactPerson: "Klaus Schmidt",
    contactEmail: "contact@germanparts.com",
    contactPhone: "+49 (89) 123-45678",
    yearEstablished: 1978,
    employeeCount: "500-1000",
    specialties: ["Engine Components", "Transmission Parts", "Electronic Systems"],
    languages: ["German", "English", "French"],
  },
  {
    id: "p11",
    name: "Global Retail Solutions",
    type: "buyer",
    category: "Retail",
    subcategory: "Department Stores",
    country: "United Kingdom",
    city: "London",
    coordinates: [51.5074, -0.1278],
    rating: 4.6,
    verified: true,
    description: "International retail chain seeking quality products across multiple categories.",
    logo: "/placeholder.svg?height=80&width=80&text=GRS",
    website: "https://example.com/globalretail",
    contactPerson: "Emma Wilson",
    contactEmail: "sourcing@globalretail.com",
    contactPhone: "+44 (20) 7946-0123",
    yearEstablished: 1985,
    employeeCount: "1000+",
    specialties: ["Consumer Goods", "Home Products", "Apparel"],
    languages: ["English", "French", "Spanish"],
  },
  {
    id: "p12",
    name: "South African Mining Corp",
    type: "seller",
    category: "Mining",
    subcategory: "Precious Metals",
    country: "South Africa",
    city: "Johannesburg",
    coordinates: [-26.2041, 28.0473],
    rating: 4.4,
    verified: true,
    description: "Leading mining company specializing in precious metals and minerals extraction.",
    logo: "/placeholder.svg?height=80&width=80&text=SAMC",
    website: "https://example.com/samining",
    contactPerson: "Nelson Khumalo",
    contactEmail: "contact@samining.com",
    contactPhone: "+27 (11) 234-5678",
    yearEstablished: 1990,
    employeeCount: "1000+",
    specialties: ["Gold", "Platinum", "Diamonds"],
    languages: ["English", "Afrikaans", "Zulu"],
  },
  {
    id: "p13",
    name: "French Luxury Goods",
    type: "seller",
    category: "Luxury",
    subcategory: "Fashion & Accessories",
    country: "France",
    city: "Paris",
    coordinates: [48.8566, 2.3522],
    rating: 4.8,
    verified: true,
    description: "Exquisite luxury fashion and accessories with French craftsmanship and design.",
    logo: "/placeholder.svg?height=80&width=80&text=FLG",
    website: "https://example.com/frenchluxury",
    contactPerson: "Sophie Dubois",
    contactEmail: "contact@frenchluxury.com",
    contactPhone: "+33 (1) 23-45-67-89",
    yearEstablished: 1980,
    employeeCount: "100-500",
    specialties: ["Haute Couture", "Leather Goods", "Jewelry"],
    languages: ["French", "English", "Italian"],
  },
  {
    id: "p14",
    name: "Mexican Artisan Crafts",
    type: "seller",
    category: "Handicrafts",
    subcategory: "Traditional Crafts",
    country: "Mexico",
    city: "Mexico City",
    coordinates: [19.4326, -99.1332],
    rating: 4.5,
    verified: true,
    description: "Authentic Mexican handicrafts and artisanal products with cultural significance.",
    logo: "/placeholder.svg?height=80&width=80&text=MAC",
    website: "https://example.com/mexicancrafts",
    contactPerson: "Carlos Hernandez",
    contactEmail: "contact@mexicancrafts.com",
    contactPhone: "+52 (55) 1234-5678",
    yearEstablished: 2005,
    employeeCount: "10-50",
    specialties: ["Textiles", "Ceramics", "Folk Art"],
    languages: ["Spanish", "English"],
  },
  {
    id: "p15",
    name: "Chinese Manufacturing Group",
    type: "seller",
    category: "Manufacturing",
    subcategory: "General Manufacturing",
    country: "China",
    city: "Shenzhen",
    coordinates: [22.5431, 114.0579],
    rating: 4.3,
    verified: true,
    description: "Versatile manufacturing capabilities across multiple industries with competitive pricing.",
    logo: "/placeholder.svg?height=80&width=80&text=CMG",
    website: "https://example.com/chinesemfg",
    contactPerson: "Li Wei",
    contactEmail: "contact@chinesemfg.com",
    contactPhone: "+86 (755) 1234-5678",
    yearEstablished: 2000,
    employeeCount: "1000+",
    specialties: ["Electronics", "Plastics", "Textiles"],
    languages: ["Mandarin", "Cantonese", "English"],
  },
  {
    id: "p16",
    name: "Russian Timber Exports",
    type: "seller",
    category: "Forestry",
    subcategory: "Timber",
    country: "Russia",
    city: "Moscow",
    coordinates: [55.7558, 37.6173],
    rating: 4.2,
    verified: true,
    description: "Large-scale timber exports from Russian forests with sustainable harvesting practices.",
    logo: "/placeholder.svg?height=80&width=80&text=RTE",
    website: "https://example.com/russiantimber",
    contactPerson: "Dmitri Petrov",
    contactEmail: "contact@russiantimber.com",
    contactPhone: "+7 (495) 123-4567",
    yearEstablished: 1995,
    employeeCount: "500-1000",
    specialties: ["Softwood", "Hardwood", "Processed Timber"],
    languages: ["Russian", "English"],
  },
  {
    id: "p17",
    name: "Italian Fashion House",
    type: "seller",
    category: "Fashion",
    subcategory: "Apparel",
    country: "Italy",
    city: "Milan",
    coordinates: [45.4642, 9.19],
    rating: 4.7,
    verified: true,
    description: "Elegant Italian fashion with premium craftsmanship and trendsetting designs.",
    logo: "/placeholder.svg?height=80&width=80&text=IFH",
    website: "https://example.com/italianfashion",
    contactPerson: "Marco Rossi",
    contactEmail: "contact@italianfashion.com",
    contactPhone: "+39 (02) 1234-5678",
    yearEstablished: 1975,
    employeeCount: "100-500",
    specialties: ["Luxury Apparel", "Accessories", "Footwear"],
    languages: ["Italian", "English", "French"],
  },
  {
    id: "p18",
    name: "Korean Electronics Corp",
    type: "seller",
    category: "Electronics",
    subcategory: "Consumer Electronics",
    country: "South Korea",
    city: "Seoul",
    coordinates: [37.5665, 126.978],
    rating: 4.6,
    verified: true,
    description: "Innovative electronics with cutting-edge technology and sleek design.",
    logo: "/placeholder.svg?height=80&width=80&text=KEC",
    website: "https://example.com/koreanelectronics",
    contactPerson: "Park Ji-sung",
    contactEmail: "contact@koreanelectronics.com",
    contactPhone: "+82 (2) 1234-5678",
    yearEstablished: 1990,
    employeeCount: "1000+",
    specialties: ["Smartphones", "Home Appliances", "Display Technology"],
    languages: ["Korean", "English", "Chinese"],
  },
  {
    id: "p19",
    name: "Brazilian Coffee Exporters",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Coffee",
    country: "Brazil",
    city: "Rio de Janeiro",
    coordinates: [-22.9068, -43.1729],
    rating: 4.8,
    verified: true,
    description: "Premium coffee beans from Brazil's finest plantations with sustainable farming practices.",
    logo: "/placeholder.svg?height=80&width=80&text=BCE",
    website: "https://example.com/braziliancoffee",
    contactPerson: "Luiz Silva",
    contactEmail: "contact@braziliancoffee.com",
    contactPhone: "+55 (21) 9876-5432",
    yearEstablished: 1998,
    employeeCount: "50-100",
    specialties: ["Arabica", "Robusta", "Specialty Coffee"],
    languages: ["Portuguese", "English", "Spanish"],
  },
  {
    id: "p20",
    name: "Turkish Textile Manufacturers",
    type: "seller",
    category: "Textiles",
    subcategory: "Fabrics",
    country: "Turkey",
    city: "Istanbul",
    coordinates: [41.0082, 28.9784],
    rating: 4.5,
    verified: true,
    description: "High-quality textiles and fabrics with traditional Turkish craftsmanship and modern techniques.",
    logo: "/placeholder.svg?height=80&width=80&text=TTM",
    website: "https://example.com/turkishtextiles",
    contactPerson: "Mehmet Yilmaz",
    contactEmail: "contact@turkishtextiles.com",
    contactPhone: "+90 (212) 123-4567",
    yearEstablished: 2002,
    employeeCount: "100-500",
    specialties: ["Cotton", "Silk", "Wool"],
    languages: ["Turkish", "English", "Arabic"],
  },
  {
    id: "p21",
    name: "Global Procurement Inc.",
    type: "buyer",
    category: "Retail",
    subcategory: "General Merchandise",
    country: "United States",
    city: "New York",
    coordinates: [40.7128, -74.006],
    rating: 4.7,
    verified: true,
    description: "International procurement company sourcing products for major retail chains worldwide.",
    logo: "/placeholder.svg?height=80&width=80&text=GPI",
    website: "https://example.com/globalprocurement",
    contactPerson: "Robert Johnson",
    contactEmail: "sourcing@globalprocurement.com",
    contactPhone: "+1 (212) 555-7890",
    yearEstablished: 1995,
    employeeCount: "100-500",
    specialties: ["Consumer Goods", "Electronics", "Home Products"],
    languages: ["English", "Spanish", "Mandarin"],
  },
  {
    id: "p22",
    name: "Spanish Olive Oil Producers",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Oils",
    country: "Spain",
    city: "Seville",
    coordinates: [37.3891, -5.9845],
    rating: 4.9,
    verified: true,
    description: "Premium olive oil from Spain's finest groves with traditional production methods.",
    logo: "/placeholder.svg?height=80&width=80&text=SOAP",
    website: "https://example.com/spanisholiveoil",
    contactPerson: "Elena Rodriguez",
    contactEmail: "contact@spanisholiveoil.com",
    contactPhone: "+34 (954) 123-456",
    yearEstablished: 1985,
    employeeCount: "50-100",
    specialties: ["Extra Virgin Olive Oil", "Organic Oils", "Flavored Oils"],
    languages: ["Spanish", "English", "French"],
  },
  {
    id: "p23",
    name: "Egyptian Cotton Exporters",
    type: "seller",
    category: "Textiles",
    subcategory: "Cotton",
    country: "Egypt",
    city: "Cairo",
    coordinates: [30.0444, 31.2357],
    rating: 4.6,
    verified: true,
    description: "World-renowned Egyptian cotton with exceptional quality and luxurious feel.",
    logo: "/placeholder.svg?height=80&width=80&text=ECE",
    website: "https://example.com/egyptiancotton",
    contactPerson: "Ahmed Hassan",
    contactEmail: "contact@egyptiancotton.com",
    contactPhone: "+20 (2) 1234-5678",
    yearEstablished: 1990,
    employeeCount: "100-500",
    specialties: ["Long-staple Cotton", "Organic Cotton", "Cotton Textiles"],
    languages: ["Arabic", "English", "French"],
  },
  {
    id: "p24",
    name: "Swiss Precision Instruments",
    type: "seller",
    category: "Manufacturing",
    subcategory: "Precision Tools",
    country: "Switzerland",
    city: "Zurich",
    coordinates: [47.3769, 8.5417],
    rating: 4.9,
    verified: true,
    description: "High-precision instruments and tools with Swiss engineering excellence.",
    logo: "/placeholder.svg?height=80&width=80&text=SPI",
    website: "https://example.com/swissprecision",
    contactPerson: "Hans Mueller",
    contactEmail: "contact@swissprecision.com",
    contactPhone: "+41 (44) 123-4567",
    yearEstablished: 1970,
    employeeCount: "100-500",
    specialties: ["Measuring Instruments", "Watchmaking Tools", "Medical Instruments"],
    languages: ["German", "French", "Italian", "English"],
  },
  {
    id: "p25",
    name: "Argentinian Beef Exporters",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Meat",
    country: "Argentina",
    city: "Buenos Aires",
    coordinates: [-34.6037, -58.3816],
    rating: 4.7,
    verified: true,
    description: "Premium grass-fed beef from Argentina's pampas with sustainable ranching practices.",
    logo: "/placeholder.svg?height=80&width=80&text=ABE",
    website: "https://example.com/argentinianbeef",
    contactPerson: "Diego Martinez",
    contactEmail: "contact@argentinianbeef.com",
    contactPhone: "+54 (11) 1234-5678",
    yearEstablished: 1995,
    employeeCount: "100-500",
    specialties: ["Grass-fed Beef", "Organic Meat", "Premium Cuts"],
    languages: ["Spanish", "English", "Portuguese"],
  },
  {
    id: "p26",
    name: "Thai Silk Enterprises",
    type: "seller",
    category: "Textiles",
    subcategory: "Silk",
    country: "Thailand",
    city: "Bangkok",
    coordinates: [13.7563, 100.5018],
    rating: 4.8,
    verified: true,
    description: "Exquisite Thai silk with traditional weaving techniques and vibrant designs.",
    logo: "/placeholder.svg?height=80&width=80&text=TSE",
    website: "https://example.com/thaisilk",
    contactPerson: "Somchai Pattana",
    contactEmail: "contact@thaisilk.com",
    contactPhone: "+66 (2) 123-4567",
    yearEstablished: 1988,
    employeeCount: "50-100",
    specialties: ["Handwoven Silk", "Silk Garments", "Silk Home Decor"],
    languages: ["Thai", "English", "Chinese"],
  },
  {
    id: "p27",
    name: "Nigerian Oil & Gas Ltd.",
    type: "seller",
    category: "Energy",
    subcategory: "Oil & Gas",
    country: "Nigeria",
    city: "Lagos",
    coordinates: [6.5244, 3.3792],
    rating: 4.3,
    verified: true,
    description: "Major oil and gas producer with extensive operations across Nigeria.",
    logo: "/placeholder.svg?height=80&width=80&text=NOGL",
    website: "https://example.com/nigerianoil",
    contactPerson: "Oluwaseun Adebayo",
    contactEmail: "contact@nigerianoil.com",
    contactPhone: "+234 (1) 123-4567",
    yearEstablished: 1992,
    employeeCount: "1000+",
    specialties: ["Crude Oil", "Natural Gas", "Petroleum Products"],
    languages: ["English", "Yoruba", "Hausa", "Igbo"],
  },
  {
    id: "p28",
    name: "Dutch Flower Exporters",
    type: "seller",
    category: "Agriculture",
    subcategory: "Flowers",
    country: "Netherlands",
    city: "Amsterdam",
    coordinates: [52.3676, 4.9041],
    rating: 4.8,
    verified: true,
    description: "World-leading flower exporters with vast variety and exceptional quality.",
    logo: "/placeholder.svg?height=80&width=80&text=DFE",
    website: "https://example.com/dutchflowers",
    contactPerson: "Jan de Vries",
    contactEmail: "contact@dutchflowers.com",
    contactPhone: "+31 (20) 123-4567",
    yearEstablished: 1980,
    employeeCount: "100-500",
    specialties: ["Tulips", "Roses", "Exotic Flowers"],
    languages: ["Dutch", "English", "German"],
  },
  {
    id: "p29",
    name: "Chilean Wine Producers",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Wine",
    country: "Chile",
    city: "Santiago",
    coordinates: [-33.4489, -70.6693],
    rating: 4.7,
    verified: true,
    description: "Premium wines from Chile's diverse terroirs with traditional and innovative winemaking.",
    logo: "/placeholder.svg?height=80&width=80&text=CWP",
    website: "https://example.com/chileanwine",
    contactPerson: "Isabella Mendoza",
    contactEmail: "contact@chileanwine.com",
    contactPhone: "+56 (2) 2123-4567",
    yearEstablished: 1990,
    employeeCount: "50-100",
    specialties: ["Red Wine", "White Wine", "Organic Wine"],
    languages: ["Spanish", "English", "Portuguese"],
  },
  {
    id: "p30",
    name: "Scandinavian Design Collective",
    type: "seller",
    category: "Home & Decor",
    subcategory: "Furniture",
    country: "Denmark",
    city: "Copenhagen",
    coordinates: [55.6761, 12.5683],
    rating: 4.9,
    verified: true,
    description: "Minimalist Scandinavian furniture and home decor with functional elegance.",
    logo: "/placeholder.svg?height=80&width=80&text=SDC",
    website: "https://example.com/scandinaviandesign",
    contactPerson: "Lars Nielsen",
    contactEmail: "contact@scandinaviandesign.com",
    contactPhone: "+45 (33) 12-34-56",
    yearEstablished: 1995,
    employeeCount: "50-100",
    specialties: ["Furniture", "Lighting", "Home Accessories"],
    languages: ["Danish", "Swedish", "Norwegian", "English"],
  },
  {
    id: "p31",
    name: "Moroccan Artisan Cooperative",
    type: "seller",
    category: "Handicrafts",
    subcategory: "Home Decor",
    country: "Morocco",
    city: "Marrakech",
    coordinates: [31.6295, -7.9811],
    rating: 4.6,
    verified: true,
    description: "Authentic Moroccan handicrafts with traditional techniques and cultural heritage.",
    logo: "/placeholder.svg?height=80&width=80&text=MAC",
    website: "https://example.com/moroccanartisans",
    contactPerson: "Fatima Benali",
    contactEmail: "contact@moroccanartisans.com",
    contactPhone: "+212 (524) 123-456",
    yearEstablished: 2005,
    employeeCount: "10-50",
    specialties: ["Rugs", "Ceramics", "Leather Goods"],
    languages: ["Arabic", "French", "English", "Spanish"],
  },
  {
    id: "p32",
    name: "Singapore Tech Innovations",
    type: "seller",
    category: "Technology",
    subcategory: "Software",
    country: "Singapore",
    city: "Singapore",
    coordinates: [1.3521, 103.8198],
    rating: 4.7,
    verified: true,
    description: "Cutting-edge technology solutions with focus on AI, fintech, and smart city applications.",
    logo: "/placeholder.svg?height=80&width=80&text=STI",
    website: "https://example.com/singaporetech",
    contactPerson: "David Tan",
    contactEmail: "contact@singaporetech.com",
    contactPhone: "+65 6123-4567",
    yearEstablished: 2010,
    employeeCount: "100-500",
    specialties: ["AI Solutions", "Fintech", "IoT"],
    languages: ["English", "Mandarin", "Malay", "Tamil"],
  },
  {
    id: "p33",
    name: "New Zealand Dairy Cooperative",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Dairy",
    country: "New Zealand",
    city: "Auckland",
    coordinates: [-36.8509, 174.7645],
    rating: 4.8,
    verified: true,
    description: "Premium dairy products from New Zealand's grass-fed cows with sustainable farming practices.",
    logo: "/placeholder.svg?height=80&width=80&text=NZDC",
    website: "https://example.com/nzdairy",
    contactPerson: "Sarah Williams",
    contactEmail: "contact@nzdairy.com",
    contactPhone: "+64 (9) 123-4567",
    yearEstablished: 1985,
    employeeCount: "500-1000",
    specialties: ["Milk Powder", "Cheese", "Butter"],
    languages: ["English", "Maori"],
  },
  {
    id: "p34",
    name: "Polish Furniture Manufacturers",
    type: "seller",
    category: "Manufacturing",
    subcategory: "Furniture",
    country: "Poland",
    city: "Warsaw",
    coordinates: [52.2297, 21.0122],
    rating: 4.5,
    verified: true,
    description: "Quality furniture manufacturing with European standards and competitive pricing.",
    logo: "/placeholder.svg?height=80&width=80&text=PFM",
    website: "https://example.com/polishfurniture",
    contactPerson: "Marek Kowalski",
    contactEmail: "contact@polishfurniture.com",
    contactPhone: "+48 (22) 123-4567",
    yearEstablished: 1998,
    employeeCount: "100-500",
    specialties: ["Wooden Furniture", "Upholstered Furniture", "Office Furniture"],
    languages: ["Polish", "English", "German", "Russian"],
  },
  {
    id: "p35",
    name: "Vietnamese Handicraft Exporters",
    type: "seller",
    category: "Handicrafts",
    subcategory: "Home Decor",
    country: "Vietnam",
    city: "Hanoi",
    coordinates: [21.0278, 105.8342],
    rating: 4.4,
    verified: true,
    description: "Traditional Vietnamese handicrafts with skilled craftsmanship and cultural significance.",
    logo: "/placeholder.svg?height=80&width=80&text=VHE",
    website: "https://example.com/vietnamesehandicrafts",
    contactPerson: "Nguyen Van Minh",
    contactEmail: "contact@vietnamesehandicrafts.com",
    contactPhone: "+84 (24) 1234-5678",
    yearEstablished: 2003,
    employeeCount: "50-100",
    specialties: ["Bamboo Crafts", "Lacquerware", "Embroidery"],
    languages: ["Vietnamese", "English", "French"],
  },
  {
    id: "p36",
    name: "Israeli Tech Startups",
    type: "seller",
    category: "Technology",
    subcategory: "Software",
    country: "Israel",
    city: "Tel Aviv",
    coordinates: [32.0853, 34.7818],
    rating: 4.8,
    verified: true,
    description: "Innovative technology solutions from Israel's dynamic startup ecosystem.",
    logo: "/placeholder.svg?height=80&width=80&text=ITS",
    website: "https://example.com/israelitech",
    contactPerson: "David Cohen",
    contactEmail: "contact@israelitech.com",
    contactPhone: "+972 (3) 123-4567",
    yearEstablished: 2012,
    employeeCount: "50-100",
    specialties: ["Cybersecurity", "AI", "Medical Technology"],
    languages: ["Hebrew", "English", "Arabic"],
  },
  {
    id: "p37",
    name: "Colombian Coffee Growers",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Coffee",
    country: "Colombia",
    city: "Bogotá",
    coordinates: [4.711, -74.0721],
    rating: 4.9,
    verified: true,
    description: "Premium Colombian coffee with rich flavors and sustainable farming practices.",
    logo: "/placeholder.svg?height=80&width=80&text=CCG",
    website: "https://example.com/colombiancoffee",
    contactPerson: "Carlos Mendez",
    contactEmail: "contact@colombiancoffee.com",
    contactPhone: "+57 (1) 123-4567",
    yearEstablished: 1990,
    employeeCount: "100-500",
    specialties: ["Arabica Coffee", "Specialty Coffee", "Organic Coffee"],
    languages: ["Spanish", "English"],
  },
  {
    id: "p38",
    name: "Irish Dairy Products",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Dairy",
    country: "Ireland",
    city: "Dublin",
    coordinates: [53.3498, -6.2603],
    rating: 4.7,
    verified: true,
    description: "Premium dairy products from Ireland's grass-fed cows with traditional methods.",
    logo: "/placeholder.svg?height=80&width=80&text=IDP",
    website: "https://example.com/irishdairy",
    contactPerson: "Sean O'Connor",
    contactEmail: "contact@irishdairy.com",
    contactPhone: "+353 (1) 123-4567",
    yearEstablished: 1985,
    employeeCount: "100-500",
    specialties: ["Butter", "Cheese", "Milk Powder"],
    languages: ["English", "Irish"],
  },
  {
    id: "p39",
    name: "Malaysian Palm Oil Producers",
    type: "seller",
    category: "Agriculture",
    subcategory: "Oils",
    country: "Malaysia",
    city: "Kuala Lumpur",
    coordinates: [3.139, 101.6869],
    rating: 4.3,
    verified: true,
    description: "Sustainable palm oil production with modern processing techniques and certifications.",
    logo: "/placeholder.svg?height=80&width=80&text=MPOP",
    website: "https://example.com/malaysianpalmoil",
    contactPerson: "Ahmad Razak",
    contactEmail: "contact@malaysianpalmoil.com",
    contactPhone: "+60 (3) 1234-5678",
    yearEstablished: 1995,
    employeeCount: "500-1000",
    specialties: ["Crude Palm Oil", "Palm Kernel Oil", "Sustainable Palm Oil"],
    languages: ["Malay", "English", "Chinese"],
  },
  {
    id: "p40",
    name: "Greek Olive Products",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Oils",
    country: "Greece",
    city: "Athens",
    coordinates: [37.9838, 23.7275],
    rating: 4.8,
    verified: true,
    description: "Premium Greek olive oil and products with traditional Mediterranean quality.",
    logo: "/placeholder.svg?height=80&width=80&text=GOP",
    website: "https://example.com/greekolive",
    contactPerson: "Nikos Papadopoulos",
    contactEmail: "contact@greekolive.com",
    contactPhone: "+30 (21) 0123-4567",
    yearEstablished: 1980,
    employeeCount: "50-100",
    specialties: ["Extra Virgin Olive Oil", "Olives", "Olive-based Products"],
    languages: ["Greek", "English", "German"],
  },
  {
    id: "p41",
    name: "Kenyan Tea Exporters",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Tea",
    country: "Kenya",
    city: "Nairobi",
    coordinates: [-1.2921, 36.8219],
    rating: 4.6,
    verified: true,
    description: "Premium Kenyan tea with rich flavors from the highlands of East Africa.",
    logo: "/placeholder.svg?height=80&width=80&text=KTE",
    website: "https://example.com/kenyantea",
    contactPerson: "James Kimani",
    contactEmail: "contact@kenyantea.com",
    contactPhone: "+254 (20) 123-4567",
    yearEstablished: 1992,
    employeeCount: "100-500",
    specialties: ["Black Tea", "Green Tea", "Specialty Tea"],
    languages: ["English", "Swahili"],
  },
  {
    id: "p42",
    name: "Austrian Precision Engineering",
    type: "seller",
    category: "Manufacturing",
    subcategory: "Machinery",
    country: "Austria",
    city: "Vienna",
    coordinates: [48.2082, 16.3738],
    rating: 4.8,
    verified: true,
    description: "High-precision machinery and engineering solutions with Austrian quality standards.",
    logo: "/placeholder.svg?height=80&width=80&text=APE",
    website: "https://example.com/austrianengineering",
    contactPerson: "Thomas Wagner",
    contactEmail: "contact@austrianengineering.com",
    contactPhone: "+43 (1) 123-45678",
    yearEstablished: 1985,
    employeeCount: "100-500",
    specialties: ["Industrial Machinery", "Automation Systems", "Precision Tools"],
    languages: ["German", "English", "French"],
  },
  {
    id: "p43",
    name: "Peruvian Textile Cooperative",
    type: "seller",
    category: "Textiles",
    subcategory: "Traditional Textiles",
    country: "Peru",
    city: "Lima",
    coordinates: [-12.0464, -77.0428],
    rating: 4.7,
    verified: true,
    description: "Authentic Peruvian textiles with traditional Andean techniques and natural materials.",
    logo: "/placeholder.svg?height=80&width=80&text=PTC",
    website: "https://example.com/peruviantextiles",
    contactPerson: "Maria Sanchez",
    contactEmail: "contact@peruviantextiles.com",
    contactPhone: "+51 (1) 123-4567",
    yearEstablished: 2000,
    employeeCount: "10-50",
    specialties: ["Alpaca Wool", "Traditional Weaving", "Natural Dyes"],
    languages: ["Spanish", "English", "Quechua"],
  },
  {
    id: "p44",
    name: "Finnish Wood Products",
    type: "seller",
    category: "Forestry",
    subcategory: "Wood Products",
    country: "Finland",
    city: "Helsinki",
    coordinates: [60.1699, 24.9384],
    rating: 4.8,
    verified: true,
    description: "Sustainable wood products from Finland's managed forests with Nordic quality.",
    logo: "/placeholder.svg?height=80&width=80&text=FWP",
    website: "https://example.com/finnishwood",
    contactPerson: "Mikko Virtanen",
    contactEmail: "contact@finnishwood.com",
    contactPhone: "+358 (9) 123-4567",
    yearEstablished: 1990,
    employeeCount: "100-500",
    specialties: ["Timber", "Plywood", "Wooden Furniture"],
    languages: ["Finnish", "Swedish", "English"],
  },
  {
    id: "p45",
    name: "Hungarian Agricultural Cooperative",
    type: "seller",
    category: "Agriculture",
    subcategory: "Grains",
    country: "Hungary",
    city: "Budapest",
    coordinates: [47.4979, 19.0402],
    rating: 4.5,
    verified: true,
    description: "Quality grains and agricultural products from Hungary's fertile plains.",
    logo: "/placeholder.svg?height=80&width=80&text=HAC",
    website: "https://example.com/hungarianagri",
    contactPerson: "István Nagy",
    contactEmail: "contact@hungarianagri.com",
    contactPhone: "+36 (1) 123-4567",
    yearEstablished: 1995,
    employeeCount: "50-100",
    specialties: ["Wheat", "Corn", "Sunflower"],
    languages: ["Hungarian", "English", "German"],
  },
  {
    id: "p46",
    name: "Belgian Chocolate Manufacturers",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Chocolate",
    country: "Belgium",
    city: "Brussels",
    coordinates: [50.8503, 4.3517],
    rating: 4.9,
    verified: true,
    description: "Exquisite Belgian chocolates with traditional craftsmanship and premium ingredients.",
    logo: "/placeholder.svg?height=80&width=80&text=BCM",
    website: "https://example.com/belgianchocolate",
    contactPerson: "Sophie Dubois",
    contactEmail: "contact@belgianchocolate.com",
    contactPhone: "+32 (2) 123-4567",
    yearEstablished: 1975,
    employeeCount: "50-100",
    specialties: ["Pralines", "Truffles", "Chocolate Bars"],
    languages: ["Dutch", "French", "English", "German"],
  },
  {
    id: "p47",
    name: "Indonesian Furniture Crafters",
    type: "seller",
    category: "Manufacturing",
    subcategory: "Furniture",
    country: "Indonesia",
    city: "Jakarta",
    coordinates: [-6.2088, 106.8456],
    rating: 4.6,
    verified: true,
    description: "Handcrafted furniture with Indonesian teak and traditional craftsmanship.",
    logo: "/placeholder.svg?height=80&width=80&text=IFC",
    website: "https://example.com/indonesianfurniture",
    contactPerson: "Budi Santoso",
    contactEmail: "contact@indonesianfurniture.com",
    contactPhone: "+62 (21) 1234-5678",
    yearEstablished: 1998,
    employeeCount: "100-500",
    specialties: ["Teak Furniture", "Rattan Furniture", "Carved Wood"],
    languages: ["Indonesian", "English", "Chinese"],
  },
  {
    id: "p48",
    name: "Czech Glass Artisans",
    type: "seller",
    category: "Handicrafts",
    subcategory: "Glass",
    country: "Czech Republic",
    city: "Prague",
    coordinates: [50.0755, 14.4378],
    rating: 4.8,
    verified: true,
    description: "Exquisite Czech glass and crystal with traditional European craftsmanship.",
    logo: "/placeholder.svg?height=80&width=80&text=CGA",
    website: "https://example.com/czechglass",
    contactPerson: "Pavel Novak",
    contactEmail: "contact@czechglass.com",
    contactPhone: "+420 (2) 1234-5678",
    yearEstablished: 1980,
    employeeCount: "50-100",
    specialties: ["Crystal", "Art Glass", "Glass Jewelry"],
    languages: ["Czech", "English", "German"],
  },
  {
    id: "p49",
    name: "Portuguese Wine Exporters",
    type: "seller",
    category: "Food & Beverage",
    subcategory: "Wine",
    country: "Portugal",
    city: "Lisbon",
    coordinates: [38.7223, -9.1393],
    rating: 4.7,
    verified: true,
    description: "Premium Portuguese wines with traditional winemaking and unique terroirs.",
    logo: "/placeholder.svg?height=80&width=80&text=PWE",
    website: "https://example.com/portuguesewine",
    contactPerson: "Miguel Silva",
    contactEmail: "contact@portuguesewine.com",
    contactPhone: "+351 (21) 123-4567",
    yearEstablished: 1990,
    employeeCount: "50-100",
    specialties: ["Port Wine", "Red Wine", "Vinho Verde"],
    languages: ["Portuguese", "English", "Spanish"],
  },
  {
    id: "p50",
    name: "Ukrainian Grain Exporters",
    type: "seller",
    category: "Agriculture",
    subcategory: "Grains",
    country: "Ukraine",
    city: "Kyiv",
    coordinates: [50.4501, 30.5234],
    rating: 4.5,
    verified: true,
    description: "High-quality grains from Ukraine's fertile black soil with modern farming practices.",
    logo: "/placeholder.svg?height=80&width=80&text=UGE",
    website: "https://example.com/ukrainiangrain",
    contactPerson: "Oleksandr Shevchenko",
    contactEmail: "contact@ukrainiangrain.com",
    contactPhone: "+380 (44) 123-4567",
    yearEstablished: 2000,
    employeeCount: "100-500",
    specialties: ["Wheat", "Corn", "Barley"],
    languages: ["Ukrainian", "Russian", "English"],
  },
]

// Categories for filtering
const categories = [
  "Technology",
  "Agriculture",
  "Manufacturing",
  "Textiles",
  "Electronics",
  "Mining",
  "Trading",
  "Forestry",
  "Food & Beverage",
  "Luxury",
  "Handicrafts",
  "Fashion",
  "Energy",
  "Automotive",
  "Retail",
  "Home & Decor",
]

// Countries for filtering
const countries = Array.from(new Set(partnersData.map((partner) => partner.country))).sort()

export default function GlobalMapPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedType, setSelectedType] = useState<string>("all")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [selectedCountry, setSelectedCountry] = useState<string>("all")
  const [filteredPartners, setFilteredPartners] = useState<Partner[]>(partnersData)
  const [selectedPartner, setSelectedPartner] = useState<Partner | null>(null)
  const [showFilters, setShowFilters] = useState(true)
  const [showAIChat, setShowAIChat] = useState(false)
  const [showPartnerChat, setShowPartnerChat] = useState(false)
  const [chatMessages, setChatMessages] = useState<{ role: string; content: string }[]>([
    {
      role: "assistant",
      content: "Hello! I'm your AI assistant for finding global partners. How can I help you today?",
    },
  ])
  const [chatInput, setChatInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const mapRef = useRef<HTMLDivElement>(null)

  // Current user mock data
  const currentUser = {
    id: "user1",
    name: "Guest User",
    avatar: "/placeholder.svg?height=80&width=80&text=YOU",
    type: "buyer" as const,
  }

  // Filter partners based on search and filters
  useEffect(() => {
    let filtered = partnersData

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (partner) =>
          partner.name.toLowerCase().includes(query) ||
          partner.description.toLowerCase().includes(query) ||
          partner.category.toLowerCase().includes(query) ||
          partner.country.toLowerCase().includes(query) ||
          partner.city.toLowerCase().includes(query),
      )
    }

    // Filter by type
    if (selectedType !== "all") {
      filtered = filtered.filter(
        (partner) => partner.type === selectedType || (selectedType === "both" && partner.type === "both"),
      )
    }

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter((partner) => partner.category === selectedCategory)
    }

    // Filter by country
    if (selectedCountry !== "all") {
      filtered = filtered.filter((partner) => partner.country === selectedCountry)
    }

    setFilteredPartners(filtered)
  }, [searchQuery, selectedType, selectedCategory, selectedCountry])

  // Handle AI chat interaction
  const handleSendMessage = () => {
    if (!chatInput.trim()) return

    // Add user message
    setChatMessages((prev) => [...prev, { role: "user", content: chatInput }])
    setIsLoading(true)

    // Simulate AI response
    setTimeout(() => {
      let response = ""
      const query = chatInput.toLowerCase()

      // Generate contextual responses based on user query
      if (query.includes("find") || query.includes("search") || query.includes("looking for")) {
        if (query.includes("technology") || query.includes("tech") || query.includes("software")) {
          response =
            "I can help you find technology partners! We have several tech companies in our network, including Global Tech Solutions (USA), Singapore Tech Innovations, and Israeli Tech Startups. Would you like me to filter for technology partners from a specific region?"
        } else if (query.includes("food") || query.includes("agriculture") || query.includes("farm")) {
          response =
            "We have many food and agricultural partners in our network. Some notable ones include EcoFarm Produce (Brazil), Indian Spice Exporters, and New Zealand Dairy Cooperative. Would you like more specific information about any of these partners?"
        } else {
          response =
            "I'd be happy to help you find partners! Could you specify what industry or region you're interested in? We have partners across various sectors including Technology, Manufacturing, Agriculture, and more."
        }
      } else if (query.includes("contact") || query.includes("connect")) {
        response =
          "To connect with a partner, you can select them from the map or search results, then click the 'Chat with Partner' or 'Visit Website' buttons on their profile. Would you like me to recommend some partners based on your needs?"
      } else if (query.includes("how") && query.includes("work")) {
        response =
          "Our Global Map helps you find and connect with partners worldwide. You can filter by country, category, or partner type, and click on the glowing markers to view detailed information. Once you find a suitable partner, you can contact them directly through our platform."
      } else {
        response =
          "Thank you for your message. I can help you find global partners based on your business needs. Could you tell me more about what type of partners you're looking for? For example, are you interested in specific industries, regions, or partner types (buyers/sellers)?"
      }

      setChatMessages((prev) => [...prev, { role: "assistant", content: response }])
      setChatInput("")
      setIsLoading(false)
    }, 1000)
  }

  // Simulate map interaction (in a real app, this would use a map library like Mapbox or Google Maps)
  const handleMapClick = (e: React.MouseEvent) => {
    // In a real implementation, this would get coordinates from the map click
    // For demo purposes, we'll just select a random partner
    const randomIndex = Math.floor(Math.random() * filteredPartners.length)
    setSelectedPartner(filteredPartners[randomIndex])
  }

  return (
    <div className="container mx-auto py-6 px-4 md:px-6 max-w-7xl">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Global Partner Map</h1>
          <p className="text-muted-foreground">Find and connect with partners worldwide</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="h-4 w-4" />
            {showFilters ? "Hide Filters" : "Show Filters"}
          </Button>
          <Button className="gap-2" onClick={() => setShowAIChat(!showAIChat)}>
            <MessageSquare className="h-4 w-4" />
            AI Assistant
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6">
        {/* Filters Panel */}
        {showFilters && (
          <Card className="h-[calc(100vh-200px)] overflow-y-auto">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between">
                <span>Search Filters</span>
                <Button variant="ghost" size="icon" className="h-8 w-8 lg:hidden" onClick={() => setShowFilters(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </CardTitle>
              <CardDescription>Find partners by location, category, and more</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="search">Search</Label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="search"
                    placeholder="Search partners..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="partner-type">Partner Type</Label>
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger id="partner-type">
                    <SelectValue placeholder="Select partner type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="buyer">Buyers</SelectItem>
                    <SelectItem value="seller">Sellers</SelectItem>
                    <SelectItem value="both">Both (Buyers & Sellers)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Select value={selectedCountry} onValueChange={setSelectedCountry}>
                  <SelectTrigger id="country">
                    <SelectValue placeholder="Select country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Countries</SelectItem>
                    {countries.map((country) => (
                      <SelectItem key={country} value={country}>
                        {country}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Verification Status</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox id="verified" defaultChecked />
                  <label
                    htmlFor="verified"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Show verified partners only
                  </label>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Minimum Rating</Label>
                  <span className="text-sm text-muted-foreground">4.5+</span>
                </div>
                <Slider defaultValue={[4.5]} min={1} max={5} step={0.1} />
              </div>

              <div className="pt-4 border-t">
                <Button className="w-full">Apply Filters</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Map and Results */}
        <div className="space-y-6">
          {/* Interactive Map */}
          <Card className="overflow-hidden">
            <CardHeader className="pb-3">
              <CardTitle>Interactive Global Map</CardTitle>
              <CardDescription>Click on glowing markers to view partner details</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div ref={mapRef} className="relative h-[400px] bg-muted/30 cursor-pointer" onClick={handleMapClick}>
                {/* Placeholder for the actual map */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=400&width=800&text=Interactive+World+Map"
                    alt="World Map"
                    fill
                    className="object-cover"
                  />
                </div>

                {/* Sample glowing markers - in a real implementation, these would be positioned based on coordinates */}
                {filteredPartners.slice(0, 20).map((partner, index) => (
                  <TooltipProvider key={partner.id}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <div
                          className="absolute w-3 h-3 rounded-full bg-primary animate-pulse shadow-[0_0_10px_rgba(var(--primary-rgb),0.7)] cursor-pointer z-10"
                          style={{
                            left: `${(Math.abs(partner.coordinates[1] + 180) / 360) * 100}%`,
                            top: `${(Math.abs(partner.coordinates[0] - 90) / 180) * 100}%`,
                          }}
                          onClick={(e) => {
                            e.stopPropagation()
                            setSelectedPartner(partner)
                          }}
                        />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="font-medium">{partner.name}</p>
                        <p className="text-xs">
                          {partner.city}, {partner.country}
                        </p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                ))}
              </div>
            </CardContent>
            <CardFooter className="bg-muted/10 p-3 text-xs text-muted-foreground">
              Showing {filteredPartners.length} partners across{" "}
              {Array.from(new Set(filteredPartners.map((p) => p.country))).length} countries
            </CardFooter>
          </Card>

          {/* Selected Partner Details */}
          {selectedPartner && (
            <Card className="border-primary/20 shadow-md shadow-primary/5">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-3">
                    <div className="relative w-12 h-12 rounded-md overflow-hidden border">
                      <Image
                        src={selectedPartner.logo || "/placeholder.svg"}
                        alt={selectedPartner.name}
                        fill
                        className="object-cover glow-image"
                      />
                    </div>
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {selectedPartner.name}
                        {selectedPartner.verified && (
                          <Badge variant="secondary" className="ml-2">
                            Verified
                          </Badge>
                        )}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {selectedPartner.city}, {selectedPartner.country}
                      </CardDescription>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.floor(selectedPartner.rating)
                            ? "text-amber-500 fill-amber-500"
                            : i < selectedPartner.rating
                              ? "text-amber-500 fill-amber-500/50"
                              : "text-muted-foreground"
                        }`}
                      />
                    ))}
                    <span className="text-sm font-medium ml-1">{selectedPartner.rating}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-1">About</h3>
                  <p className="text-sm text-muted-foreground">{selectedPartner.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="text-sm font-medium mb-1">Partner Type</h3>
                    <Badge variant="outline" className="capitalize">
                      {selectedPartner.type === "both" ? "Buyer & Seller" : selectedPartner.type}
                    </Badge>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-1">Category</h3>
                    <Badge variant="outline">{selectedPartner.category}</Badge>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-1">Established</h3>
                    <p className="text-sm text-muted-foreground">{selectedPartner.yearEstablished}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium mb-1">Size</h3>
                    <p className="text-sm text-muted-foreground">{selectedPartner.employeeCount} employees</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-1">Specialties</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedPartner.specialties.map((specialty, index) => (
                      <Badge key={index} variant="secondary">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-1">Contact Information</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedPartner.contactPerson}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedPartner.contactEmail}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{selectedPartner.contactPhone}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between gap-4">
                <Button className="w-full gap-2" onClick={() => setShowPartnerChat(true)}>
                  <MessageSquare className="h-4 w-4" />
                  Chat with Partner
                </Button>
                <Button
                  variant="outline"
                  className="w-full gap-2"
                  onClick={() => window.open(selectedPartner.website, "_blank")}
                >
                  <ExternalLink className="h-4 w-4" />
                  Visit Website
                </Button>
              </CardFooter>
            </Card>
          )}

          {/* Partner Results */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Partner Results</h2>
              <span className="text-sm text-muted-foreground">{filteredPartners.length} partners found</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredPartners.slice(0, 6).map((partner) => (
                <Card
                  key={partner.id}
                  className="overflow-hidden hover:shadow-md transition-shadow cursor-pointer border-muted"
                  onClick={() => setSelectedPartner(partner)}
                >
                  <div className="relative h-12 bg-muted/30 flex items-center px-4">
                    <div className="relative w-8 h-8 rounded-md overflow-hidden border">
                      <Image
                        src={partner.logo || "/placeholder.svg"}
                        alt={partner.name}
                        fill
                        className="object-cover glow-image"
                      />
                    </div>
                    <div className="ml-3 flex-1 truncate">
                      <h3 className="font-medium text-sm truncate">{partner.name}</h3>
                      <p className="text-xs text-muted-foreground truncate">
                        {partner.city}, {partner.country}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="h-3 w-3 text-amber-500 fill-amber-500" />
                      <span className="text-xs font-medium">{partner.rating}</span>
                    </div>
                  </div>
                  <CardContent className="p-3">
                    <p className="text-xs text-muted-foreground line-clamp-2">{partner.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline" className="text-xs capitalize">
                        {partner.type === "both" ? "Buyer & Seller" : partner.type}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {partner.category}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredPartners.length > 6 && (
              <div className="text-center mt-4">
                <Button variant="outline">View All {filteredPartners.length} Partners</Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AI Chat Assistant */}
      {showAIChat && (
        <div className="fixed bottom-6 right-6 w-96 h-[500px] bg-background border rounded-lg shadow-lg flex flex-col z-50">
          <div className="p-3 border-b flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Zap className="h-4 w-4 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-sm">AI Partner Assistant</h3>
                <p className="text-xs text-muted-foreground">Helping you find the right partners</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowAIChat(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {chatMessages.map((message, index) => (
              <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="max-w-[80%] rounded-lg p-3 bg-muted">
                  <div className="flex space-x-2">
                    <div className="h-2 w-2 bg-primary rounded-full animate-bounce"></div>
                    <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-75"></div>
                    <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-150"></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-3 border-t">
            <div className="flex gap-2">
              <Input
                placeholder="Ask about finding partners..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
              />
              <Button size="icon" onClick={handleSendMessage} disabled={!chatInput.trim() || isLoading}>
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-4 w-4"
                >
                  <path d="m22 2-7 20-4-9-9-4Z" />
                  <path d="M22 2 11 13" />
                </svg>
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Partner Chat Dialog */}
      <PartnerChat
        isOpen={showPartnerChat}
        onClose={() => setShowPartnerChat(false)}
        partner={selectedPartner || undefined}
        currentUser={currentUser}
      />
    </div>
  )
}

