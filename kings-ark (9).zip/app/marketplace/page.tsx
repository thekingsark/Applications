"use client"

import { useState } from "react"
import {
  Search,
  Filter,
  Grid,
  List,
  Star,
  Clock,
  ArrowLeft,
  MessageSquare,
  Plus,
  Minus,
  ShoppingCart,
  Calendar,
  Users,
  Globe,
  FileText,
  Upload,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import Link from "next/link"
import PartnerChat from "@/components/partner-chat"
import type { Partner } from "@/types"

// Import the partners data from the global map page
import { partnersData } from "../global-map/partners-data"

// Product interface
interface Product {
  id: string
  name: string
  description: string
  price: number
  discountPrice?: number
  currency: string
  images: string[]
  category: string
  subcategory: string
  tags: string[]
  rating: number
  reviewCount: number
  stock: number
  seller: Partner
  location: string
  shippingOptions: {
    method: string
    price: number
    estimatedDelivery: string
  }[]
  specifications: Record<string, string>
  createdAt: Date
  featured: boolean
  bestseller: boolean
  condition: "new" | "used" | "refurbished"
  minOrder?: number
  maxOrder?: number
  bulkPricing?: {
    quantity: number
    price: number
  }[]
}

// Outsourcing project interface
interface OutsourcingProject {
  id: string
  title: string
  description: string
  budget: {
    min: number
    max: number
    currency: string
  }
  deadline: Date
  category: string
  subcategory: string
  skills: string[]
  attachments?: string[]
  location?: string
  buyer: Partner
  status: "open" | "in_progress" | "completed" | "cancelled"
  bids: {
    seller: Partner
    amount: number
    deliveryTime: number
    proposal: string
    createdAt: Date
  }[]
  createdAt: Date
  views: number
}

// Generate sample products based on partners data
const generateSampleProducts = (): Product[] => {
  const categories = [
    "Electronics",
    "Manufacturing",
    "Agriculture",
    "Textiles",
    "Furniture",
    "Automotive",
    "Food & Beverage",
    "Chemicals",
    "Pharmaceuticals",
    "Construction",
  ]

  const subcategories: Record<string, string[]> = {
    Electronics: ["Smartphones", "Computers", "Components", "Accessories", "Office Equipment"],
    Manufacturing: ["Machinery", "Tools", "Industrial Supplies", "Safety Equipment", "Packaging"],
    Agriculture: ["Seeds", "Fertilizers", "Farm Equipment", "Irrigation Systems", "Organic Products"],
    Textiles: ["Fabrics", "Clothing", "Home Textiles", "Industrial Textiles", "Raw Materials"],
    Furniture: ["Office Furniture", "Home Furniture", "Outdoor Furniture", "Hospitality Furniture", "Custom Designs"],
    Automotive: ["Parts & Components", "Accessories", "Tools", "Maintenance Products", "Electronics"],
    "Food & Beverage": ["Processed Foods", "Beverages", "Ingredients", "Organic Products", "Specialty Items"],
    Chemicals: [
      "Industrial Chemicals",
      "Agricultural Chemicals",
      "Cleaning Products",
      "Specialty Chemicals",
      "Raw Materials",
    ],
    Pharmaceuticals: ["Medications", "Medical Supplies", "Equipment", "Supplements", "Raw Materials"],
    Construction: ["Building Materials", "Tools", "Equipment", "Safety Gear", "Fixtures"],
  }

  const conditions = ["new", "used", "refurbished"] as const

  // Filter partners who are sellers or both
  const sellers = partnersData.filter((partner) => partner.type === "seller" || partner.type === "both")

  const products: Product[] = []

  // Generate 30 sample products
  for (let i = 1; i <= 30; i++) {
    const category = categories[Math.floor(Math.random() * categories.length)]
    const subcategory = subcategories[category][Math.floor(Math.random() * subcategories[category].length)]
    const seller = sellers[Math.floor(Math.random() * sellers.length)]
    const price = Math.floor(Math.random() * 9900) + 100 // $100 to $10,000
    const hasDiscount = Math.random() > 0.7
    const discountPrice = hasDiscount ? Math.floor(price * (0.7 + Math.random() * 0.2)) : undefined
    const condition = conditions[Math.floor(Math.random() * conditions.length)]
    const hasBulkPricing = Math.random() > 0.6

    const bulkPricing = hasBulkPricing
      ? [
          { quantity: 10, price: Math.floor(price * 0.9) },
          { quantity: 25, price: Math.floor(price * 0.85) },
          { quantity: 50, price: Math.floor(price * 0.8) },
          { quantity: 100, price: Math.floor(price * 0.75) },
        ]
      : undefined

    const minOrder = Math.random() > 0.5 ? Math.floor(Math.random() * 5) + 1 : undefined
    const maxOrder = minOrder && Math.random() > 0.5 ? minOrder + Math.floor(Math.random() * 95) + 5 : undefined

    products.push({
      id: `prod-${i}`,
      name: `${seller.name} ${category} - ${subcategory} Product ${i}`,
      description: `High-quality ${subcategory.toLowerCase()} from ${seller.name}, designed for professional use. This product features premium materials, excellent craftsmanship, and meets all industry standards.`,
      price,
      discountPrice,
      currency: "USD",
      images: [
        `/placeholder.svg?height=300&width=300&text=Product+${i}`,
        `/placeholder.svg?height=300&width=300&text=Product+${i}+View+2`,
        `/placeholder.svg?height=300&width=300&text=Product+${i}+View+3`,
      ],
      category,
      subcategory,
      tags: [category, subcategory, seller.country, condition],
      rating: 3 + Math.random() * 2,
      reviewCount: Math.floor(Math.random() * 500) + 1,
      stock: Math.floor(Math.random() * 1000) + 1,
      seller,
      location: `${seller.city}, ${seller.country}`,
      shippingOptions: [
        {
          method: "Standard",
          price: Math.floor(Math.random() * 50) + 10,
          estimatedDelivery: "7-14 business days",
        },
        {
          method: "Express",
          price: Math.floor(Math.random() * 100) + 50,
          estimatedDelivery: "3-5 business days",
        },
      ],
      specifications: {
        Material: ["Metal", "Plastic", "Wood", "Fabric", "Composite"][Math.floor(Math.random() * 5)],
        Dimensions: `${Math.floor(Math.random() * 100) + 10}cm x ${Math.floor(Math.random() * 100) + 10}cm x ${Math.floor(Math.random() * 50) + 5}cm`,
        Weight: `${Math.floor(Math.random() * 100) + 1}kg`,
        Warranty: `${Math.floor(Math.random() * 5) + 1} years`,
        "Country of Origin": seller.country,
      },
      createdAt: new Date(Date.now() - Math.floor(Math.random() * 90) * 24 * 60 * 60 * 1000),
      featured: Math.random() > 0.8,
      bestseller: Math.random() > 0.8,
      condition,
      minOrder,
      maxOrder,
      bulkPricing,
    })
  }

  return products
}

// Generate sample outsourcing projects
const generateSampleProjects = (): OutsourcingProject[] => {
  const categories = [
    "Manufacturing",
    "Software Development",
    "Design",
    "Marketing",
    "Logistics",
    "Consulting",
    "Research",
    "Content Creation",
    "Engineering",
    "Customer Support",
  ]

  const subcategories: Record<string, string[]> = {
    Manufacturing: ["Product Assembly", "Custom Fabrication", "Packaging", "Quality Control", "Prototyping"],
    "Software Development": ["Web Development", "Mobile Apps", "Enterprise Software", "API Integration", "Maintenance"],
    Design: ["Product Design", "Packaging Design", "Logo & Branding", "UI/UX Design", "CAD Design"],
    Marketing: ["Digital Marketing", "Market Research", "Content Marketing", "Social Media", "SEO/SEM"],
    Logistics: ["Warehousing", "Distribution", "Supply Chain Management", "Inventory Management", "Shipping"],
    Consulting: ["Business Strategy", "Operations", "Financial", "IT Consulting", "Market Entry"],
    Research: ["Market Research", "Product Research", "Competitive Analysis", "User Research", "Technical Research"],
    "Content Creation": ["Technical Writing", "Translation", "Video Production", "Photography", "Copywriting"],
    Engineering: ["Mechanical", "Electrical", "Civil", "Chemical", "Environmental"],
    "Customer Support": ["Call Center", "Technical Support", "Customer Service", "Help Desk", "CRM Management"],
  }

  // Filter partners who are buyers or both
  const buyers = partnersData.filter((partner) => partner.type === "buyer" || partner.type === "both")
  // Filter partners who are sellers or both for bids
  const sellers = partnersData.filter((partner) => partner.type === "seller" || partner.type === "both")

  const projects: OutsourcingProject[] = []

  // Generate 20 sample projects
  for (let i = 1; i <= 20; i++) {
    const category = categories[Math.floor(Math.random() * categories.length)]
    const subcategory = subcategories[category][Math.floor(Math.random() * subcategories[category].length)]
    const buyer = buyers[Math.floor(Math.random() * buyers.length)]
    const minBudget = Math.floor(Math.random() * 9000) + 1000 // $1,000 to $10,000
    const maxBudget = minBudget + Math.floor(Math.random() * 10000) // $1,000 to $10,000 more than minBudget

    // Generate random deadline between 7 and 90 days from now
    const deadline = new Date()
    deadline.setDate(deadline.getDate() + Math.floor(Math.random() * 83) + 7)

    // Generate random creation date in the past 30 days
    const createdAt = new Date()
    createdAt.setDate(createdAt.getDate() - Math.floor(Math.random() * 30))

    // Generate random skills based on category
    const skillsByCategory: Record<string, string[]> = {
      Manufacturing: ["CNC Machining", "3D Printing", "Injection Molding", "Welding", "Assembly", "Quality Control"],
      "Software Development": ["JavaScript", "Python", "React", "Node.js", "AWS", "Database Design", "API Development"],
      Design: ["Adobe Creative Suite", "Sketch", "Figma", "3D Modeling", "CAD", "Branding"],
      Marketing: ["SEO", "SEM", "Social Media", "Content Strategy", "Analytics", "Email Marketing"],
      Logistics: ["Supply Chain Management", "Inventory Control", "Route Optimization", "Customs Clearance"],
      Consulting: ["Business Analysis", "Process Improvement", "Change Management", "Risk Assessment"],
      Research: ["Data Analysis", "Survey Design", "Competitive Analysis", "Focus Groups", "Market Trends"],
      "Content Creation": ["Copywriting", "Video Editing", "Translation", "Technical Writing", "Scriptwriting"],
      Engineering: ["AutoCAD", "Structural Analysis", "Circuit Design", "Thermodynamics", "Fluid Mechanics"],
      "Customer Support": ["CRM Systems", "Ticketing Systems", "Multilingual Support", "Technical Troubleshooting"],
    }

    const availableSkills = skillsByCategory[category] || []
    const numSkills = Math.floor(Math.random() * 3) + 2 // 2-4 skills
    const skills: string[] = []

    for (let j = 0; j < numSkills; j++) {
      if (availableSkills.length > 0) {
        const randomIndex = Math.floor(Math.random() * availableSkills.length)
        skills.push(availableSkills[randomIndex])
        availableSkills.splice(randomIndex, 1)
      }
    }

    // Generate random number of bids (0-5)
    const numBids = Math.floor(Math.random() * 6)
    const bids = []

    for (let j = 0; j < numBids; j++) {
      const seller = sellers[Math.floor(Math.random() * sellers.length)]
      const bidAmount = minBudget + Math.floor(Math.random() * (maxBudget - minBudget))
      const deliveryDays = Math.floor(Math.random() * 60) + 5 // 5-65 days

      bids.push({
        seller,
        amount: bidAmount,
        deliveryTime: deliveryDays,
        proposal: `We at ${seller.name} are excited to work on your ${subcategory} project. With our expertise in ${skills.join(", ")}, we can deliver high-quality results within ${deliveryDays} days. Our team has successfully completed similar projects for clients in ${seller.specialties.join(", ")}.`,
        createdAt: new Date(createdAt.getTime() + Math.floor(Math.random() * (Date.now() - createdAt.getTime()))),
      })
    }

    projects.push({
      id: `proj-${i}`,
      title: `${subcategory} Project for ${buyer.name}`,
      description: `${buyer.name} is looking for an experienced partner for a ${subcategory} project. We need expertise in ${skills.join(", ")}. The project involves developing/creating/implementing a comprehensive solution that meets our specific requirements and industry standards.`,
      budget: {
        min: minBudget,
        max: maxBudget,
        currency: "USD",
      },
      deadline,
      category,
      subcategory,
      skills,
      attachments:
        Math.random() > 0.5
          ? [
              `/placeholder.svg?height=100&width=100&text=Attachment+1`,
              `/placeholder.svg?height=100&width=100&text=Attachment+2`,
            ]
          : undefined,
      location: buyer.country,
      buyer,
      status: "open",
      bids,
      createdAt,
      views: Math.floor(Math.random() * 500) + 10,
    })
  }

  return projects
}

// Generate sample data
const sampleProducts = generateSampleProducts()
const sampleProjects = generateSampleProjects()

// Categories for filtering
const productCategories = Array.from(new Set(sampleProducts.map((product) => product.category))).sort()
const projectCategories = Array.from(new Set(sampleProjects.map((project) => project.category))).sort()

export default function MarketplacePage() {
  // State for marketplace
  const [activeTab, setActiveTab] = useState("products")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [selectedCondition, setSelectedCondition] = useState<string>("all")
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000])
  const [sortBy, setSortBy] = useState<string>("featured")
  const [showFilters, setShowFilters] = useState(true)

  // State for product details
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [selectedImage, setSelectedImage] = useState<string>("")
  const [quantity, setQuantity] = useState<number>(1)
  const [selectedShipping, setSelectedShipping] = useState<string>("")

  // State for project details
  const [selectedProject, setSelectedProject] = useState<OutsourcingProject | null>(null)
  const [bidAmount, setBidAmount] = useState<number>(0)
  const [bidDeliveryTime, setBidDeliveryTime] = useState<number>(30)
  const [bidProposal, setBidProposal] = useState<string>("")

  // State for creating new listings
  const [isCreateProductOpen, setIsCreateProductOpen] = useState(false)
  const [isCreateProjectOpen, setIsCreateProjectOpen] = useState(false)

  // State for chat
  const [showPartnerChat, setShowPartnerChat] = useState(false)
  const [chatPartner, setChatPartner] = useState<Partner | null>(null)

  // Current user mock data (for demo purposes)
  const currentUser = {
    id: "user1",
    name: "Your Company",
    avatar: "/placeholder.svg?height=80&width=80&text=YOU",
    type: "both" as const,
  }

  // Filter products based on search and filters
  const filteredProducts = sampleProducts.filter((product) => {
    // Search query filter
    if (
      searchQuery &&
      !product.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !product.description.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !product.category.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !product.subcategory.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !product.seller.name.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    // Category filter
    if (selectedCategory !== "all" && product.category !== selectedCategory) {
      return false
    }

    // Condition filter
    if (selectedCondition !== "all" && product.condition !== selectedCondition) {
      return false
    }

    // Price range filter
    if (product.price < priceRange[0] || product.price > priceRange[1]) {
      return false
    }

    return true
  })

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "newest":
        return b.createdAt.getTime() - a.createdAt.getTime()
      case "rating":
        return b.rating - a.rating
      case "featured":
      default:
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0) || (b.bestseller ? 1 : 0) - (a.bestseller ? 1 : 0)
    }
  })

  // Filter projects based on search and filters
  const filteredProjects = sampleProjects.filter((project) => {
    // Search query filter
    if (
      searchQuery &&
      !project.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !project.description.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !project.category.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !project.subcategory.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !project.buyer.name.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false
    }

    // Category filter
    if (selectedCategory !== "all" && project.category !== selectedCategory) {
      return false
    }

    return true
  })

  // Sort projects
  const sortedProjects = [...filteredProjects].sort((a, b) => {
    switch (sortBy) {
      case "budget-high":
        return b.budget.max - a.budget.max
      case "budget-low":
        return a.budget.min - b.budget.min
      case "deadline":
        return a.deadline.getTime() - b.deadline.getTime()
      case "newest":
        return b.createdAt.getTime() - a.createdAt.getTime()
      default:
        return b.createdAt.getTime() - a.createdAt.getTime()
    }
  })

  // Handle product selection
  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product)
    setSelectedImage(product.images[0])
    setQuantity(product.minOrder || 1)
    setSelectedShipping(product.shippingOptions[0].method)
  }

  // Handle project selection
  const handleProjectSelect = (project: OutsourcingProject) => {
    setSelectedProject(project)
    setBidAmount(project.budget.min)
    setBidDeliveryTime(30)
    setBidProposal("")
  }

  // Handle quantity change
  const handleQuantityChange = (newQuantity: number) => {
    if (!selectedProduct) return

    const min = selectedProduct.minOrder || 1
    const max = selectedProduct.maxOrder || 9999

    if (newQuantity < min) {
      setQuantity(min)
    } else if (newQuantity > max) {
      setQuantity(max)
    } else {
      setQuantity(newQuantity)
    }
  }

  // Calculate product price based on quantity (bulk pricing)
  const calculatePrice = (product: Product | null, qty: number): number => {
    if (!product) return 0
    if (!product.bulkPricing) return product.discountPrice || product.price

    // Find the applicable bulk price tier
    for (let i = product.bulkPricing.length - 1; i >= 0; i--) {
      if (qty >= product.bulkPricing[i].quantity) {
        return product.bulkPricing[i].price
      }
    }

    return product.discountPrice || product.price
  }

  // Handle chat with partner
  const handleChatWithPartner = (partner: Partner) => {
    setChatPartner(partner)
    setShowPartnerChat(true)
  }

  // Handle place bid
  const handlePlaceBid = () => {
    // In a real app, this would submit the bid to the server
    alert(`Bid placed successfully! Amount: $${bidAmount}, Delivery: ${bidDeliveryTime} days`)
    setSelectedProject(null)
  }

  // Handle buy now / add to cart
  const handleBuyNow = () => {
    if (!selectedProduct) return

    // In a real app, this would add the product to cart or initiate checkout
    // For demo, we'll open a chat with the seller
    handleChatWithPartner(selectedProduct.seller)
  }

  return (
    <div className="container mx-auto py-6 px-4 md:px-6 max-w-7xl">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Marketplace</h1>
          <p className="text-muted-foreground">Buy, sell, and find business opportunities</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="h-4 w-4" />
            {showFilters ? "Hide Filters" : "Show Filters"}
          </Button>
          <Button
            className="gap-2"
            onClick={() => (activeTab === "products" ? setIsCreateProductOpen(true) : setIsCreateProjectOpen(true))}
          >
            <Plus className="h-4 w-4" />
            {activeTab === "products" ? "List Product" : "Post Project"}
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder={`Search ${activeTab === "products" ? "products" : "projects"}...`}
            className="pl-10 py-6 text-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="products" className="w-full" onValueChange={setActiveTab}>
        <div className="border-b mb-6">
          <TabsList className="w-full max-w-md">
            <TabsTrigger value="products" className="flex-1">
              Products
            </TabsTrigger>
            <TabsTrigger value="projects" className="flex-1">
              Outsourcing Projects
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-6">
          {/* Filters Panel */}
          {showFilters && (
            <Card className="h-fit lg:sticky lg:top-6">
              <CardHeader className="pb-3">
                <CardTitle>Filters</CardTitle>
                <CardDescription>Refine your search results</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {activeTab === "products"
                        ? productCategories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))
                        : projectCategories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                    </SelectContent>
                  </Select>
                </div>

                {activeTab === "products" && (
                  <>
                    <div className="space-y-2">
                      <Label>Condition</Label>
                      <Select value={selectedCondition} onValueChange={setSelectedCondition}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select condition" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Conditions</SelectItem>
                          <SelectItem value="new">New</SelectItem>
                          <SelectItem value="used">Used</SelectItem>
                          <SelectItem value="refurbished">Refurbished</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Price Range</Label>
                        <span className="text-sm text-muted-foreground">
                          ${priceRange[0]} - ${priceRange[1]}
                        </span>
                      </div>
                      <Slider
                        value={[priceRange[0], priceRange[1]]}
                        min={0}
                        max={10000}
                        step={100}
                        onValueChange={(value) => setPriceRange([value[0], value[1]])}
                        className="mt-6"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label>Sort By</Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      {activeTab === "products" ? (
                        <>
                          <SelectItem value="featured">Featured</SelectItem>
                          <SelectItem value="price-low">Price: Low to High</SelectItem>
                          <SelectItem value="price-high">Price: High to Low</SelectItem>
                          <SelectItem value="newest">Newest</SelectItem>
                          <SelectItem value="rating">Highest Rated</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="newest">Newest</SelectItem>
                          <SelectItem value="deadline">Deadline: Soonest</SelectItem>
                          <SelectItem value="budget-high">Budget: High to Low</SelectItem>
                          <SelectItem value="budget-low">Budget: Low to High</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>View</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={viewMode === "grid" ? "default" : "outline"}
                      size="sm"
                      className="flex-1"
                      onClick={() => setViewMode("grid")}
                    >
                      <Grid className="h-4 w-4 mr-2" />
                      Grid
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "outline"}
                      size="sm"
                      className="flex-1"
                      onClick={() => setViewMode("list")}
                    >
                      <List className="h-4 w-4 mr-2" />
                      List
                    </Button>
                  </div>
                </div>

                {activeTab === "products" && (
                  <div className="space-y-2">
                    <Label>Seller Location</Label>
                    <div className="space-y-2">
                      {Array.from(new Set(sampleProducts.map((p) => p.seller.country)))
                        .slice(0, 5)
                        .map((country) => (
                          <div key={country} className="flex items-center space-x-2">
                            <Checkbox id={`country-${country}`} />
                            <label
                              htmlFor={`country-${country}`}
                              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                            >
                              {country}
                            </label>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                <Button className="w-full">Apply Filters</Button>
              </CardContent>
            </Card>
          )}

          {/* Products Tab Content */}
          <TabsContent value="products" className="mt-0">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">
                {filteredProducts.length} {filteredProducts.length === 1 ? "Product" : "Products"}
              </h2>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Sort:</span>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {viewMode === "grid" ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedProducts.map((product) => (
                  <Card
                    key={product.id}
                    className="overflow-hidden hover:shadow-md transition-all cursor-pointer"
                    onClick={() => handleProductSelect(product)}
                  >
                    <div className="relative aspect-square">
                      <img
                        src={product.images[0] || "/placeholder.svg"}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                      {product.discountPrice && (
                        <Badge className="absolute top-2 right-2 bg-red-500">
                          {Math.round((1 - product.discountPrice / product.price) * 100)}% OFF
                        </Badge>
                      )}
                      {product.featured && <Badge className="absolute top-2 left-2 bg-primary">Featured</Badge>}
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="capitalize">
                          {product.condition}
                        </Badge>
                        <Badge variant="secondary">{product.category}</Badge>
                      </div>
                      <h3 className="font-semibold line-clamp-2 mb-1">{product.name}</h3>
                      <div className="flex items-center gap-1 mb-2">
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < Math.floor(product.rating)
                                  ? "text-yellow-400 fill-yellow-400"
                                  : i < product.rating
                                    ? "text-yellow-400 fill-yellow-400/50"
                                    : "text-muted-foreground"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
                      </div>
                      <div className="flex items-baseline gap-2">
                        {product.discountPrice ? (
                          <>
                            <span className="font-bold">${product.discountPrice}</span>
                            <span className="text-sm text-muted-foreground line-through">${product.price}</span>
                          </>
                        ) : (
                          <span className="font-bold">${product.price}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                        <Globe className="h-3 w-3" />
                        <span>{product.location}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {sortedProducts.map((product) => (
                  <Card
                    key={product.id}
                    className="overflow-hidden hover:shadow-md transition-all cursor-pointer"
                    onClick={() => handleProductSelect(product)}
                  >
                    <div className="flex flex-col sm:flex-row">
                      <div className="relative w-full sm:w-48 h-48">
                        <img
                          src={product.images[0] || "/placeholder.svg"}
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                        {product.discountPrice && (
                          <Badge className="absolute top-2 right-2 bg-red-500">
                            {Math.round((1 - product.discountPrice / product.price) * 100)}% OFF
                          </Badge>
                        )}
                        {product.featured && <Badge className="absolute top-2 left-2 bg-primary">Featured</Badge>}
                      </div>
                      <div className="flex-1 p-4">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="capitalize">
                            {product.condition}
                          </Badge>
                          <Badge variant="secondary">{product.category}</Badge>
                        </div>
                        <h3 className="font-semibold mb-1">{product.name}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-2">{product.description}</p>
                        <div className="flex items-center gap-1 mb-2">
                          <div className="flex">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < Math.floor(product.rating)
                                    ? "text-yellow-400 fill-yellow-400"
                                    : i < product.rating
                                      ? "text-yellow-400 fill-yellow-400/50"
                                      : "text-muted-foreground"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-xs text-muted-foreground">({product.reviewCount})</span>
                        </div>
                        <div className="flex items-baseline gap-2">
                          {product.discountPrice ? (
                            <>
                              <span className="font-bold">${product.discountPrice}</span>
                              <span className="text-sm text-muted-foreground line-through">${product.price}</span>
                            </>
                          ) : (
                            <span className="font-bold">${product.price}</span>
                          )}
                        </div>
                      </div>
                      <div className="p-4 flex flex-col justify-between border-l">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Avatar className="h-6 w-6">
                              <AvatarImage src={product.seller.logo} />
                              <AvatarFallback>{product.seller.name[0]}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm font-medium">{product.seller.name}</span>
                          </div>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground mb-4">
                            <Globe className="h-3 w-3" />
                            <span>{product.location}</span>
                          </div>
                        </div>
                        <div className="text-sm">
                          <div className="flex justify-between mb-1">
                            <span>Stock:</span>
                            <span className="font-medium">{product.stock}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Min Order:</span>
                            <span className="font-medium">{product.minOrder || 1}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Projects Tab Content */}
          <TabsContent value="projects" className="mt-0">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">
                {filteredProjects.length} {filteredProjects.length === 1 ? "Project" : "Projects"}
              </h2>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Sort:</span>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="deadline">Deadline: Soonest</SelectItem>
                    <SelectItem value="budget-high">Budget: High to Low</SelectItem>
                    <SelectItem value="budget-low">Budget: Low to High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              {sortedProjects.map((project) => (
                <Card
                  key={project.id}
                  className="overflow-hidden hover:shadow-md transition-all cursor-pointer"
                  onClick={() => handleProjectSelect(project)}
                >
                  <div className="p-6">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="secondary">{project.category}</Badge>
                          <Badge variant="outline">{project.subcategory}</Badge>
                          {new Date() > new Date(project.deadline.getTime() - 7 * 24 * 60 * 60 * 1000) && (
                            <Badge variant="destructive">Urgent</Badge>
                          )}
                        </div>
                        <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-4">{project.description}</p>
                        <div className="flex flex-wrap gap-2 mb-4">
                          {project.skills.map((skill) => (
                            <Badge key={skill} variant="outline" className="bg-primary/10">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <div className="text-right">
                          <div className="text-sm text-muted-foreground">Budget</div>
                          <div className="font-bold text-lg">
                            ${project.budget.min} - ${project.budget.max}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>Deadline: {project.deadline.toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <MessageSquare className="h-4 w-4 text-muted-foreground" />
                          <span>{project.bids.length} bids</span>
                        </div>
                      </div>
                    </div>
                    <Separator className="my-4" />
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-2">
                        <Avatar>
                          <AvatarImage src={project.buyer.logo} />
                          <AvatarFallback>{project.buyer.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{project.buyer.name}</div>
                          <div className="text-sm text-muted-foreground">{project.buyer.country}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleChatWithPartner(project.buyer)
                          }}
                        >
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Contact Buyer
                        </Button>
                        <Button size="sm">Place Bid</Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        </div>
      </Tabs>

      {/* Product Detail Dialog */}
      <Dialog open={!!selectedProduct} onOpenChange={(open) => !open && setSelectedProduct(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
            {/* Product Images */}
            <div className="p-6 border-r border-b">
              <div className="aspect-square mb-4 overflow-hidden rounded-md">
                <img
                  src={selectedImage || selectedProduct?.images[0]}
                  alt={selectedProduct?.name}
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {selectedProduct?.images.map((image, index) => (
                  <div
                    key={index}
                    className={`w-20 h-20 rounded-md overflow-hidden cursor-pointer border-2 ${
                      image === selectedImage ? "border-primary" : "border-transparent"
                    }`}
                    onClick={() => setSelectedImage(image)}
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`${selectedProduct?.name} view ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="outline" className="capitalize">
                  {selectedProduct?.condition}
                </Badge>
                <Badge variant="secondary">{selectedProduct?.category}</Badge>
              </div>
              <h2 className="text-2xl font-bold mb-2">{selectedProduct?.name}</h2>
              <div className="flex items-center gap-2 mb-4">
                <div className="flex">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        selectedProduct && i < Math.floor(selectedProduct.rating)
                          ? "text-yellow-400 fill-yellow-400"
                          : selectedProduct && i < selectedProduct.rating
                            ? "text-yellow-400 fill-yellow-400/50"
                            : "text-muted-foreground"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">({selectedProduct?.reviewCount} reviews)</span>
              </div>

              <div className="flex items-baseline gap-2 mb-4">
                {selectedProduct?.discountPrice ? (
                  <>
                    <span className="text-3xl font-bold">${calculatePrice(selectedProduct, quantity)}</span>
                    <span className="text-lg text-muted-foreground line-through">${selectedProduct.price}</span>
                    <Badge className="ml-2 bg-red-500">
                      {Math.round((1 - selectedProduct.discountPrice / selectedProduct.price) * 100)}% OFF
                    </Badge>
                  </>
                ) : (
                  <span className="text-3xl font-bold">${calculatePrice(selectedProduct, quantity)}</span>
                )}
              </div>

              <p className="text-muted-foreground mb-6">{selectedProduct?.description}</p>

              {/* Quantity Selector */}
              <div className="mb-6">
                <Label htmlFor="quantity" className="mb-2 block">
                  Quantity
                </Label>
                <div className="flex items-center">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => handleQuantityChange(quantity - 1)}
                    disabled={quantity <= (selectedProduct?.minOrder || 1)}
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <Input
                    id="quantity"
                    type="number"
                    value={quantity}
                    onChange={(e) => handleQuantityChange(Number.parseInt(e.target.value) || 1)}
                    className="w-20 mx-2 text-center"
                    min={selectedProduct?.minOrder || 1}
                    max={selectedProduct?.maxOrder || 9999}
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => handleQuantityChange(quantity + 1)}
                    disabled={selectedProduct?.maxOrder ? quantity >= selectedProduct.maxOrder : false}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                  <span className="ml-4 text-sm text-muted-foreground">
                    {selectedProduct?.minOrder && `Min: ${selectedProduct.minOrder}`}
                    {selectedProduct?.minOrder && selectedProduct?.maxOrder && " | "}
                    {selectedProduct?.maxOrder && `Max: ${selectedProduct.maxOrder}`}
                  </span>
                </div>
                {selectedProduct?.bulkPricing && (
                  <div className="mt-2 text-sm text-muted-foreground">
                    <span className="font-medium">Bulk pricing available:</span>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {selectedProduct.bulkPricing.map((tier, index) => (
                        <Badge
                          key={index}
                          variant="outline"
                          className={quantity >= tier.quantity ? "bg-primary/10" : ""}
                        >
                          {tier.quantity}+ units: ${tier.price}/each
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Shipping Options */}
              <div className="mb-6">
                <Label className="mb-2 block">Shipping</Label>
                <RadioGroup value={selectedShipping} onValueChange={setSelectedShipping}>
                  {selectedProduct?.shippingOptions.map((option, index) => (
                    <div key={index} className="flex items-center space-x-2 border p-3 rounded-md mb-2">
                      <RadioGroupItem value={option.method} id={`shipping-${option.method}`} />
                      <Label htmlFor={`shipping-${option.method}`} className="flex-1">
                        <div className="flex justify-between">
                          <span>{option.method}</span>
                          <span className="font-medium">${option.price}</span>
                        </div>
                        <span className="text-sm text-muted-foreground">{option.estimatedDelivery}</span>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 mb-6">
                <Button className="flex-1" onClick={handleBuyNow}>
                  Buy Now
                </Button>
                <Button variant="outline" className="flex-1">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Add to Cart
                </Button>
              </div>

              {/* Seller Info */}
              <div className="border rounded-md p-4">
                <div className="flex items-center gap-3 mb-3">
                  <Avatar>
                    <AvatarImage src={selectedProduct?.seller.logo} />
                    <AvatarFallback>{selectedProduct?.seller.name[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{selectedProduct?.seller.name}</div>
                    <div className="text-sm text-muted-foreground">{selectedProduct?.seller.country}</div>
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => selectedProduct && handleChatWithPartner(selectedProduct.seller)}
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Contact Seller
                </Button>
              </div>
            </div>

            {/* Product Details */}
            <div className="col-span-1 md:col-span-2 p-6 border-t">
              <Tabs defaultValue="specifications">
                <TabsList>
                  <TabsTrigger value="specifications">Specifications</TabsTrigger>
                  <TabsTrigger value="shipping">Shipping & Returns</TabsTrigger>
                  <TabsTrigger value="reviews">Reviews</TabsTrigger>
                </TabsList>
                <TabsContent value="specifications" className="pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {selectedProduct &&
                      Object.entries(selectedProduct.specifications).map(([key, value]) => (
                        <div key={key} className="flex">
                          <div className="w-1/3 font-medium">{key}</div>
                          <div className="w-2/3">{value}</div>
                        </div>
                      ))}
                  </div>
                </TabsContent>
                <TabsContent value="shipping" className="pt-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-2">Shipping Information</h3>
                      <p className="text-sm text-muted-foreground">
                        Products are shipped from {selectedProduct?.seller.country} and typically take 7-14 business
                        days for standard shipping and 3-5 business days for express shipping.
                      </p>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Return Policy</h3>
                      <p className="text-sm text-muted-foreground">
                        Returns are accepted within 30 days of delivery for unused items in original packaging. Buyer is
                        responsible for return shipping costs unless the item is defective or not as described.
                      </p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="reviews" className="pt-4">
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="text-3xl font-bold">{selectedProduct?.rating.toFixed(1)}</div>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                selectedProduct && i < Math.floor(selectedProduct.rating)
                                  ? "text-yellow-400 fill-yellow-400"
                                  : selectedProduct && i < selectedProduct.rating
                                    ? "text-yellow-400 fill-yellow-400/50"
                                    : "text-muted-foreground"
                              }`}
                            />
                          ))}
                        </div>
                        <div className="text-sm text-muted-foreground">{selectedProduct?.reviewCount} reviews</div>
                      </div>
                      <div className="flex-1">
                        {[5, 4, 3, 2, 1].map((star) => (
                          <div key={star} className="flex items-center gap-2">
                            <div className="text-sm w-2">{star}</div>
                            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                            <div className="flex-1">
                              <div className="h-2 bg-muted rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-yellow-400"
                                  style={{
                                    width: selectedProduct
                                      ? `${Math.round(
                                          ((selectedProduct.reviewCount *
                                            (star === Math.round(selectedProduct.rating)
                                              ? 0.6
                                              : star > Math.round(selectedProduct.rating)
                                                ? 0.1
                                                : 0.3)) /
                                            selectedProduct.reviewCount) *
                                            100,
                                        )}%`
                                      : "0%",
                                  }}
                                ></div>
                              </div>
                            </div>
                            <div className="text-sm text-muted-foreground w-10">
                              {selectedProduct
                                ? Math.round(
                                    ((selectedProduct.reviewCount *
                                      (star === Math.round(selectedProduct.rating)
                                        ? 0.6
                                        : star > Math.round(selectedProduct.rating)
                                          ? 0.1
                                          : 0.3)) /
                                      selectedProduct.reviewCount) *
                                      100,
                                  )
                                : 0}
                              %
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <Button variant="outline" className="w-full">
                      See All Reviews
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Project Detail Dialog */}
      <Dialog open={!!selectedProject} onOpenChange={(open) => !open && setSelectedProject(null)}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          <div className="p-6">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary">{selectedProject?.category}</Badge>
              <Badge variant="outline">{selectedProject?.subcategory}</Badge>
              {selectedProject &&
                new Date() > new Date(selectedProject.deadline.getTime() - 7 * 24 * 60 * 60 * 1000) && (
                  <Badge variant="destructive">Urgent</Badge>
                )}
            </div>
            <h2 className="text-2xl font-bold mb-4">{selectedProject?.title}</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="col-span-2">
                <div className="prose max-w-none">
                  <p className="text-muted-foreground">{selectedProject?.description}</p>
                </div>

                <div className="mt-4">
                  <h3 className="font-medium mb-2">Required Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedProject?.skills.map((skill) => (
                      <Badge key={skill} variant="outline" className="bg-primary/10">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                {selectedProject?.attachments && (
                  <div className="mt-4">
                    <h3 className="font-medium mb-2">Attachments</h3>
                    <div className="flex gap-2">
                      {selectedProject.attachments.map((attachment, index) => (
                        <div key={index} className="border rounded-md p-2 flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">Attachment {index + 1}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <Card>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Budget</div>
                        <div className="font-bold text-xl">
                          ${selectedProject?.budget.min} - ${selectedProject?.budget.max}
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <div className="text-sm text-muted-foreground">Deadline</div>
                        <div className="font-medium flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          {selectedProject?.deadline.toLocaleDateString()}
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <div className="text-sm text-muted-foreground">Location</div>
                        <div className="font-medium flex items-center gap-2">
                          <Globe className="h-4 w-4" />
                          {selectedProject?.location}
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <div className="text-sm text-muted-foreground">Posted</div>
                        <div className="font-medium flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          {selectedProject?.createdAt.toLocaleDateString()}
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <div className="text-sm text-muted-foreground">Bids</div>
                        <div className="font-medium flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          {selectedProject?.bids.length} proposals
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="mt-4">
                  <h3 className="font-medium mb-2">About the Buyer</h3>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar>
                          <AvatarImage src={selectedProject?.buyer.logo} />
                          <AvatarFallback>{selectedProject?.buyer.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{selectedProject?.buyer.name}</div>
                          <div className="text-sm text-muted-foreground">{selectedProject?.buyer.country}</div>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => selectedProject && handleChatWithPartner(selectedProject.buyer)}
                      >
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Contact Buyer
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>

            <Separator className="my-6" />

            <div>
              <h3 className="text-xl font-semibold mb-4">Place a Bid</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="bid-amount">Bid Amount ($)</Label>
                      <Input
                        id="bid-amount"
                        type="number"
                        value={bidAmount}
                        onChange={(e) => setBidAmount(Number.parseInt(e.target.value) || 0)}
                        min={selectedProject?.budget.min}
                        max={selectedProject?.budget.max}
                      />
                      {selectedProject && (
                        <div className="text-xs text-muted-foreground">
                          Budget range: ${selectedProject.budget.min} - ${selectedProject.budget.max}
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="delivery-time">Delivery Time (days)</Label>
                      <Input
                        id="delivery-time"
                        type="number"
                        value={bidDeliveryTime}
                        onChange={(e) => setBidDeliveryTime(Number.parseInt(e.target.value) || 1)}
                        min={1}
                        max={365}
                      />
                    </div>
                  </div>
                </div>
                <div>
                  <div className="space-y-2">
                    <Label htmlFor="proposal">Proposal</Label>
                    <Textarea
                      id="proposal"
                      placeholder="Describe why you're the best fit for this project..."
                      className="min-h-[150px]"
                      value={bidProposal}
                      onChange={(e) => setBidProposal(e.target.value)}
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-end mt-6">
                <Button variant="outline" className="mr-2" onClick={() => setSelectedProject(null)}>
                  Cancel
                </Button>
                <Button onClick={handlePlaceBid}>Place Bid</Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create Product Dialog */}
      <Dialog open={isCreateProductOpen} onOpenChange={setIsCreateProductOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>List a New Product</DialogTitle>
            <DialogDescription>Add your product to the marketplace for buyers to discover</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="product-name">Product Name</Label>
                <Input id="product-name" placeholder="Enter product name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="product-description">Description</Label>
                <Textarea
                  id="product-description"
                  placeholder="Describe your product in detail..."
                  className="min-h-[150px]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product-price">Price ($)</Label>
                  <Input id="product-price" type="number" min={0} step={0.01} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="product-discount">Discount Price ($)</Label>
                  <Input id="product-discount" type="number" min={0} step={0.01} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product-category">Category</Label>
                  <Select>
                    <SelectTrigger id="product-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {productCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="product-condition">Condition</Label>
                  <Select>
                    <SelectTrigger id="product-condition">
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="used">Used</SelectItem>
                      <SelectItem value="refurbished">Refurbished</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="product-images">Product Images</Label>
                <div className="border-2 border-dashed rounded-lg p-6 text-center">
                  <Upload className="h-10 w-10 mx-auto text-muted-foreground" />
                  <p className="mt-2">Drag and drop product images here or click to browse</p>
                  <Button size="sm" className="mt-2">
                    Select Files
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="product-stock">Stock Quantity</Label>
                <Input id="product-stock" type="number" min={1} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="product-min-order">Minimum Order</Label>
                  <Input id="product-min-order" type="number" min={1} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="product-max-order">Maximum Order</Label>
                  <Input id="product-max-order" type="number" min={1} />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="product-bulk-pricing">Bulk Pricing</Label>
                  <Switch id="product-bulk-pricing" />
                </div>
                <div className="text-sm text-muted-foreground">Enable to offer discounts for bulk purchases</div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateProductOpen(false)}>
              Cancel
            </Button>
            <Button>List Product</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Project Dialog */}
      <Dialog open={isCreateProjectOpen} onOpenChange={setIsCreateProjectOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Post a New Project</DialogTitle>
            <DialogDescription>Describe your project requirements to find the perfect partner</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="project-title">Project Title</Label>
                <Input id="project-title" placeholder="Enter project title" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="project-description">Description</Label>
                <Textarea
                  id="project-description"
                  placeholder="Describe your project requirements in detail..."
                  className="min-h-[150px]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="project-category">Category</Label>
                  <Select>
                    <SelectTrigger id="project-category">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {projectCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="project-subcategory">Subcategory</Label>
                  <Input id="project-subcategory" placeholder="Enter subcategory" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="project-skills">Required Skills</Label>
                <Input id="project-skills" placeholder="Enter skills (comma separated)" />
              </div>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="project-min-budget">Min Budget ($)</Label>
                  <Input id="project-min-budget" type="number" min={0} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="project-max-budget">Max Budget ($)</Label>
                  <Input id="project-max-budget" type="number" min={0} />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="project-deadline">Deadline</Label>
                <Input id="project-deadline" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="project-attachments">Attachments</Label>
                <div className="border-2 border-dashed rounded-lg p-6 text-center">
                  <FileText className="h-10 w-10 mx-auto text-muted-foreground" />
                  <p className="mt-2">Drag and drop files here or click to browse</p>
                  <Button size="sm" className="mt-2">
                    Select Files
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="project-terms" />
                  <label
                    htmlFor="project-terms"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    I agree to the terms and conditions
                  </label>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateProjectOpen(false)}>
              Cancel
            </Button>
            <Button>Post Project</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Partner Chat Dialog */}
      <PartnerChat
        isOpen={showPartnerChat}
        onClose={() => setShowPartnerChat(false)}
        partner={chatPartner || undefined}
        currentUser={currentUser}
      />
    </div>
  )
}

