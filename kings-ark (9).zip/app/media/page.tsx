"use client"

import { useState, useEffect, useRef } from "react"
import {
  Home,
  Flame,
  Clock,
  History,
  ThumbsUp,
  PlaySquare,
  Film,
  Tv,
  Upload,
  Import,
  Search,
  Menu,
  Bell,
  User,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Settings,
  MoreVertical,
  MessageSquare,
  Share,
  ChevronLeft,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Progress } from "@/components/ui/progress"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Badge } from "@/components/ui/badge"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import Link from "next/link"
import SpinningCrownLogo from "@/components/spinning-crown-logo"

// Mock data for videos
const videos = [
  {
    id: "1",
    title: "Global Trade Opportunities in Emerging Markets",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Trade Insights",
    channelAvatar: "/placeholder.svg?height=40&width=40",
    views: "125K",
    timestamp: "2 days ago",
    duration: "15:24",
    verified: true,
  },
  {
    id: "2",
    title: "Supply Chain Innovations for 2023",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Logistics Pro",
    channelAvatar: "/placeholder.svg?height=40&width=40",
    views: "89K",
    timestamp: "1 week ago",
    duration: "22:15",
    verified: true,
  },
  {
    id: "3",
    title: "International Shipping: Best Practices",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Global Freight",
    channelAvatar: "/placeholder.svg?height=40&width=40",
    views: "210K",
    timestamp: "3 weeks ago",
    duration: "18:42",
    verified: false,
  },
  {
    id: "4",
    title: "B2B Marketing Strategies That Work",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Business Growth",
    channelAvatar: "/placeholder.svg?height=40&width=40",
    views: "75K",
    timestamp: "1 month ago",
    duration: "12:38",
    verified: true,
  },
  {
    id: "5",
    title: "Navigating Import Regulations",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Trade Compliance",
    channelAvatar: "/placeholder.svg?height=40&width=40",
    views: "45K",
    timestamp: "2 months ago",
    duration: "28:17",
    verified: true,
  },
  {
    id: "6",
    title: "Sustainable Business Practices",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Green Business",
    channelAvatar: "/placeholder.svg?height=40&width=40",
    views: "120K",
    timestamp: "3 months ago",
    duration: "20:05",
    verified: false,
  },
]

// Mock data for shorts
const shorts = [
  {
    id: "s1",
    title: "Quick Tip: Negotiating with Suppliers",
    thumbnail: "/placeholder.svg?height=320&width=180",
    channel: "Business Tips",
    views: "1.2M",
    duration: "0:58",
  },
  {
    id: "s2",
    title: "Product Showcase: New Tech Gadget",
    thumbnail: "/placeholder.svg?height=320&width=180",
    channel: "Tech Trends",
    views: "850K",
    duration: "0:45",
  },
  {
    id: "s3",
    title: "Market Update in 60 Seconds",
    thumbnail: "/placeholder.svg?height=320&width=180",
    channel: "Finance Flash",
    views: "2.1M",
    duration: "1:00",
  },
  {
    id: "s4",
    title: "Quick Factory Tour",
    thumbnail: "/placeholder.svg?height=320&width=180",
    channel: "Manufacturing Insights",
    views: "750K",
    duration: "0:52",
  },
  {
    id: "s5",
    title: "Packaging Innovation",
    thumbnail: "/placeholder.svg?height=320&width=180",
    channel: "Product Design",
    views: "1.5M",
    duration: "0:48",
  },
]

// Mock data for live channels
const liveChannels = [
  {
    id: "l1",
    title: "Live Market Updates",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Financial News Network",
    viewers: "12.5K watching",
    url: "https://example.com/stream.m3u8",
  },
  {
    id: "l2",
    title: "Trade Show Live Coverage",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Industry Events",
    viewers: "8.2K watching",
    url: "https://example.com/stream2.m3u8",
  },
  {
    id: "l3",
    title: "Manufacturing Process Live",
    thumbnail: "/placeholder.svg?height=180&width=320",
    channel: "Factory Insights",
    viewers: "5.7K watching",
    url: "https://example.com/stream3.m3u8",
  },
]

// Sidebar navigation items
const sidebarItems = [
  { icon: <Home className="h-5 w-5" />, label: "Home", active: true },
  { icon: <Film className="h-5 w-5" />, label: "Shorts" },
  { icon: <PlaySquare className="h-5 w-5" />, label: "Subscriptions" },
  { icon: <Tv className="h-5 w-5" />, label: "Live" },
  { icon: <Separator className="my-2" />, label: "", isSeparator: true },
  { icon: <User className="h-5 w-5" />, label: "Your Channel" },
  { icon: <History className="h-5 w-5" />, label: "History" },
  { icon: <PlaySquare className="h-5 w-5" />, label: "Your Videos" },
  { icon: <Clock className="h-5 w-5" />, label: "Watch Later" },
  { icon: <ThumbsUp className="h-5 w-5" />, label: "Liked Videos" },
  { icon: <Separator className="my-2" />, label: "", isSeparator: true },
  { icon: <Flame className="h-5 w-5" />, label: "Trending" },
  { icon: <Tv className="h-5 w-5" />, label: "Live Channels" },
]

export default function MediaPage() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState("home")
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(80)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [showShorts, setShowShorts] = useState(false)
  const [currentShort, setCurrentShort] = useState(0)
  const [isLiveStreamDialogOpen, setIsLiveStreamDialogOpen] = useState(false)
  const [m3u8Url, setM3u8Url] = useState("")
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false)
  const [importUrl, setImportUrl] = useState("")
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")
  const videoRef = useRef<HTMLVideoElement>(null)
  const playerContainerRef = useRef<HTMLDivElement>(null)

  // Check if mobile on mount and when window resizes
  useEffect(() => {
    const checkIfMobile = () => {
      if (window.innerWidth < 768) {
        setSidebarOpen(false)
      }
    }

    checkIfMobile()
    window.addEventListener("resize", checkIfMobile)

    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  // Handle video player controls
  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleVolumeChange = (newVolume: number[]) => {
    if (videoRef.current) {
      const volumeValue = newVolume[0]
      videoRef.current.volume = volumeValue / 100
      setVolume(volumeValue)
      setIsMuted(volumeValue === 0)
    }
  }

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime)
    }
  }

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration)
    }
  }

  const handleSeek = (newTime: number[]) => {
    if (videoRef.current) {
      videoRef.current.currentTime = newTime[0]
      setCurrentTime(newTime[0])
    }
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      playerContainerRef.current?.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  // Format time for video player
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`
  }

  // Simulate upload progress
  useEffect(() => {
    if (isUploadDialogOpen && uploadProgress < 100) {
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          const newProgress = prev + 5
          if (newProgress >= 100) {
            clearInterval(interval)
            setTimeout(() => {
              setIsUploadDialogOpen(false)
              setUploadProgress(0)
            }, 1000)
          }
          return newProgress
        })
      }, 500)
      return () => clearInterval(interval)
    }
  }, [isUploadDialogOpen, uploadProgress])

  // Handle shorts navigation
  const nextShort = () => {
    setCurrentShort((prev) => (prev + 1) % shorts.length)
  }

  const prevShort = () => {
    setCurrentShort((prev) => (prev - 1 + shorts.length) % shorts.length)
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Mobile Sidebar Toggle */}
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden absolute top-4 left-4 z-50">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <div className="flex flex-col h-full">
            <div className="p-4 border-b">
              <div className="flex items-center">
                <Film className="h-6 w-6 mr-2 text-primary" />
                <h2 className="font-semibold text-lg">Kings Ark Media</h2>
              </div>
            </div>
            <ScrollArea className="flex-1">
              <div className="p-2">
                {sidebarItems.map((item, index) => (
                  <div key={index}>
                    {item.isSeparator ? (
                      <Separator className="my-2" />
                    ) : (
                      <Button
                        variant={item.active ? "secondary" : "ghost"}
                        className="w-full justify-start mb-1"
                        onClick={() => (item.label === "Shorts" ? setShowShorts(true) : null)}
                      >
                        {item.icon}
                        <span className="ml-2">{item.label}</span>
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        </SheetContent>
      </Sheet>

      {/* Desktop Sidebar */}
      {sidebarOpen && (
        <div className="hidden md:flex flex-col w-64 border-r bg-background">
          <div className="p-4 border-b">
            <div className="flex items-center">
              <Film className="h-6 w-6 mr-2 text-primary" />
              <h2 className="font-semibold text-lg">Kings Ark Media</h2>
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="p-2">
              {sidebarItems.map((item, index) => (
                <div key={index}>
                  {item.isSeparator ? (
                    <Separator className="my-2" />
                  ) : (
                    <Button
                      variant={item.active ? "secondary" : "ghost"}
                      className="w-full justify-start mb-1"
                      onClick={() => (item.label === "Shorts" ? setShowShorts(true) : null)}
                    >
                      {item.icon}
                      <span className="ml-2">{item.label}</span>
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Header */}
        <header className="border-b bg-background p-4 flex items-center justify-between">
          <div className="flex items-center md:w-1/3">
            <Button
              variant="ghost"
              size="icon"
              className="hidden md:flex mr-2"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="hidden md:flex items-center">
              <Film className="h-6 w-6 mr-2 text-primary" />
              <h2 className="font-semibold text-lg">Kings Ark Media</h2>
            </div>

            {/* Return to Homepage Button - Glowing */}
            <Link
              href="/"
              className="flex items-center gap-2 px-3 py-2 rounded-full bg-primary/10 text-primary hover:bg-primary/20 transition-all shadow-lg shadow-primary/20 animate-pulse"
            >
              <div className="relative h-6 w-6">
                <SpinningCrownLogo />
              </div>
              <span className="font-medium text-sm">Kings Ark Platform</span>
            </Link>
          </div>

          <div className="flex-1 max-w-2xl">
            <div className="relative">
              <Input
                type="search"
                placeholder="Search videos, channels, and more..."
                className="w-full pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Button size="sm" className="absolute right-1 top-1/2 transform -translate-y-1/2">
                Search
              </Button>
            </div>
          </div>

          <div className="flex items-center space-x-2 md:w-1/3 justify-end">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" onClick={() => setIsUploadDialogOpen(true)}>
                    <Upload className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Upload Video</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" onClick={() => setIsImportDialogOpen(true)}>
                    <Import className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Import Video</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" onClick={() => setIsLiveStreamDialogOpen(true)}>
                    <Tv className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Add Live Stream</TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Avatar>
                    <AvatarImage src="/placeholder.svg?height=32&width=32" />
                    <AvatarFallback>KA</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>Your Channel</DropdownMenuItem>
                <DropdownMenuItem>Studio</DropdownMenuItem>
                <DropdownMenuItem>Switch Account</DropdownMenuItem>
                <DropdownMenuItem>Sign Out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          {showShorts ? (
            <div className="h-full flex flex-col">
              <div className="p-4 flex items-center justify-between">
                <h2 className="text-2xl font-bold">Shorts</h2>
                <Button variant="ghost" size="sm" onClick={() => setShowShorts(false)}>
                  Back to Home
                </Button>
              </div>
              <div className="flex-1 flex items-center justify-center bg-black">
                <div className="relative max-w-sm max-h-[80vh] aspect-[9/16]">
                  <img
                    src={shorts[currentShort].thumbnail || "/placeholder.svg"}
                    alt={shorts[currentShort].title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent text-white">
                    <h3 className="font-bold">{shorts[currentShort].title}</h3>
                    <p className="text-sm">{shorts[currentShort].channel}</p>
                    <p className="text-xs">{shorts[currentShort].views} views</p>
                  </div>
                  <div className="absolute right-4 bottom-20 flex flex-col items-center space-y-6">
                    <Button variant="ghost" size="icon" className="rounded-full bg-black/30 text-white">
                      <ThumbsUp className="h-6 w-6" />
                    </Button>
                    <Button variant="ghost" size="icon" className="rounded-full bg-black/30 text-white">
                      <MessageSquare className="h-6 w-6" />
                    </Button>
                    <Button variant="ghost" size="icon" className="rounded-full bg-black/30 text-white">
                      <Share className="h-6 w-6" />
                    </Button>
                    <Button variant="ghost" size="icon" className="rounded-full bg-black/30 text-white">
                      <MoreVertical className="h-6 w-6" />
                    </Button>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-1/2 left-4 -translate-y-1/2 rounded-full bg-black/30 text-white"
                    onClick={prevShort}
                  >
                    <ChevronLeft className="h-6 w-6" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-1/2 right-4 -translate-y-1/2 rounded-full bg-black/30 text-white"
                    onClick={nextShort}
                  >
                    <ChevronRight className="h-6 w-6" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <Tabs defaultValue="home" className="w-full" onValueChange={setActiveTab}>
              <div className="px-4 pt-4 border-b sticky top-0 bg-background z-10">
                <TabsList className="grid w-full max-w-md grid-cols-4">
                  <TabsTrigger value="home">Home</TabsTrigger>
                  <TabsTrigger value="shorts">Shorts</TabsTrigger>
                  <TabsTrigger value="live">Live</TabsTrigger>
                  <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="home" className="p-4">
                <h2 className="text-2xl font-bold mb-4">Recommended Videos</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {videos.map((video) => (
                    <Card key={video.id} className="overflow-hidden">
                      <div className="relative">
                        <img
                          src={video.thumbnail || "/placeholder.svg"}
                          alt={video.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1 rounded">
                          {video.duration}
                        </div>
                      </div>
                      <CardContent className="p-3">
                        <div className="flex space-x-3">
                          <Avatar className="h-9 w-9">
                            <AvatarImage src={video.channelAvatar} />
                            <AvatarFallback>{video.channel[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-semibold line-clamp-2">{video.title}</h3>
                            <div className="flex items-center text-sm text-muted-foreground mt-1">
                              <span>{video.channel}</span>
                              {video.verified && (
                                <Badge variant="outline" className="ml-1 h-4 px-1">
                                  ✓
                                </Badge>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {video.views} views • {video.timestamp}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="shorts" className="p-4">
                <h2 className="text-2xl font-bold mb-4">Shorts</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {shorts.map((short, index) => (
                    <div
                      key={short.id}
                      className="cursor-pointer"
                      onClick={() => {
                        setCurrentShort(index)
                        setShowShorts(true)
                      }}
                    >
                      <div className="relative rounded-xl overflow-hidden aspect-[9/16]">
                        <img
                          src={short.thumbnail || "/placeholder.svg"}
                          alt={short.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1 rounded">
                          {short.duration}
                        </div>
                      </div>
                      <h3 className="font-medium text-sm mt-2 line-clamp-2">{short.title}</h3>
                      <p className="text-xs text-muted-foreground">{short.views} views</p>
                    </div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="live" className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold">Live Now</h2>
                  <Button variant="outline" onClick={() => setIsLiveStreamDialogOpen(true)}>
                    <Tv className="h-4 w-4 mr-2" />
                    Add Live Stream
                  </Button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {liveChannels.map((channel) => (
                    <Card key={channel.id} className="overflow-hidden">
                      <div className="relative">
                        <img
                          src={channel.thumbnail || "/placeholder.svg"}
                          alt={channel.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-1 rounded">
                          LIVE
                        </div>
                      </div>
                      <CardContent className="p-3">
                        <h3 className="font-semibold">{channel.title}</h3>
                        <p className="text-sm text-muted-foreground">{channel.channel}</p>
                        <p className="text-xs text-muted-foreground mt-1">{channel.viewers}</p>
                      </CardContent>
                      <CardFooter className="p-3 pt-0">
                        <Button size="sm" className="w-full">
                          Watch Now
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="subscriptions" className="p-4">
                <h2 className="text-2xl font-bold mb-4">Your Subscriptions</h2>
                <div className="flex flex-wrap gap-4 mb-6">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="flex flex-col items-center">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={`/placeholder.svg?height=64&width=64&text=${i + 1}`} />
                        <AvatarFallback>CH</AvatarFallback>
                      </Avatar>
                      <span className="text-sm mt-1">Channel {i + 1}</span>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {videos.slice(0, 4).map((video) => (
                    <Card key={video.id} className="overflow-hidden">
                      <div className="relative">
                        <img
                          src={video.thumbnail || "/placeholder.svg"}
                          alt={video.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1 rounded">
                          {video.duration}
                        </div>
                      </div>
                      <CardContent className="p-3">
                        <div className="flex space-x-3">
                          <Avatar className="h-9 w-9">
                            <AvatarImage src={video.channelAvatar} />
                            <AvatarFallback>{video.channel[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h3 className="font-semibold line-clamp-2">{video.title}</h3>
                            <div className="flex items-center text-sm text-muted-foreground mt-1">
                              <span>{video.channel}</span>
                              {video.verified && (
                                <Badge variant="outline" className="ml-1 h-4 px-1">
                                  ✓
                                </Badge>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {video.views} views • {video.timestamp}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </div>

        {/* Video Player Modal */}
        <Dialog>
          <DialogTrigger asChild>
            <div className="hidden">Open Video</div>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[80vw] p-0 overflow-hidden">
            <div ref={playerContainerRef} className="relative bg-black">
              <video
                ref={videoRef}
                className="w-full max-h-[70vh]"
                src="/placeholder.mp4"
                poster="/placeholder.svg?height=720&width=1280"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
              />

              {/* Video Controls */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                <div className="flex items-center mb-2">
                  <Slider
                    value={[currentTime]}
                    max={duration || 100}
                    step={1}
                    onValueChange={handleSeek}
                    className="w-full"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="icon" onClick={togglePlay} className="text-white">
                      {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                    </Button>
                    <Button variant="ghost" size="icon" onClick={toggleMute} className="text-white">
                      {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                    </Button>
                    <div className="w-24 hidden sm:block">
                      <Slider value={[volume]} max={100} step={1} onValueChange={handleVolumeChange} />
                    </div>
                    <span className="text-white text-sm">
                      {formatTime(currentTime)} / {formatTime(duration)}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="icon" className="text-white">
                      <Settings className="h-5 w-5" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={toggleFullscreen} className="text-white">
                      <Maximize className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-4">
              <h2 className="text-xl font-bold">Video Title</h2>
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center">
                  <Avatar className="h-10 w-10 mr-3">
                    <AvatarImage src="/placeholder.svg?height=40&width=40" />
                    <AvatarFallback>CH</AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium">Channel Name</h3>
                    <p className="text-sm text-muted-foreground">1.2M subscribers</p>
                  </div>
                  <Button className="ml-4" size="sm">
                    Subscribe
                  </Button>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">
                    <ThumbsUp className="h-4 w-4 mr-1" /> 24K
                  </Button>
                  <Button variant="outline" size="sm">
                    Share
                  </Button>
                </div>
              </div>
              <Separator className="my-4" />
              <div className="bg-muted/50 rounded-lg p-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm font-medium">125K views • 2 days ago</span>
                  </div>
                  <Button variant="ghost" size="sm">
                    Show more
                  </Button>
                </div>
                <p className="text-sm mt-2 line-clamp-3">
                  Video description goes here. This is a sample description for the video that provides context and
                  information about the content.
                </p>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Upload Video Dialog */}
        <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Upload Video</DialogTitle>
              <DialogDescription>Share your content with partners on Kings Ark Media</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="border-2 border-dashed rounded-lg p-6 text-center">
                <Upload className="h-10 w-10 mx-auto text-muted-foreground" />
                <p className="mt-2">Drag and drop video files here or click to browse</p>
                <Button size="sm" className="mt-2">
                  Select Files
                </Button>
              </div>
              {uploadProgress > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Uploading...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input id="title" placeholder="Enter video title" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" placeholder="Describe your video" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <select
                  id="category"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <option value="">Select a category</option>
                  <option value="trade">Trade & Commerce</option>
                  <option value="manufacturing">Manufacturing</option>
                  <option value="logistics">Logistics & Supply Chain</option>
                  <option value="finance">Finance & Investment</option>
                  <option value="technology">Technology</option>
                </select>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="visibility" />
                <Label htmlFor="visibility">Make video public</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Upload</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Import Video Dialog */}
        <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Import Video</DialogTitle>
              <DialogDescription>Import videos from YouTube or other platforms</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="importUrl">Video URL</Label>
                <Input
                  id="importUrl"
                  placeholder="https://youtube.com/watch?v=..."
                  value={importUrl}
                  onChange={(e) => setImportUrl(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label>Platform</Label>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="justify-start">
                    <svg className="h-4 w-4 mr-2 text-red-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z" />
                    </svg>
                    YouTube
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <svg className="h-4 w-4 mr-2 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.977 6.416c-.105 2.338-1.739 5.543-4.894 9.609-3.268 4.247-6.026 6.37-8.29 6.37-1.409 0-2.578-1.294-3.553-3.881L5.322 11.4C4.603 8.816 3.834 7.522 3.01 7.522c-.179 0-.806.378-1.881 1.132L0 7.197c1.185-1.044 2.351-2.084 3.501-3.128C5.08 2.701 6.266 1.984 7.055 1.91c1.867-.18 3.016 1.1 3.447 3.838.465 2.953.789 4.789.971 5.507.539 2.45 1.131 3.674 1.776 3.674.502 0 1.256-.796 2.265-2.385 1.004-1.589 1.54-2.797 1.612-3.628.144-1.371-.395-2.061-1.614-2.061-.574 0-1.167.121-1.777.391 1.186-3.868 3.434-5.757 6.762-5.637 2.473.06 3.628 1.664 3.493 4.797l-.013.01z" />
                    </svg>
                    Vimeo
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <svg className="h-4 w-4 mr-2 text-purple-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M11.64 5.93h1.43v4.28h-1.43m3.93-4.28H17v4.28h-1.43M7 2L3.43 5.57v12.86h4.28V22l3.58-3.57h2.85L20.57 12V2m-1.43 9.29l-2.85 2.85h-2.86l-2.5 2.5v-2.5H7.71V3.43h11.43z" />
                    </svg>
                    Twitch
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="importTitle">Title (Optional)</Label>
                <Input id="importTitle" placeholder="Custom title for imported video" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="importDescription">Description (Optional)</Label>
                <Textarea id="importDescription" placeholder="Custom description" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsImportDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Import</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Live Stream Dialog */}
        <Dialog open={isLiveStreamDialogOpen} onOpenChange={setIsLiveStreamDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add Live Stream</DialogTitle>
              <DialogDescription>Add an M3U8 stream URL or other live video source</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="streamUrl">Stream URL (M3U8)</Label>
                <Input
                  id="streamUrl"
                  placeholder="https://example.com/stream.m3u8"
                  value={m3u8Url}
                  onChange={(e) => setM3u8Url(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="streamTitle">Stream Title</Label>
                <Input id="streamTitle" placeholder="Enter stream title" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="streamDescription">Description</Label>
                <Textarea id="streamDescription" placeholder="Describe this live stream" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="streamThumbnail">Thumbnail URL (Optional)</Label>
                <Input id="streamThumbnail" placeholder="https://example.com/thumbnail.jpg" />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="streamPublic" />
                <Label htmlFor="streamPublic">Make stream public</Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsLiveStreamDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit">Add Stream</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}

