import { Loader2 } from "lucide-react"
import SpinningCrownLogo from "@/components/spinning-crown-logo"

export default function MetaverseLoading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-background to-background/80">
      <div className="flex flex-col items-center">
        <SpinningCrownLogo size={64} className="mb-8" />
        <h1 className="text-3xl font-bold mb-4">Kings Ark Metaverse</h1>
        <div className="flex items-center">
          <Loader2 className="h-6 w-6 animate-spin mr-2" />
          <p className="text-lg">Loading virtual environment...</p>
        </div>
      </div>
    </div>
  )
}

