"use client"

import { useState, useEffect } from "react"
import type { Avatar, User, ChatMessage, Room, Deal } from "@/types/metaverse"
import { partnersData } from "../global-map/partners-data"
import dynamic from "next/dynamic"
import { Spinner } from "@/components/ui/spinner"
import { ThreePluginsLoader } from "./utils/three-plugins-loader"
import { WebGLDetector } from "./utils/webgl-detector"

// Dynamically import the metaverse components to ensure they only load on the client
const DynamicMetaversePage = dynamic(() => import("./components/metaverse-main"), {
  ssr: false,
  loading: () => (
    <div className="flex min-h-screen bg-gradient-to-b from-background to-background/80 items-center justify-center">
      <div className="text-center">
        <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
        <h2 className="text-2xl font-bold mt-6">Loading Metaverse</h2>
        <p className="text-muted-foreground mt-2">Initializing 3D environment...</p>
      </div>
    </div>
  ),
})

// Mock data for avatars
const mockAvatars: Avatar[] = [
  {
    id: "avatar-1",
    name: "Business Person",
    model: "business-person",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Business",
  },
  {
    id: "avatar-2",
    name: "Executive",
    model: "executive",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Executive",
  },
  {
    id: "avatar-3",
    name: "Casual",
    model: "casual",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Casual",
  },
  {
    id: "avatar-4",
    name: "Creative",
    model: "creative",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Creative",
  },
]

// Mock data for rooms
const mockRooms: Room[] = [
  {
    id: "room-1",
    name: "Main Conference Room",
    description: "The main conference room for general meetings",
    capacity: 20,
    currentUsers: 8,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Conference",
  },
  {
    id: "room-2",
    name: "Deal Negotiation Room",
    description: "Private room for negotiating deals",
    capacity: 10,
    currentUsers: 4,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Negotiation",
  },
  {
    id: "room-3",
    name: "Networking Lounge",
    description: "Casual space for networking and informal discussions",
    capacity: 30,
    currentUsers: 12,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Networking",
  },
  {
    id: "room-4",
    name: "Private Meeting Room A",
    description: "Private room for confidential meetings",
    capacity: 6,
    currentUsers: 2,
    isPrivate: true,
    password: "1234",
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Private",
  },
  {
    id: "room-5",
    name: "Global Trade Center",
    description: "International business hub for cross-border deals",
    capacity: 50,
    currentUsers: 18,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Global",
  },
  {
    id: "room-6",
    name: "Pitch Arena",
    description: "Present your business ideas to potential investors",
    capacity: 25,
    currentUsers: 10,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Pitch",
  },
]

// Convert partners data to metaverse users
const convertPartnersToUsers = (): User[] => {
  return partnersData.map((partner, index) => {
    const avatarIndex = index % mockAvatars.length
    const isSpeaking = Math.random() > 0.8
    const isTyping = Math.random() > 0.9

    return {
      id: partner.id,
      name: partner.contactPerson,
      avatar: mockAvatars[avatarIndex],
      position: [(Math.random() - 0.5) * 5, 1.6, (Math.random() - 0.5) * 5],
      rotation: [0, Math.random() * Math.PI * 2, 0],
      speaking: isSpeaking,
      typing: isTyping,
      status: "online",
      company: partner.name,
      role: partner.type === "seller" ? "Seller" : partner.type === "buyer" ? "Buyer" : "Both",
      country: partner.country,
    }
  })
}

// Generate mock users for a room
const generateMockUsers = (roomId: string, count: number): User[] => {
  // Use partners data for the first set of users
  const partnerUsers = convertPartnersToUsers().slice(0, count - 5)

  // Add some additional random users to reach the desired count
  const additionalUsers: User[] = []
  for (let i = 0; i < Math.min(5, count - partnerUsers.length); i++) {
    additionalUsers.push({
      id: `user-${i + 1}`,
      name: `User ${i + 1}`,
      avatar: mockAvatars[Math.floor(Math.random() * mockAvatars.length)],
      position: [(Math.random() - 0.5) * 5, 1.6, (Math.random() - 0.5) * 5],
      rotation: [0, Math.random() * Math.PI * 2, 0],
      speaking: Math.random() > 0.8,
      typing: Math.random() > 0.9,
      status: "online",
      company: `Company ${i + 1}`,
      role: Math.random() > 0.5 ? "Buyer" : "Seller",
      country: ["USA", "UK", "Germany", "Japan", "China", "India"][Math.floor(Math.random() * 6)],
    })
  }

  return [...partnerUsers, ...additionalUsers]
}

// Generate more realistic chat messages
const generateRealisticMessages = (roomId: string, users: User[]): ChatMessage[] => {
  const businessMessages = [
    "Has anyone closed a deal in the renewable energy sector recently?",
    "I'm looking for partners in the tech industry, preferably in Asia.",
    "We're expanding our operations to Europe. Any recommendations for logistics partners?",
    "Just closed a $2M deal with a distributor in South America!",
    "Is anyone interested in discussing joint ventures in the manufacturing sector?",
    "Looking for investors for our new AI-powered supply chain solution.",
    "We're offering exclusive rates for first-time partners. DM me for details.",
    "Anyone here from the pharmaceutical industry? We have some interesting proposals.",
    "Just joined from Tokyo. Looking forward to connecting with potential partners.",
    "We're hosting a virtual trade show next month. Let me know if you'd like an invitation.",
    "Has anyone used the new deal negotiation features? They're quite impressive.",
    "Looking for suppliers of organic materials for our new product line.",
    "We're a VC firm looking for promising startups in fintech and healthtech.",
    "Just published our Q2 results. We're looking for new growth opportunities.",
    "Anyone interested in the African market? We have strong connections there.",
  ]

  const messages: ChatMessage[] = []

  // Add system welcome message
  messages.push({
    id: `msg-welcome`,
    userId: "system",
    userName: "Kings Ark Metaverse",
    content: `Welcome to the ${roomId === "room-1" ? "Main Conference Room" : roomId === "room-2" ? "Deal Negotiation Room" : roomId === "room-3" ? "Networking Lounge" : "Private Meeting Room"}! Please introduce yourself and connect with other business partners.`,
    timestamp: new Date(Date.now() - 3600000),
    isPrivate: false,
  })

  // Add some realistic business messages
  for (let i = 0; i < 15; i++) {
    const user = users[Math.floor(Math.random() * users.length)]
    const isPrivate = Math.random() > 0.8
    const recipientId = isPrivate ? users.find((u) => u.id !== user.id)?.id : undefined
    const messageContent = businessMessages[i % businessMessages.length]

    messages.push({
      id: `msg-${i + 1}`,
      userId: user.id,
      userName: user.name,
      content: messageContent,
      timestamp: new Date(Date.now() - (15 - i) * 300000 * Math.random()),
      isPrivate,
      recipientId,
    })
  }

  return messages.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
}

// Generate more realistic deals
const generateRealisticDeals = (users: User[]): Deal[] => {
  const dealTemplates = [
    {
      title: "Supply Chain Optimization Partnership",
      description: "Collaboration to optimize logistics and reduce delivery times by 30% across Asia.",
      amount: 250000,
      currency: "USD",
    },
    {
      title: "Green Energy Investment",
      description: "Investment in solar panel manufacturing facility with expected ROI of 22% over 5 years.",
      amount: 1500000,
      currency: "EUR",
    },
    {
      title: "Software Distribution Agreement",
      description: "Exclusive distribution rights for enterprise software solutions in South America.",
      amount: 350000,
      currency: "USD",
    },
    {
      title: "Agricultural Export Contract",
      description: "Export of organic produce to European markets with guaranteed minimum volumes.",
      amount: 780000,
      currency: "EUR",
    },
    {
      title: "Manufacturing Joint Venture",
      description: "Joint venture to establish manufacturing facilities in Southeast Asia with shared IP.",
      amount: 2100000,
      currency: "USD",
    },
    {
      title: "Medical Equipment Distribution",
      description: "Distribution of advanced medical diagnostic equipment to hospitals in Middle East.",
      amount: 950000,
      currency: "USD",
    },
    {
      title: "Textile Import Agreement",
      description: "Import of premium textiles for luxury fashion brands with exclusivity clause.",
      amount: 420000,
      currency: "GBP",
    },
    {
      title: "Tech Startup Investment",
      description: "Series A investment in AI-powered fintech solution with board representation.",
      amount: 3500000,
      currency: "USD",
    },
    {
      title: "Pharmaceutical Licensing Deal",
      description: "Licensing of patented pharmaceutical compounds for development in Asian markets.",
      amount: 1800000,
      currency: "USD",
    },
    {
      title: "Retail Expansion Partnership",
      description: "Strategic partnership to expand retail presence in 5 new countries over 3 years.",
      amount: 1250000,
      currency: "EUR",
    },
  ]

  const deals: Deal[] = []
  const statuses: Deal["status"][] = ["proposed", "negotiating", "accepted", "rejected", "completed"]

  for (let i = 0; i < dealTemplates.length; i++) {
    const template = dealTemplates[i]
    const sellers = users.filter((u) => u.role === "Seller" || u.role === "Both")
    const buyers = users.filter((u) => u.role === "Buyer" || u.role === "Both")

    const seller = sellers[Math.floor(Math.random() * sellers.length)]
    const buyer = buyers[Math.floor(Math.random() * buyers.length)]
    const status = statuses[Math.floor(Math.random() * statuses.length)]

    deals.push({
      id: `deal-${i + 1}`,
      title: template.title,
      description: template.description,
      sellerId: seller.id,
      sellerName: seller.name,
      buyerId: buyer.id,
      buyerName: buyer.name,
      amount: template.amount,
      currency: template.currency,
      status,
      createdAt: new Date(Date.now() - (10 - i) * 86400000 * Math.random()),
      updatedAt: new Date(Date.now() - (10 - i) * 43200000 * Math.random()),
      documents: [
        "Contract.pdf",
        "Terms_and_Conditions.pdf",
        "Financial_Projections.xlsx",
        "Legal_Framework.pdf",
        "Technical_Specifications.pdf",
      ].slice(0, Math.floor(Math.random() * 3) + 2),
    })
  }

  return deals
}

export default function MetaversePage() {
  const [isWebGLAvailable, setIsWebGLAvailable] = useState<boolean | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  useEffect(() => {
    // Check WebGL availability
    const checkWebGL = async () => {
      try {
        // Check if WebGL is available
        if (!WebGLDetector.isWebGLAvailable()) {
          setIsWebGLAvailable(false)
          setErrorMessage(WebGLDetector.getWebGLErrorMessage())
          return
        }

        // Preload Three.js plugins
        const pluginsLoaded = await ThreePluginsLoader.preloadPlugins()
        if (!pluginsLoaded) {
          setIsWebGLAvailable(false)
          setErrorMessage("Failed to load 3D environment plugins. Please try a different browser.")
          return
        }

        setIsWebGLAvailable(true)
      } catch (error) {
        console.error("Error checking WebGL:", error)
        setIsWebGLAvailable(false)
        setErrorMessage("An error occurred while initializing the 3D environment. Please try refreshing the page.")
      }
    }

    checkWebGL()
  }, [])

  // Show loading state while checking WebGL
  if (isWebGLAvailable === null) {
    return (
      <div className="flex min-h-screen bg-gradient-to-b from-background to-background/80 items-center justify-center">
        <div className="text-center">
          <Spinner size="lg" />
          <h2 className="text-2xl font-bold mt-4">Checking System Compatibility</h2>
          <p className="text-muted-foreground mt-2">Verifying 3D rendering capabilities...</p>
        </div>
      </div>
    )
  }

  // Show error if WebGL is not available
  if (!isWebGLAvailable) {
    return (
      <div className="flex min-h-screen bg-gradient-to-b from-background to-background/80 items-center justify-center p-6">
        <div className="max-w-md text-center bg-background/90 backdrop-blur-sm p-8 rounded-lg border border-primary/20 shadow-lg">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-16 w-16 mx-auto text-yellow-500"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
            />
          </svg>

          <h2 className="text-2xl font-bold mt-4">3D Environment Not Available</h2>
          <p className="mt-2 text-muted-foreground">{errorMessage}</p>

          <div className="mt-6 bg-muted p-4 rounded-md text-sm text-left">
            <p className="font-medium mb-2">Troubleshooting tips:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Make sure your browser is up to date</li>
              <li>Try disabling hardware acceleration in your browser settings</li>
              <li>Check if WebGL is enabled in your browser</li>
              <li>Try using a different browser (Chrome, Firefox, Edge)</li>
              <li>Update your graphics drivers</li>
            </ul>
          </div>

          <button
            className="mt-6 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
            onClick={() => window.location.reload()}
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }

  // Render the metaverse if WebGL is available
  return <DynamicMetaversePage />
}

