"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react"
import type { User } from "@/types/metaverse"
import { Slider } from "@/components/ui/slider"

interface VoiceChatProps {
  roomId: string
  userId: string
  users: User[]
  onVoiceStatusChange: (isSpeaking: boolean) => void
}

export function VoiceChat({ roomId, userId, users, onVoiceStatusChange }: VoiceChatProps) {
  const [isMuted, setIsMuted] = useState(true)
  const [volume, setVolume] = useState(80)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const audioContextRef = useRef<AudioContext | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const animationFrameRef = useRef<number | null>(null)

  // Initialize audio context
  useEffect(() => {
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()

    return () => {
      if (audioContextRef.current && audioContextRef.current.state !== "closed") {
        audioContextRef.current.close()
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  // Handle microphone toggle
  useEffect(() => {
    if (!isMuted) {
      navigator.mediaDevices
        .getUserMedia({ audio: true, video: false })
        .then((stream) => {
          streamRef.current = stream

          if (audioContextRef.current) {
            const source = audioContextRef.current.createMediaStreamSource(stream)
            const analyser = audioContextRef.current.createAnalyser()
            analyser.fftSize = 256
            source.connect(analyser)
            analyserRef.current = analyser

            const bufferLength = analyser.frequencyBinCount
            const dataArray = new Uint8Array(bufferLength)

            const checkAudioLevel = () => {
              if (!analyserRef.current) return

              analyser.getByteFrequencyData(dataArray)
              let sum = 0
              for (let i = 0; i < bufferLength; i++) {
                sum += dataArray[i]
              }
              const average = sum / bufferLength

              const newIsSpeaking = average > 20 // Threshold for speaking detection
              if (newIsSpeaking !== isSpeaking) {
                setIsSpeaking(newIsSpeaking)
                onVoiceStatusChange(newIsSpeaking)
              }

              animationFrameRef.current = requestAnimationFrame(checkAudioLevel)
            }

            checkAudioLevel()
          }
        })
        .catch((err) => {
          console.error("Error accessing microphone:", err)
          setIsMuted(true)
        })
    } else {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
        streamRef.current = null
      }

      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
        animationFrameRef.current = null
      }

      if (isSpeaking) {
        setIsSpeaking(false)
        onVoiceStatusChange(false)
      }
    }
  }, [isMuted, onVoiceStatusChange])

  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0])
    // In a real implementation, this would adjust the volume of incoming audio
  }

  return (
    <div className="border rounded-md bg-background/80 backdrop-blur-sm p-3">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-medium">Voice Chat</h3>
        <div className="flex items-center space-x-2">
          <Button
            size="icon"
            variant={isMuted ? "outline" : "default"}
            onClick={() => setIsMuted(!isMuted)}
            className={isSpeaking && !isMuted ? "animate-pulse ring-2 ring-green-500" : ""}
          >
            {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center space-x-3">
          {volume === 0 ? (
            <VolumeX className="h-4 w-4 text-muted-foreground" />
          ) : (
            <Volume2 className="h-4 w-4 text-primary" />
          )}
          <Slider value={[volume]} max={100} step={1} onValueChange={handleVolumeChange} className="flex-1" />
          <span className="text-xs w-8 text-right">{volume}%</span>
        </div>

        <div className="space-y-2">
          <h4 className="text-sm font-medium">Participants</h4>
          <div className="space-y-1">
            {users.map((user) => (
              <div key={user.id} className="flex items-center justify-between py-1">
                <div className="flex items-center">
                  <div className={`w-2 h-2 rounded-full mr-2 ${user.speaking ? "bg-green-500" : "bg-gray-400"}`} />
                  <span className="text-sm">{user.name}</span>
                  {user.id === userId && <span className="text-xs ml-2 text-muted-foreground">(You)</span>}
                </div>
                {user.speaking && <Mic className="h-3 w-3 text-green-500" />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

