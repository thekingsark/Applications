"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import type { User } from "@/types/metaverse"
import { AvatarModel } from "./avatar-model"
import { SpatialAudioManager } from "./spatial-audio-manager"
import { Button } from "@/components/ui/button"
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react"

interface EnhancedConferenceRoomProps {
  roomId: string
  userId: string
  users: User[]
  onUserMove: (position: [number, number, number], rotation: [number, number, number]) => void
  spatialAudioEnabled: boolean
  showSpeechBubbles: boolean
}

export function EnhancedConferenceRoom({
  roomId,
  userId,
  users,
  onUserMove,
  spatialAudioEnabled,
  showSpeechBubbles,
}: EnhancedConferenceRoomProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isMicMuted, setIsMicMuted] = useState(true)
  const [isAudioMuted, setIsAudioMuted] = useState(false)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [userSpeechTexts, setUserSpeechTexts] = useState<Record<string, string>>({})
  const [isMoving, setIsMoving] = useState(false)
  const keysPressed = useRef<Record<string, boolean>>({})
  const animationFrameRef = useRef<number | null>(null)

  // Sample speech texts for demonstration
  const sampleSpeechTexts = [
    "Hello, nice to meet you!",
    "I'm interested in your business proposal.",
    "Let's discuss the details later.",
    "What do you think about the market trends?",
    "I'm looking for new partners in Asia.",
    "Our company is expanding to Europe next year.",
    "The ROI on this project is promising.",
    "We should schedule a follow-up meeting.",
    "Have you seen the latest industry report?",
    "I'd like to introduce you to our team.",
  ]

  // Set up keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = true

      if (!isMoving) {
        setIsMoving(true)
        moveUser()
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = false

      // Check if any movement keys are still pressed
      const anyMovementKeyPressed = ["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].some(
        (key) => keysPressed.current[key],
      )

      if (!anyMovementKeyPressed) {
        setIsMoving(false)
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current)
          animationFrameRef.current = null
        }
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)

      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }
    }
  }, [])

  // Handle user movement
  const moveUser = () => {
    const currentUser = users.find((user) => user.id === userId)
    if (!currentUser) return

    const moveSpeed = 0.05
    const rotateSpeed = 0.05

    const newPosition: [number, number, number] = [...currentUser.position]
    const newRotation: [number, number, number] = [...currentUser.rotation]

    // Forward/backward movement
    if (keysPressed.current["w"] || keysPressed.current["arrowup"]) {
      newPosition[0] += Math.sin(newRotation[1]) * moveSpeed
      newPosition[2] += Math.cos(newRotation[1]) * moveSpeed
    }
    if (keysPressed.current["s"] || keysPressed.current["arrowdown"]) {
      newPosition[0] -= Math.sin(newRotation[1]) * moveSpeed
      newPosition[2] -= Math.cos(newRotation[1]) * moveSpeed
    }

    // Strafe left/right
    if (keysPressed.current["a"] || keysPressed.current["arrowleft"]) {
      newPosition[0] -= Math.cos(newRotation[1]) * moveSpeed
      newPosition[2] += Math.sin(newRotation[1]) * moveSpeed
    }
    if (keysPressed.current["d"] || keysPressed.current["arrowright"]) {
      newPosition[0] += Math.cos(newRotation[1]) * moveSpeed
      newPosition[2] -= Math.sin(newRotation[1]) * moveSpeed
    }

    // Rotation (using Q and E)
    if (keysPressed.current["q"]) {
      newRotation[1] -= rotateSpeed
    }
    if (keysPressed.current["e"]) {
      newRotation[1] += rotateSpeed
    }

    // Boundary checks
    newPosition[0] = Math.max(-5, Math.min(5, newPosition[0]))
    newPosition[2] = Math.max(-5, Math.min(5, newPosition[2]))

    // Update user position
    onUserMove(newPosition, newRotation)

    // Continue animation if still moving
    if (isMoving) {
      animationFrameRef.current = requestAnimationFrame(moveUser)
    }
  }

  // Handle mouse movement for rotation
  const handleMouseMove = (e: React.MouseEvent) => {
    if (e.buttons === 1 && containerRef.current) {
      const currentUser = users.find((user) => user.id === userId)
      if (!currentUser) return

      const rect = containerRef.current.getBoundingClientRect()
      const centerX = rect.left + rect.width / 2

      // Calculate rotation based on mouse position relative to center
      const rotationY = ((e.clientX - centerX) / rect.width) * Math.PI

      // Update user rotation
      const newRotation: [number, number, number] = [currentUser.rotation[0], rotationY, currentUser.rotation[2]]

      onUserMove(currentUser.position, newRotation)
    }
  }

  // Generate random speech text for speaking users
  useEffect(() => {
    users.forEach((user) => {
      if (user.speaking && !userSpeechTexts[user.id] && showSpeechBubbles) {
        const randomText = sampleSpeechTexts[Math.floor(Math.random() * sampleSpeechTexts.length)]
        setUserSpeechTexts((prev) => ({
          ...prev,
          [user.id]: randomText,
        }))

        // Clear speech text after a few seconds
        setTimeout(() => {
          setUserSpeechTexts((prev) => {
            const newTexts = { ...prev }
            delete newTexts[user.id]
            return newTexts
          })
        }, 5000)
      }
    })
  }, [users, showSpeechBubbles, userSpeechTexts])

  // Handle user selection
  const handleUserClick = (user: User) => {
    setSelectedUser(user === selectedUser ? null : user)
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full bg-gradient-to-b from-gray-900/50 to-gray-950/50 overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      {/* Room environment */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-[600px] h-[600px] border-2 border-primary/20 rounded-full opacity-20" />

        {/* Center table */}
        <div className="absolute w-32 h-32 bg-amber-800/30 rounded-full border border-amber-700/50" />

        {/* Directional indicators */}
        <div className="absolute top-10 left-1/2 transform -translate-x-1/2 text-primary/40 text-sm">North</div>
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-primary/40 text-sm">South</div>
        <div className="absolute left-10 top-1/2 transform -translate-y-1/2 text-primary/40 text-sm">West</div>
        <div className="absolute right-10 top-1/2 transform -translate-y-1/2 text-primary/40 text-sm">East</div>
      </div>

      {/* Render all users */}
      {users.map((user) => (
        <AvatarModel
          key={user.id}
          user={user}
          position={user.position}
          rotation={user.rotation}
          isSpeaking={user.speaking}
          isCurrentUser={user.id === userId}
          speechText={userSpeechTexts[user.id]}
          onClick={() => handleUserClick(user)}
        />
      ))}

      {/* Controls */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center gap-2 bg-background/80 backdrop-blur-sm p-2 rounded-lg border border-primary/20">
        <Button
          size="sm"
          variant={isMicMuted ? "outline" : "default"}
          onClick={() => setIsMicMuted(!isMicMuted)}
          className="glow-button"
        >
          {isMicMuted ? <MicOff className="h-4 w-4 mr-2" /> : <Mic className="h-4 w-4 mr-2" />}
          {isMicMuted ? "Unmute" : "Mute"}
        </Button>

        <Button
          size="sm"
          variant={isAudioMuted ? "outline" : "default"}
          onClick={() => setIsAudioMuted(!isAudioMuted)}
          className="glow-button"
        >
          {isAudioMuted ? <VolumeX className="h-4 w-4 mr-2" /> : <Volume2 className="h-4 w-4 mr-2" />}
          {isAudioMuted ? "Unmute Audio" : "Mute Audio"}
        </Button>
      </div>

      {/* Movement instructions */}
      <div className="absolute top-4 left-4 bg-background/80 backdrop-blur-sm p-2 rounded text-xs border border-primary/20">
        <p>WASD or Arrow Keys: Move</p>
        <p>Q/E: Rotate</p>
        <p>Click + Drag: Look around</p>
        <p>Click on users to interact</p>
      </div>

      {/* User info panel */}
      {selectedUser && (
        <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm p-3 rounded border border-primary/20 w-64">
          <h3 className="font-medium text-sm">{selectedUser.name}</h3>
          <p className="text-xs text-muted-foreground">{selectedUser.company}</p>
          <div className="mt-2 flex justify-between text-xs">
            <span>{selectedUser.role}</span>
            <span>{selectedUser.country}</span>
          </div>
          <div className="mt-3 flex gap-2">
            <Button size="sm" className="text-xs w-full glow-button">
              Message
            </Button>
            <Button size="sm" variant="outline" className="text-xs w-full glow-button">
              Propose Deal
            </Button>
          </div>
        </div>
      )}

      {/* Spatial audio manager */}
      {spatialAudioEnabled && (
        <SpatialAudioManager users={users} currentUserId={userId} enabled={spatialAudioEnabled && !isAudioMuted} />
      )}
    </div>
  )
}

