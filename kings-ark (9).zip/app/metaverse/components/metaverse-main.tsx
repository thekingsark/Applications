"use client"

import { useState, useEffect, useRef } from "react"
import type { Avatar, User, ChatMessage, Room, Deal } from "@/types/metaverse"
import { AvatarSelector } from "./avatar-selector"
import { TextChatWithTTS } from "./text-chat-with-tts"
import { VoiceChatWithSearch } from "./voice-chat-with-search"
import { DealNegotiation } from "./deal-negotiation"
import MetaverseVoiceSearch from "./metaverse-voice-search"
import { ThreeRenderer } from "./three-renderer"
import { WelcomeVoiceMessage } from "./welcome-voice-message"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import {
  Users,
  MessageSquare,
  Video,
  DollarSign,
  Plus,
  Search,
  Briefcase,
  Home,
  Globe,
  Headphones,
  Map,
  FileText,
  Mic,
  Settings,
  MessageCircle,
} from "lucide-react"
\
Headphones, Map, FileText, Mic, Settings, MessageCircle
} from 'lucide-react'
import SpinningCrownLogo from "@/components/spinning-crown-logo"
import { v4 as uuidv4 } from "uuid"
import Link from "next/link"
import { partnersData } from "../../global-map/partners-data"

// Mock data for avatars
const mockAvatars: Avatar[] = [
  {
    id: "avatar-1",
    name: "Business Person",
    model: "business-person",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Business",
  },
  {
    id: "avatar-2",
    name: "Executive",
    model: "executive",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Executive",
  },
  {
    id: "avatar-3",
    name: "Casual",
    model: "casual",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Casual",
  },
  {
    id: "avatar-4",
    name: "Creative",
    model: "creative",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Creative",
  },
]

// Mock data for rooms
const mockRooms: Room[] = [
  {
    id: "room-1",
    name: "Main Conference Room",
    description: "The main conference room for general meetings",
    capacity: 20,
    currentUsers: 8,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Conference",
  },
  {
    id: "room-2",
    name: "Deal Negotiation Room",
    description: "Private room for negotiating deals",
    capacity: 10,
    currentUsers: 4,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Negotiation",
  },
  {
    id: "room-3",
    name: "Networking Lounge",
    description: "Casual space for networking and informal discussions",
    capacity: 30,
    currentUsers: 12,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Networking",
  },
  {
    id: "room-4",
    name: "Private Meeting Room A",
    description: "Private room for confidential meetings",
    capacity: 6,
    currentUsers: 2,
    isPrivate: true,
    password: "1234",
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Private",
  },
  {
    id: "room-5",
    name: "Global Trade Center",
    description: "International business hub for cross-border deals",
    capacity: 50,
    currentUsers: 18,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Global",
  },
  {
    id: "room-6",
    name: "Pitch Arena",
    description: "Present your business ideas to potential investors",
    capacity: 25,
    currentUsers: 10,
    isPrivate: false,
    owner: "Kings Ark",
    thumbnail: "/placeholder.svg?height=200&width=200&text=Pitch",
  },
]

// Convert partners data to metaverse users
const convertPartnersToUsers = (): User[] => {
  return partnersData.map((partner, index) => {
    const avatarIndex = index % mockAvatars.length
    const isSpeaking = Math.random() > 0.8
    const isTyping = Math.random() > 0.9

    return {
      id: partner.id,
      name: partner.contactPerson,
      avatar: mockAvatars[avatarIndex],
      position: [(Math.random() - 0.5) * 5, 1.6, (Math.random() - 0.5) * 5],
      rotation: [0, Math.random() * Math.PI * 2, 0],
      speaking: isSpeaking,
      typing: isTyping,
      status: "online",
      company: partner.name,
      role: partner.type === "seller" ? "Seller" : partner.type === "buyer" ? "Buyer" : "Both",
      country: partner.country,
    }
  })
}

// Generate mock users for a room
const generateMockUsers = (roomId: string, count: number): User[] => {
  // Use partners data for the first set of users
  const partnerUsers = convertPartnersToUsers().slice(0, count - 5)

  // Add some additional random users to reach the desired count
  const additionalUsers: User[] = []
  for (let i = 0; i < Math.min(5, count - partnerUsers.length); i++) {
    additionalUsers.push({
      id: `user-${i + 1}`,
      name: `User ${i + 1}`,
      avatar: mockAvatars[Math.floor(Math.random() * mockAvatars.length)],
      position: [(Math.random() - 0.5) * 5, 1.6, (Math.random() - 0.5) * 5],
      rotation: [0, Math.random() * Math.PI * 2, 0],
      speaking: Math.random() > 0.8,
      typing: Math.random() > 0.9,
      status: "online",
      company: `Company ${i + 1}`,
      role: Math.random() > 0.5 ? "Buyer" : "Seller",
      country: ["USA", "UK", "Germany", "Japan", "China", "India"][Math.floor(Math.random() * 6)],
    })
  }

  return [...partnerUsers, ...additionalUsers]
}

// Generate more realistic chat messages
const generateRealisticMessages = (roomId: string, users: User[]): ChatMessage[] => {
  const businessMessages = [
    "Has anyone closed a deal in the renewable energy sector recently?",
    "I'm looking for partners in the tech industry, preferably in Asia.",
    "We're expanding our operations to Europe. Any recommendations for logistics partners?",
    "Just closed a $2M deal with a distributor in South America!",
    "Is anyone interested in discussing joint ventures in the manufacturing sector?",
    "Looking for investors for our new AI-powered supply chain solution.",
    "We're offering exclusive rates for first-time partners. DM me for details.",
    "Anyone here from the pharmaceutical industry? We have some interesting proposals.",
    "Just joined from Tokyo. Looking forward to connecting with potential partners.",
    "We're hosting a virtual trade show next month. Let me know if you'd like an invitation.",
    "Has anyone used the new deal negotiation features? They're quite impressive.",
    "Looking for suppliers of organic materials for our new product line.",
    "We're a VC firm looking for promising startups in fintech and healthtech.",
    "Just published our Q2 results. We're looking for new growth opportunities.",
    "Anyone interested in the African market? We have strong connections there.",
  ]

  const messages: ChatMessage[] = []

  // Add system welcome message
  messages.push({
    id: `msg-welcome`,
    userId: "system",
    userName: "Kings Ark Metaverse",
    content: `Welcome to the ${roomId === "room-1" ? "Main Conference Room" : roomId === "room-2" ? "Deal Negotiation Room" : roomId === "room-3" ? "Networking Lounge" : "Private Meeting Room"}! Please introduce yourself and connect with other business partners.`,
    timestamp: new Date(Date.now() - 3600000),
    isPrivate: false,
  })

  // Add some realistic business messages
  for (let i = 0; i < 15; i++) {
    const user = users[Math.floor(Math.random() * users.length)]
    const isPrivate = Math.random() > 0.8
    const recipientId = isPrivate ? users.find((u) => u.id !== user.id)?.id : undefined
    const messageContent = businessMessages[i % businessMessages.length]

    messages.push({
      id: `msg-${i + 1}`,
      userId: user.id,
      userName: user.name,
      content: messageContent,
      timestamp: new Date(Date.now() - (15 - i) * 300000 * Math.random()),
      isPrivate,
      recipientId,
    })
  }

  return messages.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())
}

// Generate more realistic deals
const generateRealisticDeals = (users: User[]): Deal[] => {
  const dealTemplates = [
    {
      title: "Supply Chain Optimization Partnership",
      description: "Collaboration to optimize logistics and reduce delivery times by 30% across Asia.",
      amount: 250000,
      currency: "USD",
    },
    {
      title: "Green Energy Investment",
      description: "Investment in solar panel manufacturing facility with expected ROI of 22% over 5 years.",
      amount: 1500000,
      currency: "EUR",
    },
    {
      title: "Software Distribution Agreement",
      description: "Exclusive distribution rights for enterprise software solutions in South America.",
      amount: 350000,
      currency: "USD",
    },
    {
      title: "Agricultural Export Contract",
      description: "Export of organic produce to European markets with guaranteed minimum volumes.",
      amount: 780000,
      currency: "EUR",
    },
    {
      title: "Manufacturing Joint Venture",
      description: "Joint venture to establish manufacturing facilities in Southeast Asia with shared IP.",
      amount: 2100000,
      currency: "USD",
    },
    {
      title: "Medical Equipment Distribution",
      description: "Distribution of advanced medical diagnostic equipment to hospitals in Middle East.",
      amount: 950000,
      currency: "USD",
    },
    {
      title: "Textile Import Agreement",
      description: "Import of premium textiles for luxury fashion brands with exclusivity clause.",
      amount: 420000,
      currency: "GBP",
    },
    {
      title: "Tech Startup Investment",
      description: "Series A investment in AI-powered fintech solution with board representation.",
      amount: 3500000,
      currency: "USD",
    },
    {
      title: "Pharmaceutical Licensing Deal",
      description: "Licensing of patented pharmaceutical compounds for development in Asian markets.",
      amount: 1800000,
      currency: "USD",
    },
    {
      title: "Retail Expansion Partnership",
      description: "Strategic partnership to expand retail presence in 5 new countries over 3 years.",
      amount: 1250000,
      currency: "EUR",
    },
  ]

  const deals: Deal[] = []
  const statuses: Deal["status"][] = ["proposed", "negotiating", "accepted", "rejected", "completed"]

  for (let i = 0; i < dealTemplates.length; i++) {
    const template = dealTemplates[i]
    const sellers = users.filter((u) => u.role === "Seller" || u.role === "Both")
    const buyers = users.filter((u) => u.role === "Buyer" || u.role === "Both")

    const seller = sellers[Math.floor(Math.random() * sellers.length)]
    const buyer = buyers[Math.floor(Math.random() * buyers.length)]
    const status = statuses[Math.floor(Math.random() * statuses.length)]

    deals.push({
      id: `deal-${i + 1}`,
      title: template.title,
      description: template.description,
      sellerId: seller.id,
      sellerName: seller.name,
      buyerId: buyer.id,
      buyerName: buyer.name,
      amount: template.amount,
      currency: template.currency,
      status,
      createdAt: new Date(Date.now() - (10 - i) * 86400000 * Math.random()),
      updatedAt: new Date(Date.now() - (10 - i) * 43200000 * Math.random()),
      documents: [
        "Contract.pdf",
        "Terms_and_Conditions.pdf",
        "Financial_Projections.xlsx",
        "Legal_Framework.pdf",
        "Technical_Specifications.pdf",
      ].slice(0, Math.floor(Math.random() * 3) + 2),
    })
  }

  return deals
}

export default function MetaverseMain() {
  const [userId] = useState<string>(`user-${uuidv4()}`)
  const [userName, setUserName] = useState<string>("Guest User")
  const [selectedAvatar, setSelectedAvatar] = useState<Avatar | null>(null)
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)
  const [isSetupComplete, setIsSetupComplete] = useState<boolean>(false)
  const [users, setUsers] = useState<User[]>([])
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [deals, setDeals] = useState<Deal[]>([])
  const [activeDeal, setActiveDeal] = useState<Deal | null>(null)
  const [activeTab, setActiveTab] = useState<string>("conference")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [isCreatingDeal, setIsCreatingDeal] = useState<boolean>(false)
  const [newDealTitle, setNewDealTitle] = useState<string>("")
  const [newDealDescription, setNewDealDescription] = useState<string>("")
  const [newDealAmount, setNewDealAmount] = useState<string>("10000")
  const [newDealCurrency, setNewDealCurrency] = useState<string>("USD")
  const [selectedBuyerId, setSelectedBuyerId] = useState<string>("")
  const [showTutorial, setShowTutorial] = useState<boolean>(true)
  const [showMetaverseInfo, setShowMetaverseInfo] = useState<boolean>(false)
  const [spatialAudio, setSpatialAudio] = useState<boolean>(true)
  const [showMap, setShowMap] = useState<boolean>(false)
  const [showVoiceSearch, setShowVoiceSearch] = useState<boolean>(false)
  const [showSettings, setShowSettings] = useState<boolean>(false)
  const [showSpeechBubbles, setShowSpeechBubbles] = useState<boolean>(true)
  const [textToSpeech, setTextToSpeech] = useState<boolean>(true)
  const [voiceCommands, setVoiceCommands] = useState<boolean>(true)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const loadingTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Simulate loading
  useEffect(() => {
    if (selectedRoom) {
      setIsLoading(true)
      loadingTimeoutRef.current = setTimeout(() => {
        setIsLoading(false)
      }, 2000)
    }

    return () => {
      if (loadingTimeoutRef.current) {
        clearTimeout(loadingTimeoutRef.current)
      }
    }
  }, [selectedRoom])

  // Initialize room data when a room is selected
  useEffect(() => {
    if (!selectedRoom) return

    const mockUsers = generateMockUsers(selectedRoom.id, selectedRoom.currentUsers)
    const mockMessages = generateRealisticMessages(selectedRoom.id, mockUsers)
    const mockDeals = generateRealisticDeals(mockUsers)

    setUsers([
      ...mockUsers,
      {
        id: userId,
        name: userName,
        avatar: selectedAvatar || mockAvatars[0],
        position: [0, 1.6, 0],
        rotation: [0, 0, 0],
        speaking: false,
        typing: false,
        status: "online",
        company: "Guest Company",
        role: "Buyer",
        country: "USA",
      },
    ])

    setMessages(mockMessages)
    setDeals(mockDeals)
  }, [selectedRoom, userId, userName, selectedAvatar])

  // Handle user setup completion
  const handleSetupComplete = () => {
    if (!selectedAvatar || !userName.trim()) return
    setIsSetupComplete(true)
  }

  // Handle sending a chat message
  const handleSendMessage = (content: string, isPrivate: boolean, recipientId?: string) => {
    const newMessage: ChatMessage = {
      id: `msg-${uuidv4()}`,
      userId,
      userName,
      content,
      timestamp: new Date(),
      isPrivate,
      recipientId,
    }

    setMessages([...messages, newMessage])

    // Text-to-speech for new messages if enabled
    if (textToSpeech && typeof window !== "undefined" && "speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(
        `${isPrivate ? "Private message from" : "Message from"} ${userName}: ${content}`,
      )
      window.speechSynthesis.speak(utterance)
    }
  }

  // Handle user movement in the 3D space
  const handleUserMove = (position: [number, number, number], rotation: [number, number, number]) => {
    setUsers((prevUsers) => prevUsers.map((user) => (user.id === userId ? { ...user, position, rotation } : user)))
  }

  // Handle voice status change
  const handleVoiceStatusChange = (isSpeaking: boolean) => {
    setUsers((prevUsers) => prevUsers.map((user) => (user.id === userId ? { ...user, speaking: isSpeaking } : user)))
  }

  // Handle deal update
  const handleUpdateDeal = (updatedDeal: Deal) => {
    setDeals((prevDeals) => prevDeals.map((deal) => (deal.id === updatedDeal.id ? updatedDeal : deal)))
    setActiveDeal(null)
  }

  // Handle creating a new deal
  const handleCreateDeal = () => {
    if (!newDealTitle.trim() || !selectedBuyerId) return

    const buyer = users.find((user) => user.id === selectedBuyerId)
    if (!buyer) return

    const newDeal: Deal = {
      id: `deal-${uuidv4()}`,
      title: newDealTitle,
      description: newDealDescription,
      sellerId: userId,
      sellerName: userName,
      buyerId: selectedBuyerId,
      buyerName: buyer.name,
      amount: Number.parseFloat(newDealAmount) || 10000,
      currency: newDealCurrency,
      status: "proposed",
      createdAt: new Date(),
      updatedAt: new Date(),
      documents: [],
    }

    setDeals([...deals, newDeal])
    setIsCreatingDeal(false)
    setNewDealTitle("")
    setNewDealDescription("")
    setNewDealAmount("10000")
    setNewDealCurrency("USD")
    setSelectedBuyerId("")
  }

  // Handle voice search
  const handleVoiceSearch = (query: string) => {
    setSearchQuery(query)
  }

  // Handle voice commands
  const handleVoiceCommand = (command: string, params?: string) => {
    switch (command) {
      case "goto":
        // Find a user by name
        if (params) {
          const targetUser = users.find(
            (u) =>
              u.name.toLowerCase().includes(params.toLowerCase()) ||
              u.company.toLowerCase().includes(params.toLowerCase()),
          )
          if (targetUser) {
            // Move near the target user
            const newPosition: [number, number, number] = [
              targetUser.position[0] + 0.5,
              targetUser.position[1],
              targetUser.position[2] + 0.5,
            ]
            handleUserMove(newPosition, [0, 0, 0])
          }
        }
        break

      case "find":
        // Search for a user and highlight them
        if (params) {
          setSearchQuery(params)
          setActiveTab("users")
        }
        break

      case "join":
        // Join a different room
        if (params) {
          const targetRoom = mockRooms.find((r) => r.name.toLowerCase().includes(params.toLowerCase()))
          if (targetRoom) {
            setSelectedRoom(targetRoom)
          }
        }
        break

      case "createDeal":
        // Create a deal with a specific person
        if (params) {
          const targetUser = users.find(
            (u) => u.name.toLowerCase().includes(params.toLowerCase()) && (u.role === "Buyer" || u.role === "Both"),
          )
          if (targetUser) {
            setSelectedBuyerId(targetUser.id)
            setIsCreatingDeal(true)
          }
        }
        break

      case "openMap":
        setShowMap(true)
        break

      case "toggleSpatialAudio":
        setSpatialAudio(!spatialAudio)
        break

      case "muteAll":
        // Implementation for muting all users
        break

      case "unmuteAll":
        // Implementation for unmuting all users
        break

      case "showParticipants":
        setActiveTab("users")
        break

      case "showDeals":
        setActiveTab("deals")
        break

      default:
        // Unknown command
        break
    }
  }

  // Filter users based on search query
  const filteredUsers = users.filter(
    (user) =>
      user.id !== userId &&
      (user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.role.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  // Filter deals based on search query
  const filteredDeals = deals.filter(
    (deal) =>
      deal.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.sellerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deal.buyerName.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // If setup is not complete, show the setup screen
  if (!isSetupComplete) {
    return (
      <div className="flex min-h-screen bg-gradient-to-b from-background to-background/80">
        <div className="flex-1 flex flex-col items-center justify-center p-6">
          <div className="w-full max-w-md">
            <div className="flex flex-col items-center mb-8">
              <SpinningCrownLogo size={64} />
              <h1 className="text-3xl font-bold mt-4">Kings Ark Metaverse</h1>
              <p className="text-muted-foreground mt-2">Virtual Business Conference</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Welcome to the Metaverse</CardTitle>
                <CardDescription>Please set up your profile before entering the virtual conference.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="username">Your Name</Label>
                  <Input
                    id="username"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Enter your name"
                  />
                </div>

                <AvatarSelector
                  avatars={mockAvatars}
                  selectedAvatar={selectedAvatar}
                  onSelectAvatar={setSelectedAvatar}
                />

                <Button
                  className="w-full glow-button"
                  size="lg"
                  onClick={handleSetupComplete}
                  disabled={!selectedAvatar || !userName.trim()}
                >
                  Enter Metaverse
                </Button>

                <div className="text-center text-sm text-muted-foreground">
                  <Link href="/" className="hover:underline">
                    Return to Kings Ark Dashboard
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  // If no room is selected, show the room selection screen
  if (!selectedRoom) {
    return (
      <div className="flex min-h-screen bg-gradient-to-b from-background to-background/80">
        <div className="flex-1 flex flex-col p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
              <SpinningCrownLogo size={40} />
              <h1 className="text-2xl font-bold ml-4">Kings Ark Metaverse</h1>
            </div>

            <Link href="/">
              <Button variant="outline" className="glow-button">
                <Home className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockRooms.map((room) => (
              <Card
                key={room.id}
                className="cursor-pointer transition-all hover:scale-105 hover:shadow-lg hover:shadow-primary/20"
                onClick={() => setSelectedRoom(room)}
              >
                <div className="aspect-video w-full overflow-hidden rounded-t-lg">
                  <img
                    src={room.thumbnail || "/placeholder.svg"}
                    alt={room.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{room.name}</CardTitle>
                    {room.isPrivate && <Badge variant="outline">Private</Badge>}
                  </div>
                  <CardDescription>{room.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                      <span>
                        {room.currentUsers}/{room.capacity}
                      </span>
                    </div>
                    <div className="text-muted-foreground">Hosted by {room.owner}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    )
  }

  // Show loading screen
  if (isLoading) {
    return (
      <div className="flex min-h-screen bg-gradient-to-b from-background to-background/80 items-center justify-center">
        <div className="text-center">
          <SpinningCrownLogo size={64} />
          <h2 className="text-2xl font-bold mt-4">Entering {selectedRoom.name}</h2>
          <p className="text-muted-foreground mt-2">Loading virtual environment...</p>
          <div className="mt-4 flex justify-center space-x-2">
            <div className="h-2 w-2 bg-primary rounded-full animate-bounce"></div>
            <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-75"></div>
            <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-150"></div>
            <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-300"></div>
          </div>
        </div>
      </div>
    )
  }

  // Main metaverse interface
  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-background to-background/80">
      <header className="border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <SpinningCrownLogo size={32} />
            <h1 className="text-xl font-bold ml-2">Kings Ark Metaverse</h1>
            <Separator orientation="vertical" className="mx-4 h-6" />
            <div className="text-muted-foreground">
              Room: <span className="font-medium text-foreground">{selectedRoom.name}</span>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative">
              <Input
                placeholder="Search users or deals..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64"
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>

            <Button
              variant="outline"
              size="icon"
              className="glow-button"
              onClick={() => setShowVoiceSearch(true)}
              title="Voice Search"
            >
              <Mic className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="icon"
              className="glow-button"
              onClick={() => setShowMetaverseInfo(true)}
              title="Metaverse Information"
            >
              <Globe className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="icon"
              className={`${spatialAudio ? "bg-primary/10" : ""} glow-button`}
              onClick={() => setSpatialAudio(!spatialAudio)}
              title={spatialAudio ? "Disable Spatial Audio" : "Enable Spatial Audio"}
            >
              <Headphones className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="icon"
              className={`${showMap ? "bg-primary/10" : ""} glow-button`}
              onClick={() => setShowMap(!showMap)}
              title="Toggle Map View"
            >
              <Map className="h-4 w-4" />
            </Button>

            <Button
              variant="outline"
              size="icon"
              className="glow-button"
              onClick={() => setShowSettings(true)}
              title="Metaverse Settings"
            >
              <Settings className="h-4 w-4" />
            </Button>

            <Link href="/">
              <Button variant="outline" className="glow-button">
                <Home className="mr-2 h-4 w-4" />
                Back to Home
              </Button>
            </Link>

            <Button variant="outline" onClick={() => setSelectedRoom(null)}>
              Exit Room
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <div className="flex-1 flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <div className="border-b px-4">
              <TabsList className="h-12">
                <TabsTrigger value="conference" className="flex items-center">
                  <Video className="h-4 w-4 mr-2" />
                  Conference Room
                </TabsTrigger>
                <TabsTrigger value="users" className="flex items-center">
                  <Users className="h-4 w-4 mr-2" />
                  Participants
                </TabsTrigger>
                <TabsTrigger value="deals" className="flex items-center">
                  <Briefcase className="h-4 w-4 mr-2" />
                  Deals
                </TabsTrigger>
                <TabsTrigger value="documents" className="flex items-center">
                  <FileText className="h-4 w-4 mr-2" />
                  Documents
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="conference" className="flex-1 p-0 m-0">
              <div className="h-full">
                {isLoading ? (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center">
                      <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                      <p className="mt-2">Loading 3D environment...</p>
                    </div>
                  </div>
                ) : (
                  <ThreeRenderer
                    users={users}
                    currentUserId={userId}
                    onUserMove={handleUserMove}
                    onUserSelect={(selectedUserId) => {
                      const user = users.find((u) => u.id === selectedUserId)
                      if (user) {
                        // Show user info or open chat
                        setActiveTab("users")
                        setSearchQuery(user.name)
                      }
                    }}
                  />
                )}
              </div>
            </TabsContent>

            <TabsContent value="users" className="flex-1 p-4 m-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredUsers.map((user) => (
                  <Card key={user.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{user.name}</CardTitle>
                        <Badge>{user.role}</Badge>
                      </div>
                      <CardDescription>{user.company}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between mb-4">
                        <div className="text-sm text-muted-foreground">{user.country}</div>
                        <div className="flex items-center">
                          {user.speaking && (
                            <Badge
                              variant="outline"
                              className="mr-2 bg-green-500/10 text-green-500 border-green-500/20"
                            >
                              Speaking
                            </Badge>
                          )}
                          {user.typing && (
                            <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500/20">
                              Typing...
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 glow-button"
                          onClick={() => {
                            setActiveTab("conference")
                            // Find user in 3D space
                            const currentUser = users.find((u) => u.id === userId)
                            if (currentUser && user) {
                              // Move near the target user
                              const newPosition: [number, number, number] = [
                                user.position[0] + 0.5,
                                user.position[1],
                                user.position[2] + 0.5,
                              ]
                              handleUserMove(newPosition, [0, 0, 0])
                            }
                          }}
                        >
                          Find in Room
                        </Button>

                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1 glow-button"
                          onClick={() => {
                            // Open private chat
                            const privateMessage = `Hello ${user.name}, I'd like to connect with you.`
                            handleSendMessage(privateMessage, true, user.id)
                          }}
                        >
                          <MessageCircle className="h-3 w-3 mr-1" />
                          Message
                        </Button>

                        {(user.role === "Buyer" || user.role === "Both") && (
                          <Button
                            size="sm"
                            className="flex-1 glow-button"
                            onClick={() => {
                              setIsCreatingDeal(true)
                              setSelectedBuyerId(user.id)
                            }}
                          >
                            Propose Deal
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="deals" className="flex-1 p-4 m-0">
              <div className="flex justify-between mb-4">
                <h2 className="text-xl font-bold">Business Deals</h2>
                <Button onClick={() => setIsCreatingDeal(true)} className="glow-button">
                  <Plus className="h-4 w-4 mr-2" />
                  New Deal
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredDeals.map((deal) => (
                  <Card
                    key={deal.id}
                    className="cursor-pointer hover:bg-accent/50 hover:shadow-md transition-all"
                    onClick={() => setActiveDeal(deal)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{deal.title}</CardTitle>
                        <Badge
                          className={
                            deal.status === "proposed"
                              ? "bg-blue-500"
                              : deal.status === "negotiating"
                                ? "bg-amber-500"
                                : deal.status === "accepted"
                                  ? "bg-green-500"
                                  : deal.status === "rejected"
                                    ? "bg-red-500"
                                    : "bg-purple-500"
                          }
                        >
                          {deal.status.charAt(0).toUpperCase() + deal.status.slice(1)}
                        </Badge>
                      </div>
                      <CardDescription>{deal.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm">
                          <span className="text-muted-foreground">Amount: </span>
                          <span className="font-medium">
                            {deal.amount.toLocaleString()} {deal.currency}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(deal.updatedAt).toLocaleDateString()}
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <div>
                          <span className="text-muted-foreground">Seller: </span>
                          <span>{deal.sellerName}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Buyer: </span>
                          <span>{deal.buyerName}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="documents" className="flex-1 p-4 m-0">
              <div className="flex justify-between mb-4">
                <h2 className="text-xl font-bold">Shared Documents</h2>
                <Button className="glow-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Upload Document
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  "Business Proposal Template.docx",
                  "NDA Agreement.pdf",
                  "Investment Opportunity.pdf",
                  "Market Analysis Q2 2023.xlsx",
                  "Partnership Agreement.pdf",
                  "Product Specifications.pdf",
                  "Financial Projections 2023-2025.xlsx",
                  "Company Profile.pdf",
                  "Technical Documentation.pdf",
                ].map((doc, index) => (
                  <Card key={index} className="cursor-pointer hover:bg-accent/50 hover:shadow-md transition-all">
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <FileText className="h-8 w-8 mr-3 text-primary" />
                        <div>
                          <div className="font-medium">{doc}</div>
                          <div className="text-xs text-muted-foreground">
                            Shared by: {users[index % users.length]?.name || "System"}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="w-80 border-l flex flex-col">
          <Tabs defaultValue="text" className="flex-1 flex flex-col">
            <TabsList className="w-full h-12 grid grid-cols-2">
              <TabsTrigger value="text" className="flex items-center">
                <MessageSquare className="h-4 w-4 mr-2" />
                Text Chat
              </TabsTrigger>
              <TabsTrigger value="voice" className="flex items-center">
                <Video className="h-4 w-4 mr-2" />
                Voice Chat
              </TabsTrigger>
            </TabsList>

            <TabsContent value="text" className="flex-1 p-0 m-0">
              <TextChatWithTTS
                roomId={selectedRoom.id}
                userId={userId}
                userName={userName}
                users={users}
                messages={messages}
                onSendMessage={handleSendMessage}
                textToSpeechEnabled={textToSpeech}
              />
            </TabsContent>

            <TabsContent value="voice" className="flex-1 p-0 m-0">
              <VoiceChatWithSearch
                roomId={selectedRoom.id}
                userId={userId}
                users={users}
                onVoiceStatusChange={handleVoiceStatusChange}
                onUserSelect={(selectedUserId) => {
                  const user = users.find((u) => u.id === selectedUserId)
                  if (user) {
                    // Navigate to user in 3D space
                    setActiveTab("conference")
                    const newPosition: [number, number, number] = [
                      user.position[0] + 0.5,
                      user.position[1],
                      user.position[2] + 0.5,
                    ]
                    handleUserMove(newPosition, [0, 0, 0])
                  }
                }}
                textToSpeechEnabled={textToSpeech}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Deal negotiation dialog */}
      {activeDeal && (
        <DealNegotiation
          deal={activeDeal}
          userId={userId}
          onUpdateDeal={handleUpdateDeal}
          onClose={() => setActiveDeal(null)}
        />
      )}

      {/* Create deal dialog */}
      <Dialog open={isCreatingDeal} onOpenChange={setIsCreatingDeal}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New Deal</DialogTitle>
            <DialogDescription>Propose a new business deal to a potential buyer.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Deal Title</Label>
              <Input
                id="title"
                value={newDealTitle}
                onChange={(e) => setNewDealTitle(e.target.value)}
                placeholder="Enter deal title"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={newDealDescription}
                onChange={(e) => setNewDealDescription(e.target.value)}
                placeholder="Describe the deal"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <div className="relative">
                  <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="amount"
                    type="number"
                    value={newDealAmount}
                    onChange={(e) => setNewDealAmount(e.target.value)}
                    className="pl-8"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="currency">Currency</Label>
                <select
                  id="currency"
                  value={newDealCurrency}
                  onChange={(e) => setNewDealCurrency(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                >
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                  <option value="GBP">GBP</option>
                  <option value="JPY">JPY</option>
                  <option value="CNY">CNY</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="buyer">Select Buyer</Label>
              <select
                id="buyer"
                value={selectedBuyerId}
                onChange={(e) => setSelectedBuyerId(e.target.value)}
                className="w-full h-10 px-3 rounded-md border border-input bg-background"
              >
                <option value="">Select a buyer</option>
                {users
                  .filter((user) => user.id !== userId && (user.role === "Buyer" || user.role === "Both"))
                  .map((user) => (
                    <option key={user.id} value={user.id}>
                      {user.name} ({user.company})
                    </option>
                  ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setIsCreatingDeal(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateDeal}
              disabled={!newDealTitle.trim() || !selectedBuyerId}
              className="glow-button"
            >
              Create Deal
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Metaverse Information Dialog */}
      <Dialog open={showMetaverseInfo} onOpenChange={setShowMetaverseInfo}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Kings Ark Metaverse</DialogTitle>
            <DialogDescription>Virtual business environment for global trade and networking</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <h3 className="text-lg font-medium mb-2">Features</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <Globe className="h-5 w-5 mr-2 text-primary shrink-0" />
                  <span>3D Virtual Conference Rooms for business meetings and networking</span>
                </li>
                <li className="flex items-start">
                  <MessageSquare className="h-5 w-5 mr-2 text-primary shrink-0" />
                  <span>Real-time text chat with public and private messaging</span>
                </li>
                <li className="flex items-start">
                  <Headphones className="h-5 w-5 mr-2 text-primary shrink-0" />
                  <span>Spatial voice chat with proximity-based audio</span>
                </li>
                <li className="flex items-start">
                  <Briefcase className="h-5 w-5 mr-2 text-primary shrink-0" />
                  <span>Deal negotiation platform for business transactions</span>
                </li>
                <li className="flex items-start">
                  <FileText className="h-5 w-5 mr-2 text-primary shrink-0" />
                  <span>Document sharing and collaborative review</span>
                </li>
                <li className="flex items-start">
                  <Mic className="h-5 w-5 mr-2 text-primary shrink-0" />
                  <span>Voice commands and voice search capabilities</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Controls</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-medium">Movement</p>
                  <p className="text-muted-foreground">W, A, S, D or Arrow Keys</p>
                </div>
                <div>
                  <p className="font-medium">Look Around</p>
                  <p className="text-muted-foreground">Q, E or Click + Drag</p>
                </div>
                <div>
                  <p className="font-medium">Interact</p>
                  <p className="text-muted-foreground">Click on users or objects</p>
                </div>
                <div>
                  <p className="font-medium">Voice Chat</p>
                  <p className="text-muted-foreground">Press Space to talk</p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => setShowMetaverseInfo(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Metaverse Settings</DialogTitle>
            <DialogDescription>Customize your metaverse experience</DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Audio Settings</h3>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="spatial-audio">Spatial Audio</Label>
                  <p className="text-sm text-muted-foreground">Hear users based on their proximity to you</p>
                </div>
                <Switch id="spatial-audio" checked={spatialAudio} onCheckedChange={setSpatialAudio} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="text-to-speech">Text-to-Speech</Label>
                  <p className="text-sm text-muted-foreground">Read chat messages aloud</p>
                </div>
                <Switch id="text-to-speech" checked={textToSpeech} onCheckedChange={setTextToSpeech} />
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Voice Controls</h3>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="voice-commands">Voice Commands</Label>
                  <p className="text-sm text-muted-foreground">Control the metaverse using voice commands</p>
                </div>
                <Switch id="voice-commands" checked={voiceCommands} onCheckedChange={setVoiceCommands} />
              </div>
            </div>

            <Separator />

            <div className="space-y-4">
              <h3 className="text-lg font-medium">Visual Settings</h3>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="speech-bubbles">Speech Bubbles</Label>
                  <p className="text-sm text-muted-foreground">Show speech bubbles above avatars</p>
                </div>
                <Switch id="speech-bubbles" checked={showSpeechBubbles} onCheckedChange={setShowSpeechBubbles} />
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => setShowSettings(false)}>Save Settings</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Tutorial Dialog */}
      <Dialog open={showTutorial} onOpenChange={setShowTutorial}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Welcome to Kings Ark Metaverse</DialogTitle>
            <DialogDescription>A quick guide to get you started</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <p>You've entered the {selectedRoom.name}. Here's how to make the most of your experience:</p>

            <ol className="space-y-2 list-decimal pl-5">
              <li>Use WASD keys to move and Q/E to rotate in the 3D space</li>
              <li>Click and drag to look around</li>
              <li>Approach other participants to engage in spatial voice chat</li>
              <li>Use the text chat panel on the right for written communication</li>
              <li>Click the microphone icon in the header for voice search and commands</li>
              <li>Browse the Participants tab to find business partners</li>
              <li>Create or respond to deals in the Deals tab</li>
            </ol>

            <p className="text-sm text-muted-foreground">
              This virtual environment is designed to facilitate business networking and deal-making in an immersive
              setting.
            </p>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => setShowTutorial(false)} className="glow-button">
              Get Started
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Voice Search Modal */}
      <MetaverseVoiceSearch
        isOpen={showVoiceSearch}
        onClose={() => setShowVoiceSearch(false)}
        onSearch={handleVoiceSearch}
        onCommand={voiceCommands ? handleVoiceCommand : undefined}
      />

      {/* Map Overlay */}
      {showMap && (
        <div className="absolute top-20 right-4 w-64 h-64 bg-background/90 backdrop-blur-sm border rounded-md shadow-lg p-2">
          <div className="text-sm font-medium mb-2 flex justify-between items-center">
            <span>Room Map</span>
            <Button variant="ghost" size="sm" className="h-6 w-6 p-0" onClick={() => setShowMap(false)}>
              ×
            </Button>
          </div>
          <div className="relative w-full h-[calc(100%-28px)] bg-muted/50 rounded">
            {/* Simple map representation */}
            <div className="absolute inset-2 border-2 border-primary/30 rounded"></div>

            {/* Table */}
            <div className="absolute left-1/2 top-1/2 w-16 h-8 -translate-x-1/2 -translate-y-1/2 bg-amber-800/70 rounded"></div>

            {/* User dots */}
            {users.map((user) => {
              // Convert 3D position to 2D map coordinates
              const x = (user.position[0] / 10 + 0.5) * 100
              const y = (user.position[2] / 10 + 0.5) * 100

              return (
                <div
                  key={user.id}
                  className={`absolute w-2 h-2 rounded-full ${user.id === userId ? "bg-blue-500" : user.speaking ? "bg-green-500" : "bg-gray-400"}`}
                  style={{
                    left: `${Math.max(2, Math.min(98, x))}%`,
                    top: `${Math.max(2, Math.min(98, y))}%`,
                  }}
                  title={user.name}
                ></div>
              )
            })}
          </div>
        </div>
      )}
      {/* Welcome voice message */}
      <WelcomeVoiceMessage room={selectedRoom} userName={userName} enabled={textToSpeech} />
    </div>
  )
}

