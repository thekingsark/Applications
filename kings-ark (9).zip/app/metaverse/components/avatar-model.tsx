"use client"

import { useRef, useEffect, useState } from "react"
import { SpeechBubble } from "./speech-bubble"
import type { User } from "@/types/metaverse"

interface AvatarModelProps {
  user: User
  position: [number, number, number]
  rotation: [number, number, number]
  isSpeaking: boolean
  isCurrentUser: boolean
  speechText?: string
  onClick?: () => void
}

export function AvatarModel({
  user,
  position,
  rotation,
  isSpeaking,
  isCurrentUser,
  speechText,
  onClick,
}: AvatarModelProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [bubblePosition, setBubblePosition] = useState({ x: 0, y: 0 })

  // Update bubble position based on avatar position
  useEffect(() => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect()
      setBubblePosition({
        x: rect.left + rect.width / 2,
        y: rect.top,
      })
    }
  }, [position])

  return (
    <div
      ref={containerRef}
      className={`
        absolute transform-gpu transition-all duration-300 ease-out
        ${isCurrentUser ? "border-2 border-primary rounded-full" : ""}
      `}
      style={{
        left: `calc(50% + ${position[0] * 50}px)`,
        top: `calc(50% + ${position[2] * 50}px)`,
        transform: `translate(-50%, -50%) rotateY(${rotation[1]}rad)`,
        zIndex: Math.floor(position[2] * 100) + 1000,
      }}
      onClick={onClick}
    >
      {/* Avatar representation */}
      <div className="relative">
        <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden">
          <img
            src={user.avatar.thumbnail || "/placeholder.svg"}
            alt={user.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Speaking indicator */}
        {isSpeaking && (
          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse border-2 border-background" />
        )}

        {/* Name tag */}
        <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 bg-background/80 backdrop-blur-sm px-2 py-0.5 rounded text-xs whitespace-nowrap">
          {user.name}
        </div>
      </div>

      {/* Speech bubble */}
      <SpeechBubble text={speechText || ""} position={bubblePosition} isActive={isSpeaking && !!speechText} />
    </div>
  )
}

