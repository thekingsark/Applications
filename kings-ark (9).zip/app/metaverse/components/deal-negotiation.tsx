"use client"

import type React from "react"

import { useState } from "react"
import type { Deal } from "@/types/metaverse"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Check, X, FileText, DollarSign, Send } from "lucide-react"

interface DealNegotiationProps {
  deal: Deal
  userId: string
  onUpdateDeal: (deal: Deal) => void
  onClose: () => void
}

export function DealNegotiation({ deal, userId, onUpdateDeal, onClose }: DealNegotiationProps) {
  const [updatedDeal, setUpdatedDeal] = useState<Deal>({ ...deal })
  const [comment, setComment] = useState("")

  const isOwner = userId === deal.sellerId
  const canAccept = userId === deal.buyerId && deal.status === "proposed"
  const canCounter = userId !== deal.sellerId && deal.status === "proposed"

  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseFloat(e.target.value)
    if (!isNaN(value)) {
      setUpdatedDeal({ ...updatedDeal, amount: value })
    }
  }

  const handleCurrencyChange = (value: string) => {
    setUpdatedDeal({ ...updatedDeal, currency: value })
  }

  const handleAccept = () => {
    onUpdateDeal({
      ...deal,
      status: "accepted",
      updatedAt: new Date(),
    })
  }

  const handleReject = () => {
    onUpdateDeal({
      ...deal,
      status: "rejected",
      updatedAt: new Date(),
    })
  }

  const handleCounter = () => {
    onUpdateDeal({
      ...updatedDeal,
      status: "negotiating",
      updatedAt: new Date(),
    })
  }

  const handleComplete = () => {
    onUpdateDeal({
      ...deal,
      status: "completed",
      updatedAt: new Date(),
    })
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Deal Negotiation</DialogTitle>
          <DialogDescription>
            {deal.status === "proposed" && "Review and respond to this deal proposal"}
            {deal.status === "negotiating" && "This deal is being negotiated"}
            {deal.status === "accepted" && "This deal has been accepted"}
            {deal.status === "rejected" && "This deal has been rejected"}
            {deal.status === "completed" && "This deal has been completed"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">Deal Title</Label>
            <Input
              id="title"
              value={updatedDeal.title}
              onChange={(e) => setUpdatedDeal({ ...updatedDeal, title: e.target.value })}
              disabled={!isOwner || deal.status === "accepted" || deal.status === "completed"}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={updatedDeal.description}
              onChange={(e) => setUpdatedDeal({ ...updatedDeal, description: e.target.value })}
              disabled={!isOwner || deal.status === "accepted" || deal.status === "completed"}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <div className="relative">
                <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="amount"
                  type="number"
                  value={updatedDeal.amount}
                  onChange={handleAmountChange}
                  disabled={deal.status === "accepted" || deal.status === "completed"}
                  className="pl-8"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select
                value={updatedDeal.currency}
                onValueChange={handleCurrencyChange}
                disabled={deal.status === "accepted" || deal.status === "completed"}
              >
                <SelectTrigger id="currency">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD</SelectItem>
                  <SelectItem value="EUR">EUR</SelectItem>
                  <SelectItem value="GBP">GBP</SelectItem>
                  <SelectItem value="JPY">JPY</SelectItem>
                  <SelectItem value="CNY">CNY</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Parties</Label>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 border rounded-md">
                <div className="text-xs text-muted-foreground">Seller</div>
                <div className="font-medium">{deal.sellerName}</div>
              </div>
              <div className="p-3 border rounded-md">
                <div className="text-xs text-muted-foreground">Buyer</div>
                <div className="font-medium">{deal.buyerName}</div>
              </div>
            </div>
          </div>

          {deal.documents.length > 0 && (
            <div className="space-y-2">
              <Label>Documents</Label>
              <div className="space-y-2">
                {deal.documents.map((doc, index) => (
                  <div key={index} className="flex items-center p-2 border rounded-md">
                    <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span className="text-sm">{doc}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {(deal.status === "proposed" || deal.status === "negotiating") && (
            <div className="space-y-2">
              <Label htmlFor="comment">Add Comment</Label>
              <Textarea
                id="comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Add a comment to your response..."
                rows={2}
              />
            </div>
          )}
        </div>

        <DialogFooter className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">Last updated: {new Date(deal.updatedAt).toLocaleString()}</div>

          <div className="flex space-x-2">
            {deal.status === "proposed" && (
              <>
                {canAccept && (
                  <Button onClick={handleAccept} className="bg-green-600 hover:bg-green-700">
                    <Check className="mr-2 h-4 w-4" />
                    Accept
                  </Button>
                )}

                {canCounter && (
                  <Button onClick={handleCounter} variant="outline">
                    <Send className="mr-2 h-4 w-4" />
                    Counter
                  </Button>
                )}

                <Button onClick={handleReject} variant="destructive">
                  <X className="mr-2 h-4 w-4" />
                  Reject
                </Button>
              </>
            )}

            {deal.status === "negotiating" && (
              <>
                <Button onClick={handleAccept} className="bg-green-600 hover:bg-green-700">
                  <Check className="mr-2 h-4 w-4" />
                  Accept
                </Button>

                <Button onClick={handleCounter} variant="outline">
                  <Send className="mr-2 h-4 w-4" />
                  Counter
                </Button>
              </>
            )}

            {deal.status === "accepted" && (
              <Button onClick={handleComplete} className="bg-green-600 hover:bg-green-700">
                <Check className="mr-2 h-4 w-4" />
                Complete Deal
              </Button>
            )}

            {(deal.status === "completed" || deal.status === "rejected") && <Button onClick={onClose}>Close</Button>}
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}

