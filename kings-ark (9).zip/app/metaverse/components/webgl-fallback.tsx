"use client"
import { Button } from "@/components/ui/button"

interface WebGLFallbackProps {
  errorMessage: string
  onRetry: () => void
}

export function WebGLFallback({ errorMessage, onRetry }: WebGLFallbackProps) {
  return (
    <div className="flex min-h-full w-full items-center justify-center bg-background p-6">
      <div className="max-w-md text-center bg-background/90 backdrop-blur-sm p-8 rounded-lg border border-primary/20 shadow-lg">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-16 w-16 mx-auto text-yellow-500"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
          />
        </svg>

        <h2 className="text-2xl font-bold mt-4">3D Environment Error</h2>
        <p className="mt-2 text-muted-foreground">{errorMessage}</p>

        <div className="mt-6 bg-muted p-4 rounded-md text-sm text-left">
          <p className="font-medium mb-2">Troubleshooting tips:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>Make sure your browser is up to date</li>
            <li>Try disabling hardware acceleration in your browser settings</li>
            <li>Check if WebGL is enabled in your browser</li>
            <li>Try using a different browser (Chrome, Firefox, Edge)</li>
            <li>Update your graphics drivers</li>
          </ul>
        </div>

        <Button className="mt-6" onClick={onRetry}>
          Try Again
        </Button>
      </div>
    </div>
  )
}

