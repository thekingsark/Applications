"use client"

import { useEffect, useRef, useState } from "react"
import type { User } from "@/types/metaverse"
import { Button } from "@/components/ui/button"
import { Loader2, ZoomIn, ZoomOut, Maximize, Minimize } from "lucide-react"
import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js"

interface ConferenceRoomProps {
  roomId: string
  userId: string
  users: User[]
  onUserMove: (position: [number, number, number], rotation: [number, number, number]) => void
}

export function ConferenceRoom({ roomId, userId, users, onUserMove }: ConferenceRoomProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const sceneRef = useRef<THREE.Scene | null>(null)
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null)
  const controlsRef = useRef<OrbitControls | null>(null)
  const avatarModelsRef = useRef<Map<string, THREE.Group>>(new Map())
  const [isLoading, setIsLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const animationFrameRef = useRef<number | null>(null)
  const lastPositionRef = useRef<[number, number, number]>([0, 0, 0])
  const lastRotationRef = useRef<[number, number, number]>([0, 0, 0])
  const positionUpdateIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [zoomLevel, setZoomLevel] = useState(5)
  const interactiveObjectsRef = useRef<THREE.Object3D[]>([])
  const raycasterRef = useRef(new THREE.Raycaster())
  const mouseRef = useRef(new THREE.Vector2())
  const [hoveredObject, setHoveredObject] = useState<string | null>(null)

  // Initialize Three.js scene
  useEffect(() => {
    if (!containerRef.current) return

    // Create scene
    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0x1a1a2e)
    sceneRef.current = scene

    // Create camera
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000,
    )
    camera.position.set(0, 1.6, zoomLevel)
    cameraRef.current = camera

    // Create renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
    renderer.setPixelRatio(window.devicePixelRatio)
    renderer.shadowMap.enabled = true
    containerRef.current.appendChild(renderer.domElement)
    rendererRef.current = renderer

    // Add controls
    const controls = new OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true
    controls.dampingFactor = 0.05
    controls.minDistance = 1
    controls.maxDistance = 10
    controls.maxPolarAngle = Math.PI / 2
    controlsRef.current = controls

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
    scene.add(ambientLight)

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
    directionalLight.position.set(5, 10, 7.5)
    directionalLight.castShadow = true
    directionalLight.shadow.mapSize.width = 1024
    directionalLight.shadow.mapSize.height = 1024
    scene.add(directionalLight)

    // Add point lights for better ambiance
    const pointLight1 = new THREE.PointLight(0x3366ff, 0.5, 10)
    pointLight1.position.set(3, 3, 3)
    scene.add(pointLight1)

    const pointLight2 = new THREE.PointLight(0xff6633, 0.5, 10)
    pointLight2.position.set(-3, 3, -3)
    scene.add(pointLight2)

    // Create a simple room
    createEnhancedRoom(scene)

    // Simulate loading for better UX
    setTimeout(() => {
      setIsLoading(false)
    }, 1500)

    // Update loading progress for visual feedback
    const loadingInterval = setInterval(() => {
      setLoadingProgress((prev) => {
        const newProgress = prev + 10
        if (newProgress >= 100) {
          clearInterval(loadingInterval)
          return 100
        }
        return newProgress
      })
    }, 150)

    // Mouse move event for raycasting
    const handleMouseMove = (event: MouseEvent) => {
      if (!containerRef.current) return

      const rect = containerRef.current.getBoundingClientRect()
      mouseRef.current.x = ((event.clientX - rect.left) / containerRef.current.clientWidth) * 2 - 1
      mouseRef.current.y = -((event.clientY - rect.top) / containerRef.current.clientHeight) * 2 + 1
    }

    // Mouse click event for interaction
    const handleMouseClick = () => {
      if (!sceneRef.current || !cameraRef.current) return

      raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current)
      const intersects = raycasterRef.current.intersectObjects(interactiveObjectsRef.current, true)

      if (intersects.length > 0) {
        const object = intersects[0].object

        if (object.userData.type === "screen") {
          // Handle screen interaction
          alert("Presentation screen clicked. In a real app, this would open a presentation.")
        } else if (object.userData.type === "whiteboard") {
          // Handle whiteboard interaction
          alert("Whiteboard clicked. In a real app, this would open a collaborative whiteboard.")
        } else if (object.userData.type === "document") {
          // Handle document interaction
          alert(`Document clicked: ${object.userData.name}. In a real app, this would open the document.`)
        }
      }
    }

    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("click", handleMouseClick)

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return

      cameraRef.current.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight
      cameraRef.current.updateProjectionMatrix()
      rendererRef.current.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
    }

    window.addEventListener("resize", handleResize)

    // Animation loop
    const animate = () => {
      try {
        if (!controlsRef.current || !rendererRef.current || !sceneRef.current || !cameraRef.current) return

        controlsRef.current.update()

        // Raycasting for interactive objects
        raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current)
        const intersects = raycasterRef.current.intersectObjects(interactiveObjectsRef.current, true)

        if (intersects.length > 0) {
          const object = intersects[0].object
          if (object.userData.name && object.userData.name !== hoveredObject) {
            setHoveredObject(object.userData.name)
            document.body.style.cursor = "pointer"
          }
        } else if (hoveredObject) {
          setHoveredObject(null)
          document.body.style.cursor = "default"
        }

        // Animate point lights for ambiance
        const time = Date.now() * 0.001
        const pointLights = sceneRef.current.children.filter((child) => child instanceof THREE.PointLight)

        if (pointLights.length >= 2) {
          const light1 = pointLights[0] as THREE.PointLight
          const light2 = pointLights[1] as THREE.PointLight

          light1.intensity = 0.5 + Math.sin(time) * 0.2
          light2.intensity = 0.5 + Math.cos(time) * 0.2
        }

        rendererRef.current.render(sceneRef.current, cameraRef.current)

        // Update user position and rotation
        if (controlsRef.current.target && cameraRef.current) {
          const position: [number, number, number] = [
            cameraRef.current.position.x,
            cameraRef.current.position.y,
            cameraRef.current.position.z,
          ]

          const rotation: [number, number, number] = [
            cameraRef.current.rotation.x,
            cameraRef.current.rotation.y,
            cameraRef.current.rotation.z,
          ]

          // Store last position and rotation
          lastPositionRef.current = position
          lastRotationRef.current = rotation
        }
      } catch (error) {
        console.error("Error in animation loop:", error)
      }

      animationFrameRef.current = requestAnimationFrame(animate)
    }

    animate()

    // Set up interval to send position updates (to avoid too many updates)
    positionUpdateIntervalRef.current = setInterval(() => {
      onUserMove(lastPositionRef.current, lastRotationRef.current)
    }, 200) // Update every 200ms

    return () => {
      if (rendererRef.current && containerRef.current) {
        try {
          containerRef.current.removeChild(rendererRef.current.domElement)
        } catch (error) {
          console.error("Error removing renderer:", error)
        }
      }

      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
      }

      if (positionUpdateIntervalRef.current) {
        clearInterval(positionUpdateIntervalRef.current)
      }

      clearInterval(loadingInterval)
      window.removeEventListener("resize", handleResize)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("click", handleMouseClick)
      document.body.style.cursor = "default"
    }
  }, [roomId, userId, onUserMove, zoomLevel])

  // Create an enhanced room with more interactive elements
  const createEnhancedRoom = (scene: THREE.Scene) => {
    // Clear interactive objects
    interactiveObjectsRef.current = []

    // Floor
    const floorGeometry = new THREE.PlaneGeometry(20, 20)
    const floorTexture = new THREE.TextureLoader().load("/placeholder.svg?height=1024&width=1024&text=Floor")
    floorTexture.wrapS = THREE.RepeatWrapping
    floorTexture.wrapT = THREE.RepeatWrapping
    floorTexture.repeat.set(10, 10)

    const floorMaterial = new THREE.MeshStandardMaterial({
      color: 0x333344,
      roughness: 0.8,
      map: floorTexture,
    })
    const floor = new THREE.Mesh(floorGeometry, floorMaterial)
    floor.rotation.x = -Math.PI / 2
    floor.receiveShadow = true
    scene.add(floor)

    // Walls
    const wallMaterial = new THREE.MeshStandardMaterial({
      color: 0x6666aa,
      roughness: 0.7,
    })

    // Back wall
    const backWallGeometry = new THREE.PlaneGeometry(20, 5)
    const backWall = new THREE.Mesh(backWallGeometry, wallMaterial)
    backWall.position.z = -10
    backWall.position.y = 2.5
    scene.add(backWall)

    // Left wall
    const leftWallGeometry = new THREE.PlaneGeometry(20, 5)
    const leftWall = new THREE.Mesh(leftWallGeometry, wallMaterial)
    leftWall.position.x = -10
    leftWall.position.y = 2.5
    leftWall.rotation.y = Math.PI / 2
    scene.add(leftWall)

    // Right wall
    const rightWallGeometry = new THREE.PlaneGeometry(20, 5)
    const rightWall = new THREE.Mesh(rightWallGeometry, wallMaterial)
    rightWall.position.x = 10
    rightWall.position.y = 2.5
    rightWall.rotation.y = -Math.PI / 2
    scene.add(rightWall)

    // Conference table
    const tableGeometry = new THREE.BoxGeometry(6, 0.2, 3)
    const tableMaterial = new THREE.MeshStandardMaterial({
      color: 0x884400,
      roughness: 0.3,
    })
    const table = new THREE.Mesh(tableGeometry, tableMaterial)
    table.position.y = 0.7
    table.castShadow = true
    table.receiveShadow = true
    scene.add(table)

    // Chairs
    const chairPositions = [
      { x: -2, z: -1.5, rotation: 0 },
      { x: 0, z: -1.5, rotation: 0 },
      { x: 2, z: -1.5, rotation: 0 },
      { x: -2, z: 1.5, rotation: Math.PI },
      { x: 0, z: 1.5, rotation: Math.PI },
      { x: 2, z: 1.5, rotation: Math.PI },
    ]

    chairPositions.forEach((pos) => {
      createSimpleChair(scene, pos.x, pos.z, pos.rotation)
    })

    // Add presentation screen
    const screenGeometry = new THREE.PlaneGeometry(4, 2.5)
    const screenMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    })
    const screen = new THREE.Mesh(screenGeometry, screenMaterial)
    screen.position.set(0, 2.5, -9.5)
    screen.userData = { type: "screen", name: "Presentation Screen" }
    scene.add(screen)
    interactiveObjectsRef.current.push(screen)

    // Add screen frame
    const frameGeometry = new THREE.BoxGeometry(4.2, 2.7, 0.1)
    const frameMaterial = new THREE.MeshStandardMaterial({
      color: 0x333333,
      roughness: 0.5,
    })
    const frame = new THREE.Mesh(frameGeometry, frameMaterial)
    frame.position.set(0, 2.5, -9.6)
    scene.add(frame)

    // Add whiteboard
    const whiteboardGeometry = new THREE.PlaneGeometry(3, 2)
    const whiteboardMaterial = new THREE.MeshBasicMaterial({
      color: 0xf5f5f5,
    })
    const whiteboard = new THREE.Mesh(whiteboardGeometry, whiteboardMaterial)
    whiteboard.position.set(-8, 2.5, -5)
    whiteboard.rotation.y = Math.PI / 4
    whiteboard.userData = { type: "whiteboard", name: "Collaborative Whiteboard" }
    scene.add(whiteboard)
    interactiveObjectsRef.current.push(whiteboard)

    // Add document stand
    const standGeometry = new THREE.BoxGeometry(1, 0.5, 1)
    const standMaterial = new THREE.MeshStandardMaterial({
      color: 0x555555,
      roughness: 0.5,
    })
    const stand = new THREE.Mesh(standGeometry, standMaterial)
    stand.position.set(8, 0.25, -5)
    scene.add(stand)

    // Add documents
    const documentGeometry = new THREE.BoxGeometry(0.8, 0.05, 0.6)
    const documentMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.2,
    })
    const document1 = new THREE.Mesh(documentGeometry, documentMaterial)
    document1.position.set(8, 0.55, -5)
    document1.userData = { type: "document", name: "Business Proposal" }
    scene.add(document1)
    interactiveObjectsRef.current.push(document1)

    // Add plants for decoration
    createPlant(scene, -8, 0, 8, 1.5)
    createPlant(scene, 8, 0, 8, 1.2)

    // Add ceiling lights
    for (let x = -6; x <= 6; x += 6) {
      for (let z = -6; z <= 6; z += 6) {
        createCeilingLight(scene, x, z)
      }
    }
  }

  const createSimpleChair = (scene: THREE.Scene, x: number, z: number, rotation: number) => {
    const chairGroup = new THREE.Group()

    // Seat
    const seatGeometry = new THREE.BoxGeometry(0.6, 0.1, 0.6)
    const seatMaterial = new THREE.MeshStandardMaterial({
      color: 0x444444,
      roughness: 0.5,
    })
    const seat = new THREE.Mesh(seatGeometry, seatMaterial)
    seat.position.y = 0.4
    seat.castShadow = true
    chairGroup.add(seat)

    // Back
    const backGeometry = new THREE.BoxGeometry(0.6, 0.6, 0.1)
    const back = new THREE.Mesh(backGeometry, seatMaterial)
    back.position.y = 0.7
    back.position.z = 0.25
    back.castShadow = true
    chairGroup.add(back)

    // Legs
    const legGeometry = new THREE.CylinderGeometry(0.05, 0.05, 0.4)
    const legMaterial = new THREE.MeshStandardMaterial({
      color: 0x888888,
      roughness: 0.2,
    })

    const positions = [
      { x: 0.25, z: 0.25 },
      { x: -0.25, z: 0.25 },
      { x: 0.25, z: -0.25 },
      { x: -0.25, z: -0.25 },
    ]

    positions.forEach((pos) => {
      const leg = new THREE.Mesh(legGeometry, legMaterial)
      leg.position.set(pos.x, 0.2, pos.z)
      leg.castShadow = true
      chairGroup.add(leg)
    })

    chairGroup.position.set(x, 0, z)
    chairGroup.rotation.y = rotation
    scene.add(chairGroup)
  }

  const createPlant = (scene: THREE.Scene, x: number, y: number, z: number, height: number) => {
    const potGeometry = new THREE.CylinderGeometry(0.3, 0.4, 0.4, 16)
    const potMaterial = new THREE.MeshStandardMaterial({
      color: 0x885533,
      roughness: 0.8,
    })
    const pot = new THREE.Mesh(potGeometry, potMaterial)
    pot.position.set(x, y + 0.2, z)
    pot.castShadow = true
    pot.receiveShadow = true
    scene.add(pot)

    const stemGeometry = new THREE.CylinderGeometry(0.02, 0.02, height, 8)
    const stemMaterial = new THREE.MeshStandardMaterial({
      color: 0x228833,
      roughness: 0.8,
    })
    const stem = new THREE.Mesh(stemGeometry, stemMaterial)
    stem.position.set(x, y + height / 2 + 0.4, z)
    stem.castShadow = true
    scene.add(stem)

    const leafGeometry = new THREE.SphereGeometry(0.3, 8, 8)
    const leafMaterial = new THREE.MeshStandardMaterial({
      color: 0x33aa33,
      roughness: 0.8,
    })

    for (let i = 0; i < 5; i++) {
      const leaf = new THREE.Mesh(leafGeometry, leafMaterial)
      const angle = (i / 5) * Math.PI * 2
      const radius = 0.2
      const leafX = x + Math.cos(angle) * radius
      const leafZ = z + Math.sin(angle) * radius
      const leafY = y + height * (0.5 + i * 0.1) + 0.4

      leaf.position.set(leafX, leafY, leafZ)
      leaf.scale.set(0.5, 0.5, 0.5)
      leaf.castShadow = true
      scene.add(leaf)
    }
  }

  const createCeilingLight = (scene: THREE.Scene, x: number, z: number) => {
    const fixtureGeometry = new THREE.CylinderGeometry(0.2, 0.2, 0.1, 16)
    const fixtureMaterial = new THREE.MeshStandardMaterial({
      color: 0xcccccc,
      roughness: 0.5,
    })
    const fixture = new THREE.Mesh(fixtureGeometry, fixtureMaterial)
    fixture.position.set(x, 4.95, z)
    scene.add(fixture)

    const lightGeometry = new THREE.CylinderGeometry(0.15, 0.15, 0.05, 16)
    const lightMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffcc,
      emissive: 0xffffcc,
    })
    const lightMesh = new THREE.Mesh(lightGeometry, lightMaterial)
    lightMesh.position.set(x, 4.9, z)
    scene.add(lightMesh)

    const pointLight = new THREE.PointLight(0xffffcc, 0.5, 10)
    pointLight.position.set(x, 4.8, z)
    scene.add(pointLight)
  }

  // Create a simple avatar
  const createSimpleAvatar = (name: string) => {
    const avatarGroup = new THREE.Group()

    // Head
    const headGeometry = new THREE.SphereGeometry(0.25, 32, 32)
    const headMaterial = new THREE.MeshStandardMaterial({
      color: 0xffaa88,
      roughness: 0.7,
    })
    const head = new THREE.Mesh(headGeometry, headMaterial)
    head.position.y = 1.6
    head.castShadow = true
    avatarGroup.add(head)

    // Body
    const bodyGeometry = new THREE.CylinderGeometry(0.2, 0.15, 0.6, 32)
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: 0x3366cc,
      roughness: 0.8,
    })
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial)
    body.position.y = 1.15
    body.castShadow = true
    avatarGroup.add(body)

    // Name tag
    const canvas = document.createElement("canvas")
    canvas.width = 256
    canvas.height = 64
    const context = canvas.getContext("2d")
    if (context) {
      context.fillStyle = "#333333"
      context.fillRect(0, 0, canvas.width, canvas.height)
      context.fillStyle = "white"
      context.font = "24px Arial"
      context.textAlign = "center"
      context.textBaseline = "middle"
      context.fillText(name, canvas.width / 2, canvas.height / 2)
    }

    const nameTexture = new THREE.CanvasTexture(canvas)
    const nameGeometry = new THREE.PlaneGeometry(0.6, 0.15)
    const nameMaterial = new THREE.MeshBasicMaterial({
      map: nameTexture,
      transparent: true,
    })
    const nameTag = new THREE.Mesh(nameGeometry, nameMaterial)
    nameTag.position.y = 1.9
    nameTag.rotation.x = -Math.PI / 6
    avatarGroup.add(nameTag)

    // Speaking indicator
    const indicatorGeometry = new THREE.SphereGeometry(0.05, 16, 16)
    const indicatorMaterial = new THREE.MeshBasicMaterial({ color: 0x666666 })
    const speakingIndicator = new THREE.Mesh(indicatorGeometry, indicatorMaterial)
    speakingIndicator.position.y = 1.95
    speakingIndicator.userData.isSpeakingIndicator = true
    avatarGroup.add(speakingIndicator)

    return avatarGroup
  }

  // Update user avatars when users change
  useEffect(() => {
    if (!sceneRef.current) return

    // Remove avatars that are no longer present
    const currentUserIds = users.map((user) => user.id)
    avatarModelsRef.current.forEach((model, userId) => {
      if (!currentUserIds.includes(userId)) {
        sceneRef.current?.remove(model)
        avatarModelsRef.current.delete(userId)
      }
    })

    // Update or add avatars for current users
    users.forEach((user) => {
      if (user.id === userId) return // Skip current user (we're using the camera)

      let avatarModel = avatarModelsRef.current.get(user.id)

      if (!avatarModel) {
        // Create a simple avatar representation
        avatarModel = createSimpleAvatar(user.name)
        if (sceneRef.current) {
          sceneRef.current.add(avatarModel)
          avatarModelsRef.current.set(user.id, avatarModel)
        }
      }

      // Update position and rotation
      if (avatarModel) {
        avatarModel.position.set(...user.position)
        avatarModel.rotation.set(...user.rotation)

        // Update speaking indicator
        const speakingIndicator = avatarModel.children.find((child) => child.userData.isSpeakingIndicator)

        if (speakingIndicator) {
          const material = (speakingIndicator as THREE.Mesh).material as THREE.MeshBasicMaterial
          material.color.set(user.speaking ? 0x00ff00 : 0x666666)
        }
      }
    })
  }, [users, userId])

  // Handle zoom in/out
  const handleZoomIn = () => {
    if (controlsRef.current) {
      setZoomLevel((prev) => Math.max(1, prev - 1))
      controlsRef.current.minDistance = Math.max(1, zoomLevel - 1)
    }
  }

  const handleZoomOut = () => {
    if (controlsRef.current) {
      setZoomLevel((prev) => Math.min(10, prev + 1))
      controlsRef.current.maxDistance = Math.min(10, zoomLevel + 1)
    }
  }

  // Handle fullscreen toggle
  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen()
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
    }

    setIsFullscreen(!isFullscreen)
  }

  // Listen for fullscreen change
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)

    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  return (
    <div className="relative w-full h-full">
      <div ref={containerRef} className="w-full h-full" />

      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
          <div className="text-lg font-medium">Loading Conference Room</div>
          <div className="text-sm text-muted-foreground">{loadingProgress}%</div>
        </div>
      )}

      {!isLoading && (
        <>
          {/* Controls overlay */}
          <div className="absolute bottom-4 right-4 flex flex-col space-y-2">
            <Button
              variant="outline"
              size="icon"
              className="bg-background/80 backdrop-blur-sm"
              onClick={handleZoomIn}
              title="Zoom In"
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="bg-background/80 backdrop-blur-sm"
              onClick={handleZoomOut}
              title="Zoom Out"
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="bg-background/80 backdrop-blur-sm"
              onClick={toggleFullscreen}
              title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
            >
              {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
            </Button>
          </div>

          {/* Hover tooltip */}
          {hoveredObject && (
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-background/80 backdrop-blur-sm px-3 py-1 rounded-md text-sm">
              {hoveredObject}
            </div>
          )}
        </>
      )}
    </div>
  )
}

