"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Mic, MicOff, Volume2, VolumeX, Search, User, UserCheck } from "lucide-react"
import type { User as MetaverseUser } from "@/types/metaverse"
import { Slider } from "@/components/ui/slider"

interface VoiceChatWithSearchProps {
  roomId: string
  userId: string
  users: MetaverseUser[]
  onVoiceStatusChange: (isSpeaking: boolean) => void
  onUserSelect: (userId: string) => void
  textToSpeechEnabled: boolean
}

export function VoiceChatWithSearch({
  roomId,
  userId,
  users,
  onVoiceStatusChange,
  onUserSelect,
  textToSpeechEnabled,
}: VoiceChatWithSearchProps) {
  const [isMuted, setIsMuted] = useState(true)
  const [isListening, setIsListening] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [volume, setVolume] = useState(80)
  const [selectedUser, setSelectedUser] = useState<string | null>(null)
  const [voiceSearchActive, setVoiceSearchActive] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [recognition, setRecognition] = useState<any>(null)
  const audioContextRef = useRef<AudioContext | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const animationFrameRef = useRef<number | null>(null)

  // Initialize audio context and speech recognition
  useEffect(() => {
    // Initialize audio context
    if (typeof window !== "undefined" && !audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
    }

    // Initialize speech recognition
    if (typeof window !== "undefined") {
      try {
        // @ts-ignore - SpeechRecognition is not in the TypeScript types yet
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

        if (SpeechRecognition) {
          const recognitionInstance = new SpeechRecognition()
          recognitionInstance.continuous = true
          recognitionInstance.interimResults = true
          recognitionInstance.lang = "en-US"

          recognitionInstance.onresult = (event: any) => {
            let finalTranscript = ""
            let interimTranscript = ""

            for (let i = event.resultIndex; i < event.results.length; i++) {
              const transcript = event.results[i][0].transcript
              if (event.results[i].isFinal) {
                finalTranscript += transcript
              } else {
                interimTranscript += transcript
              }
            }

            setTranscript(finalTranscript || interimTranscript)

            // If we have a final transcript and voice search is active, use it
            if (finalTranscript && voiceSearchActive) {
              setSearchQuery(finalTranscript)
              setVoiceSearchActive(false)
              stopSpeechRecognition()
            }
          }

          recognitionInstance.onend = () => {
            setIsListening(false)
            setVoiceSearchActive(false)
          }

          setRecognition(recognitionInstance)
        }
      } catch (error) {
        console.error("Error initializing speech recognition:", error)
      }
    }

    return () => {
      stopMicrophone()
      stopSpeechRecognition()
    }
  }, [])

  // Start/stop microphone
  const toggleMicrophone = async () => {
    if (isMuted) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
        streamRef.current = stream

        if (audioContextRef.current) {
          const source = audioContextRef.current.createMediaStreamSource(stream)
          const analyser = audioContextRef.current.createAnalyser()
          source.connect(analyser)
          analyserRef.current = analyser

          // Start monitoring audio levels
          startAudioLevelMonitoring()
        }

        setIsMuted(false)
      } catch (error) {
        console.error("Error accessing microphone:", error)
      }
    } else {
      stopMicrophone()
      setIsMuted(true)
    }
  }

  // Stop microphone
  const stopMicrophone = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
      animationFrameRef.current = null
    }

    onVoiceStatusChange(false)
  }

  // Monitor audio levels
  const startAudioLevelMonitoring = () => {
    if (!analyserRef.current) return

    analyserRef.current.fftSize = 256
    const bufferLength = analyserRef.current.frequencyBinCount
    const dataArray = new Uint8Array(bufferLength)

    const checkAudioLevel = () => {
      if (!analyserRef.current) return

      analyserRef.current.getByteFrequencyData(dataArray)

      // Calculate average volume
      let sum = 0
      for (let i = 0; i < bufferLength; i++) {
        sum += dataArray[i]
      }
      const average = sum / bufferLength

      // Determine if speaking based on threshold
      const isSpeaking = average > 20 // Adjust threshold as needed
      onVoiceStatusChange(isSpeaking)

      animationFrameRef.current = requestAnimationFrame(checkAudioLevel)
    }

    checkAudioLevel()
  }

  // Start voice search
  const startVoiceSearch = () => {
    if (!recognition) return

    try {
      setVoiceSearchActive(true)
      setTranscript("")
      recognition.start()
      setIsListening(true)
    } catch (error) {
      console.error("Error starting speech recognition:", error)
    }
  }

  // Stop speech recognition
  const stopSpeechRecognition = () => {
    if (!recognition) return

    try {
      recognition.stop()
    } catch (error) {
      console.error("Error stopping speech recognition:", error)
    }

    setIsListening(false)
  }

  // Handle user selection
  const handleUserSelect = (userId: string) => {
    setSelectedUser(userId === selectedUser ? null : userId)
    onUserSelect(userId)
  }

  // Filter users based on search query
  const filteredUsers = users.filter(
    (user) =>
      user.id !== userId &&
      (user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.country.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  // Speak text using text-to-speech
  const speakText = (text: string) => {
    if (!textToSpeechEnabled || !text) return

    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      // Cancel any ongoing speech
      window.speechSynthesis.cancel()

      const utterance = new SpeechSynthesisUtterance(text)
      utterance.volume = volume / 100
      window.speechSynthesis.speak(utterance)
    }
  }

  return (
    <div className="flex flex-col h-full border rounded-md bg-background/80 backdrop-blur-sm">
      <div className="p-3 border-b flex items-center justify-between">
        <h3 className="font-medium">Voice Chat</h3>
        <div className="flex items-center space-x-2">
          <Button
            variant={isMuted ? "outline" : "default"}
            size="sm"
            onClick={toggleMicrophone}
            className={`${!isMuted ? "bg-primary text-primary-foreground" : ""} glow-button`}
          >
            {isMuted ? <MicOff className="h-4 w-4 mr-2" /> : <Mic className="h-4 w-4 mr-2" />}
            {isMuted ? "Unmute" : "Mute"}
          </Button>
        </div>
      </div>

      <div className="p-3 border-b">
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Input
              placeholder="Search participants..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pr-8"
            />
            <Search className="absolute right-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={startVoiceSearch}
            disabled={isListening}
            className="glow-button"
          >
            <Mic className="h-4 w-4" />
          </Button>
        </div>

        {voiceSearchActive && (
          <div className="mt-2 text-xs flex items-center justify-between">
            <div className="flex items-center">
              <div className="flex space-x-1 mr-2">
                <div className="h-1.5 w-1.5 bg-primary rounded-full animate-pulse"></div>
                <div className="h-1.5 w-1.5 bg-primary rounded-full animate-pulse delay-75"></div>
                <div className="h-1.5 w-1.5 bg-primary rounded-full animate-pulse delay-150"></div>
              </div>
              <span>{transcript || "Listening..."}</span>
            </div>
            <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={stopSpeechRecognition}>
              Cancel
            </Button>
          </div>
        )}
      </div>

      <div className="p-3 border-b">
        <div className="flex items-center justify-between mb-2">
          <div className="text-sm font-medium">Volume</div>
          <div className="flex items-center">
            {volume === 0 ? (
              <VolumeX className="h-4 w-4 text-muted-foreground" />
            ) : (
              <Volume2 className="h-4 w-4 text-primary" />
            )}
          </div>
        </div>
        <Slider value={[volume]} min={0} max={100} step={1} onValueChange={(value) => setVolume(value[0])} />
      </div>

      <ScrollArea className="flex-1 p-3">
        <div className="space-y-3">
          <div className="text-sm font-medium">Participants ({filteredUsers.length})</div>

          {filteredUsers.length === 0 ? (
            <div className="text-sm text-muted-foreground text-center py-4">No participants found</div>
          ) : (
            filteredUsers.map((user) => (
              <div
                key={user.id}
                className={`
                  flex items-center justify-between p-2 rounded-md cursor-pointer
                  ${selectedUser === user.id ? "bg-primary/10 border border-primary/20" : "hover:bg-accent"}
                `}
                onClick={() => handleUserSelect(user.id)}
              >
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden mr-3">
                    <img
                      src={user.avatar.thumbnail || "/placeholder.svg"}
                      alt={user.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-medium text-sm flex items-center">
                      {user.name}
                      {user.speaking && <div className="ml-2 w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>}
                    </div>
                    <div className="text-xs text-muted-foreground">{user.company}</div>
                  </div>
                </div>

                <div className="flex items-center">
                  {selectedUser === user.id ? (
                    <UserCheck className="h-4 w-4 text-primary" />
                  ) : (
                    <User className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>

      <div className="p-3 border-t">
        <div className="flex flex-col space-y-2">
          <Button
            variant="outline"
            size="sm"
            className="w-full glow-button"
            onClick={() => speakText(`You are in ${roomId}. There are ${users.length} participants in this room.`)}
            disabled={!textToSpeechEnabled}
          >
            <Volume2 className="h-4 w-4 mr-2" />
            Announce Room Info
          </Button>

          {selectedUser && (
            <Button
              variant="outline"
              size="sm"
              className="w-full glow-button"
              onClick={() => {
                const user = users.find((u) => u.id === selectedUser)
                if (user) {
                  speakText(`${user.name} from ${user.company}. Role: ${user.role}. Country: ${user.country}.`)
                }
              }}
              disabled={!textToSpeechEnabled}
            >
              <Volume2 className="h-4 w-4 mr-2" />
              Announce User Info
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

