"use client"

import { useEffect, useState, useRef } from "react"
import type { Room } from "@/types/metaverse"

interface WelcomeVoiceMessageProps {
  room: Room | null
  userName: string
  enabled: boolean
}

export function WelcomeVoiceMessage({ room, userName, enabled }: WelcomeVoiceMessageProps) {
  const [hasPlayed, setHasPlayed] = useState(false)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    // Reset played state when room changes
    if (room) {
      setHasPlayed(false)
    }

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [room])

  useEffect(() => {
    if (!room || !enabled || hasPlayed) return

    // Play welcome message after a short delay
    timeoutRef.current = setTimeout(() => {
      playWelcomeMessage()
      setHasPlayed(true)
    }, 1500)

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [room, enabled, hasPlayed])

  const playWelcomeMessage = () => {
    if (!room || !enabled || typeof window === "undefined" || !("speechSynthesis" in window)) return

    // Cancel any ongoing speech
    window.speechSynthesis.cancel()

    const welcomeMessage = `Welcome to ${room.name}, ${userName}. There are currently ${room.currentUsers} participants in this room. Use WASD keys to move around and explore the space.`

    const utterance = new SpeechSynthesisUtterance(welcomeMessage)
    utterance.rate = 0.9
    utterance.pitch = 1.0
    utterance.volume = 1.0

    window.speechSynthesis.speak(utterance)
  }

  // This component doesn't render anything visible
  return null
}

