"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import type { ChatMessage, User } from "@/types/metaverse"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Send, Lock, Globe } from "lucide-react"
import { format } from "date-fns"

interface TextChatProps {
  roomId: string
  userId: string
  userName: string
  users: User[]
  messages: ChatMessage[]
  onSendMessage: (message: string, isPrivate: boolean, recipientId?: string) => void
}

export function TextChat({ roomId, userId, userName, users, messages, onSendMessage }: TextChatProps) {
  const [message, setMessage] = useState("")
  const [isPrivate, setIsPrivate] = useState(false)
  const [recipientId, setRecipientId] = useState<string | undefined>(undefined)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleSendMessage = () => {
    if (message.trim()) {
      onSendMessage(message, isPrivate, recipientId)
      setMessage("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="flex flex-col h-full border rounded-md bg-background/80 backdrop-blur-sm">
      <div className="p-3 border-b flex items-center justify-between">
        <h3 className="font-medium">Chat</h3>
        <div className="flex items-center space-x-2">
          <Select
            value={isPrivate ? recipientId || "" : "public"}
            onValueChange={(value) => {
              if (value === "public") {
                setIsPrivate(false)
                setRecipientId(undefined)
              } else {
                setIsPrivate(true)
                setRecipientId(value)
              }
            }}
          >
            <SelectTrigger className="w-[140px] h-8">
              <SelectValue placeholder="Public" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="public">
                <div className="flex items-center">
                  <Globe className="mr-2 h-4 w-4" />
                  <span>Public</span>
                </div>
              </SelectItem>
              {users
                .filter((user) => user.id !== userId)
                .map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    <div className="flex items-center">
                      <Lock className="mr-2 h-4 w-4" />
                      <span>{user.name}</span>
                    </div>
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <ScrollArea className="flex-1 p-3">
        <div className="space-y-4">
          {messages.map((msg) => {
            const isCurrentUser = msg.userId === userId
            const isVisible = !msg.isPrivate || msg.userId === userId || msg.recipientId === userId

            if (!isVisible) return null

            return (
              <div key={msg.id} className={`flex ${isCurrentUser ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] px-3 py-2 rounded-lg ${
                    isCurrentUser ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  {!isCurrentUser && <div className="font-medium text-xs mb-1">{msg.userName}</div>}
                  <div>{msg.content}</div>
                  <div className="text-xs opacity-70 mt-1 text-right">
                    {format(new Date(msg.timestamp), "HH:mm")}
                    {msg.isPrivate && <Lock className="inline-block ml-1 h-3 w-3" />}
                  </div>
                </div>
              </div>
            )
          })}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <div className="p-3 border-t">
        <div className="flex space-x-2">
          <Input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Message ${isPrivate ? users.find((u) => u.id === recipientId)?.name : "everyone"}...`}
            className="flex-1"
          />
          <Button size="icon" onClick={handleSendMessage}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}

