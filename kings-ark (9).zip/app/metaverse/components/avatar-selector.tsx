"use client"
import type { Avatar } from "@/types/metaverse"
import { Card, CardContent } from "@/components/ui/card"
import { Check } from "lucide-react"

interface AvatarSelectorProps {
  avatars: Avatar[]
  selectedAvatar: Avatar | null
  onSelectAvatar: (avatar: Avatar) => void
}

export function AvatarSelector({ avatars, selectedAvatar, onSelectAvatar }: AvatarSelectorProps) {
  return (
    <div className="w-full">
      <h2 className="text-xl font-bold mb-4">Select Your Avatar</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {avatars.map((avatar) => (
          <Card
            key={avatar.id}
            className={`cursor-pointer transition-all hover:scale-105 ${
              selectedAvatar?.id === avatar.id ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => onSelectAvatar(avatar)}
          >
            <CardContent className="p-3 flex flex-col items-center">
              <div className="relative w-full aspect-square mb-2 bg-muted rounded-md overflow-hidden">
                <img
                  src={avatar.thumbnail || "/placeholder.svg"}
                  alt={avatar.name}
                  className="w-full h-full object-cover"
                />
                {selectedAvatar?.id === avatar.id && (
                  <div className="absolute top-2 right-2 bg-primary rounded-full p-1">
                    <Check className="h-4 w-4 text-primary-foreground" />
                  </div>
                )}
              </div>
              <span className="text-sm font-medium">{avatar.name}</span>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

