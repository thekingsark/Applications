"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader"
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader"
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer"
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass"
import { OutlinePass } from "three/examples/jsm/postprocessing/OutlinePass"
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass"
import { FXAAShader } from "three/examples/jsm/shaders/FXAAShader"
import { WebGLDetector } from "../utils/webgl-detector"
import { WebGLFallback } from "./webgl-fallback"
import type { User } from "@/types/metaverse"

interface ThreeRendererProps {
  users: User[]
  currentUserId: string
  onUserMove: (position: [number, number, number], rotation: [number, number, number]) => void
  onUserSelect: (userId: string) => void
}

export function ThreeRenderer({ users, currentUserId, onUserMove, onUserSelect }: ThreeRendererProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const sceneRef = useRef<THREE.Scene | null>(null)
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null)
  const controlsRef = useRef<OrbitControls | null>(null)
  const composerRef = useRef<EffectComposer | null>(null)
  const outlinePassRef = useRef<OutlinePass | null>(null)
  const avatarModelsRef = useRef<Map<string, THREE.Group>>(new Map())
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster())
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2())
  const [isLoading, setIsLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [webGLError, setWebGLError] = useState<string | null>(null)
  const animationFrameRef = useRef<number | null>(null)
  const keysPressed = useRef<Record<string, boolean>>({})
  const currentUserRef = useRef<User | null>(null)
  const avatarMixersRef = useRef<Map<string, THREE.AnimationMixer>>(new Map())
  const clockRef = useRef<THREE.Clock>(new THREE.Clock())
  const isInitializedRef = useRef<boolean>(false)
  const errorCountRef = useRef<number>(0)
  const maxErrorCount = 3

  // Check WebGL compatibility
  useEffect(() => {
    if (!WebGLDetector.isWebGLAvailable()) {
      setWebGLError(WebGLDetector.getWebGLErrorMessage())
      return
    }

    if (!WebGLDetector.isWebGL2Available()) {
      console.warn(WebGLDetector.getWebGL2ErrorMessage())
      // Continue with WebGL 1
    }
  }, [])

  // Initialize Three.js scene
  const initThreeJS = useCallback(() => {
    if (!containerRef.current || isInitializedRef.current || webGLError) return

    try {
      // Create scene
      const scene = new THREE.Scene()
      scene.background = new THREE.Color(0x1a1a2e)
      scene.fog = new THREE.FogExp2(0x1a1a2e, 0.05)
      sceneRef.current = scene

      // Create camera
      const camera = new THREE.PerspectiveCamera(
        75,
        containerRef.current.clientWidth / containerRef.current.clientHeight,
        0.1,
        1000,
      )
      camera.position.set(0, 1.6, 5)
      cameraRef.current = camera

      // Create renderer with error handling
      try {
        const renderer = new THREE.WebGLRenderer({
          antialias: true,
          alpha: true,
          powerPreference: "high-performance",
          canvas: document.createElement("canvas"),
          preserveDrawingBuffer: true,
          stencil: true,
        })

        renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)) // Limit pixel ratio for performance
        renderer.shadowMap.enabled = true
        renderer.shadowMap.type = THREE.PCFSoftShadowMap
        renderer.outputEncoding = THREE.sRGBEncoding
        renderer.toneMapping = THREE.ACESFilmicToneMapping
        renderer.toneMappingExposure = 1.2

        // Add canvas to container
        containerRef.current.appendChild(renderer.domElement)
        rendererRef.current = renderer

        // Set up post-processing
        const composer = new EffectComposer(renderer)
        const renderPass = new RenderPass(scene, camera)
        composer.addPass(renderPass)

        // Add outline pass for highlighting selected objects
        const outlinePass = new OutlinePass(
          new THREE.Vector2(containerRef.current.clientWidth, containerRef.current.clientHeight),
          scene,
          camera,
        )
        outlinePass.edgeStrength = 3
        outlinePass.edgeGlow = 0.5
        outlinePass.edgeThickness = 1
        outlinePass.pulsePeriod = 2
        outlinePass.visibleEdgeColor.set(0x3399ff)
        outlinePass.hiddenEdgeColor.set(0x3399ff)
        composer.addPass(outlinePass)
        outlinePassRef.current = outlinePass

        // Add anti-aliasing pass
        const fxaaPass = new ShaderPass(FXAAShader)
        fxaaPass.material.uniforms["resolution"].value.set(
          1 / (containerRef.current.clientWidth * renderer.getPixelRatio()),
          1 / (containerRef.current.clientHeight * renderer.getPixelRatio()),
        )
        composer.addPass(fxaaPass)

        composerRef.current = composer
      } catch (e) {
        console.error("Error creating WebGL renderer:", e)
        setWebGLError("Failed to initialize 3D renderer. Please check your browser's WebGL support.")
        return
      }

      // Add controls
      const controls = new OrbitControls(camera, rendererRef.current.domElement)
      controls.enableDamping = true
      controls.dampingFactor = 0.05
      controls.minDistance = 1
      controls.maxDistance = 10
      controls.maxPolarAngle = Math.PI / 2
      controls.target.set(0, 1, 0)
      controlsRef.current = controls

      // Add lights
      const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
      scene.add(ambientLight)

      const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
      directionalLight.position.set(5, 10, 7.5)
      directionalLight.castShadow = true
      directionalLight.shadow.mapSize.width = 2048
      directionalLight.shadow.mapSize.height = 2048
      directionalLight.shadow.camera.near = 0.5
      directionalLight.shadow.camera.far = 50
      directionalLight.shadow.bias = -0.0001
      scene.add(directionalLight)

      // Add point lights for better ambiance
      const pointLight1 = new THREE.PointLight(0x3366ff, 0.5, 10)
      pointLight1.position.set(3, 3, 3)
      pointLight1.castShadow = true
      scene.add(pointLight1)

      const pointLight2 = new THREE.PointLight(0xff6633, 0.5, 10)
      pointLight2.position.set(-3, 3, -3)
      pointLight2.castShadow = true
      scene.add(pointLight2)

      // Create environment
      createEnvironment(scene)

      // Set up event listeners
      setupEventListeners()

      // Start animation loop
      clockRef.current.start()
      animate()

      // Load avatar models
      loadAvatarModels()

      isInitializedRef.current = true
    } catch (e) {
      console.error("Error initializing Three.js:", e)
      errorCountRef.current++

      if (errorCountRef.current >= maxErrorCount) {
        setWebGLError("Failed to initialize 3D environment after multiple attempts. Please try a different browser.")
      } else {
        // Clean up and try again
        cleanupThreeJS()
        setTimeout(initThreeJS, 1000)
      }
    }
  }, [webGLError])

  // Set up event listeners
  const setupEventListeners = useCallback(() => {
    if (!containerRef.current || !rendererRef.current) return

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current || !composerRef.current) return

      const width = containerRef.current.clientWidth
      const height = containerRef.current.clientHeight

      cameraRef.current.aspect = width / height
      cameraRef.current.updateProjectionMatrix()

      rendererRef.current.setSize(width, height)
      composerRef.current.setSize(width, height)

      // Update FXAA pass
      const pixelRatio = rendererRef.current.getPixelRatio()
      const fxaaPass = composerRef.current.passes[2] as ShaderPass
      if (fxaaPass && fxaaPass.material.uniforms["resolution"]) {
        fxaaPass.material.uniforms["resolution"].value.set(1 / (width * pixelRatio), 1 / (height * pixelRatio))
      }
    }

    // Handle mouse events for raycasting
    const handleMouseMove = (event: MouseEvent) => {
      if (!containerRef.current) return

      const rect = containerRef.current.getBoundingClientRect()
      mouseRef.current.x = ((event.clientX - rect.left) / containerRef.current.clientWidth) * 2 - 1
      mouseRef.current.y = -((event.clientY - rect.top) / containerRef.current.clientHeight) * 2 + 1
    }

    const handleMouseClick = (event: MouseEvent) => {
      if (!sceneRef.current || !cameraRef.current || !outlinePassRef.current) return

      raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current)

      // Check for intersections with avatar models
      const avatarObjects: THREE.Object3D[] = []
      avatarModelsRef.current.forEach((model) => {
        avatarObjects.push(model)
      })

      const intersects = raycasterRef.current.intersectObjects(avatarObjects, true)

      if (intersects.length > 0) {
        // Find the user ID associated with the clicked model
        let selectedUserId: string | null = null
        let selectedObject: THREE.Object3D | null = null

        avatarModelsRef.current.forEach((model, userId) => {
          if (intersects[0].object === model || model.children.includes(intersects[0].object as THREE.Object3D)) {
            selectedUserId = userId
            selectedObject = model
          }
        })

        if (selectedUserId && selectedObject) {
          // Highlight selected avatar
          outlinePassRef.current.selectedObjects = [selectedObject]

          // Notify parent component
          onUserSelect(selectedUserId)

          // Clear highlight after a delay
          setTimeout(() => {
            if (outlinePassRef.current) {
              outlinePassRef.current.selectedObjects = []
            }
          }, 2000)
        }
      }
    }

    // Handle keyboard controls
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = true
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = false
    }

    // Handle WebGL context loss
    const handleContextLost = (e: Event) => {
      e.preventDefault()
      console.warn("WebGL context lost. Trying to restore...")

      // Stop animation loop
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current)
        animationFrameRef.current = null
      }

      // Try to restore after a delay
      setTimeout(() => {
        if (rendererRef.current) {
          try {
            // Attempt to restore context
            const gl = rendererRef.current.getContext()
            if (gl && "getContextAttributes" in gl) {
              console.log("WebGL context restored successfully")

              // Restart animation loop
              animate()
            } else {
              // Context couldn't be restored
              errorCountRef.current++
              if (errorCountRef.current >= maxErrorCount) {
                setWebGLError("WebGL context lost and couldn't be restored. Please refresh the page.")
              } else {
                // Try to reinitialize
                cleanupThreeJS()
                isInitializedRef.current = false
                initThreeJS()
              }
            }
          } catch (err) {
            console.error("Error restoring WebGL context:", err)
            setWebGLError("Failed to restore 3D environment. Please refresh the page.")
          }
        }
      }, 1000)
    }

    // Handle WebGL context restored
    const handleContextRestored = () => {
      console.log("WebGL context restored")

      // Restart animation loop if it's not running
      if (!animationFrameRef.current) {
        animate()
      }
    }

    // Add event listeners
    window.addEventListener("resize", handleResize)
    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("click", handleMouseClick)
    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    // Add WebGL context event listeners
    const canvas = rendererRef.current.domElement
    canvas.addEventListener("webglcontextlost", handleContextLost)
    canvas.addEventListener("webglcontextrestored", handleContextRestored)

    // Return cleanup function
    return () => {
      window.removeEventListener("resize", handleResize)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("click", handleMouseClick)
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)

      canvas.removeEventListener("webglcontextlost", handleContextLost)
      canvas.removeEventListener("webglcontextrestored", handleContextRestored)
    }
  }, [initThreeJS, onUserSelect])

  // Animation loop
  const animate = useCallback(() => {
    if (!controlsRef.current || !rendererRef.current || !sceneRef.current || !cameraRef.current || !composerRef.current)
      return

    try {
      const delta = clockRef.current.getDelta()

      // Update animation mixers
      avatarMixersRef.current.forEach((mixer) => {
        mixer.update(delta)
      })

      // Update controls
      controlsRef.current.update()

      // Handle user movement with keyboard
      handleUserMovement()

      // Render scene with post-processing
      composerRef.current.render()

      // Schedule next frame
      animationFrameRef.current = requestAnimationFrame(animate)
    } catch (e) {
      console.error("Error in animation loop:", e)

      // Increment error count
      errorCountRef.current++

      if (errorCountRef.current >= maxErrorCount) {
        // Too many errors, show fallback
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current)
          animationFrameRef.current = null
        }

        setWebGLError(
          "The 3D environment encountered too many errors. Please refresh the page or try a different browser.",
        )
      } else {
        // Try to continue
        animationFrameRef.current = requestAnimationFrame(animate)
      }
    }
  }, [])

  // Handle user movement with keyboard
  const handleUserMovement = useCallback(() => {
    if (!currentUserRef.current || !cameraRef.current) return

    const moveSpeed = 0.05
    const rotateSpeed = 0.03

    let moved = false
    const newPosition: [number, number, number] = [...currentUserRef.current.position]
    const newRotation: [number, number, number] = [...currentUserRef.current.rotation]

    // Forward/backward movement
    if (keysPressed.current["w"] || keysPressed.current["arrowup"]) {
      newPosition[0] += Math.sin(newRotation[1]) * moveSpeed
      newPosition[2] += Math.cos(newRotation[1]) * moveSpeed
      moved = true
    }

    if (keysPressed.current["s"] || keysPressed.current["arrowdown"]) {
      newPosition[0] -= Math.sin(newRotation[1]) * moveSpeed
      newPosition[2] -= Math.cos(newRotation[1]) * moveSpeed
      moved = true
    }

    // Left/right movement
    if (keysPressed.current["a"] || keysPressed.current["arrowleft"]) {
      newPosition[0] -= Math.cos(newRotation[1]) * moveSpeed
      newPosition[2] += Math.sin(newRotation[1]) * moveSpeed
      moved = true
    }

    if (keysPressed.current["d"] || keysPressed.current["arrowright"]) {
      newPosition[0] += Math.cos(newRotation[1]) * moveSpeed
      newPosition[2] -= Math.sin(newRotation[1]) * moveSpeed
      moved = true
    }

    // Rotation
    if (keysPressed.current["q"]) {
      newRotation[1] -= rotateSpeed
      moved = true
    }

    if (keysPressed.current["e"]) {
      newRotation[1] += rotateSpeed
      moved = true
    }

    // Apply movement if changed
    if (moved) {
      // Boundary checks
      newPosition[0] = Math.max(-10, Math.min(10, newPosition[0]))
      newPosition[2] = Math.max(-10, Math.min(10, newPosition[2]))

      onUserMove(newPosition, newRotation)

      // Update camera position to follow user
      if (currentUserRef.current.id === currentUserId && controlsRef.current) {
        const avatarModel = avatarModelsRef.current.get(currentUserId)
        if (avatarModel) {
          controlsRef.current.target.set(avatarModel.position.x, avatarModel.position.y + 1, avatarModel.position.z)
        }
      }
    }
  }, [currentUserId, onUserMove])

  // Create environment (room, furniture, etc.)
  const createEnvironment = useCallback((scene: THREE.Scene) => {
    try {
      // Floor
      const floorGeometry = new THREE.PlaneGeometry(30, 30, 30, 30)
      const floorTexture = new THREE.TextureLoader().load("/placeholder.svg?height=512&width=512&text=Floor")
      floorTexture.wrapS = THREE.RepeatWrapping
      floorTexture.wrapT = THREE.RepeatWrapping
      floorTexture.repeat.set(10, 10)

      const floorMaterial = new THREE.MeshStandardMaterial({
        color: 0x333344,
        roughness: 0.8,
        metalness: 0.2,
        map: floorTexture,
      })

      const floor = new THREE.Mesh(floorGeometry, floorMaterial)
      floor.rotation.x = -Math.PI / 2
      floor.receiveShadow = true
      scene.add(floor)

      // Walls
      const wallTexture = new THREE.TextureLoader().load("/placeholder.svg?height=512&width=512&text=Wall")
      wallTexture.wrapS = THREE.RepeatWrapping
      wallTexture.wrapT = THREE.RepeatWrapping
      wallTexture.repeat.set(5, 2)

      const wallMaterial = new THREE.MeshStandardMaterial({
        color: 0x6666aa,
        roughness: 0.7,
        metalness: 0.1,
        map: wallTexture,
      })

      // Back wall
      const backWallGeometry = new THREE.BoxGeometry(30, 10, 0.5)
      const backWall = new THREE.Mesh(backWallGeometry, wallMaterial)
      backWall.position.set(0, 5, -15)
      backWall.receiveShadow = true
      scene.add(backWall)

      // Front wall with entrance
      const frontWallLeft = new THREE.Mesh(new THREE.BoxGeometry(12, 10, 0.5), wallMaterial)
      frontWallLeft.position.set(-9, 5, 15)
      frontWallLeft.receiveShadow = true
      scene.add(frontWallLeft)

      const frontWallRight = new THREE.Mesh(new THREE.BoxGeometry(12, 10, 0.5), wallMaterial)
      frontWallRight.position.set(9, 5, 15)
      frontWallRight.receiveShadow = true
      scene.add(frontWallRight)

      const doorFrame = new THREE.Mesh(
        new THREE.BoxGeometry(6, 2, 0.5),
        new THREE.MeshStandardMaterial({ color: 0x8888cc }),
      )
      doorFrame.position.set(0, 9, 15)
      doorFrame.receiveShadow = true
      scene.add(doorFrame)

      // Left wall
      const leftWallGeometry = new THREE.BoxGeometry(0.5, 10, 30)
      const leftWall = new THREE.Mesh(leftWallGeometry, wallMaterial)
      leftWall.position.set(-15, 5, 0)
      leftWall.receiveShadow = true
      scene.add(leftWall)

      // Right wall
      const rightWallGeometry = new THREE.BoxGeometry(0.5, 10, 30)
      const rightWall = new THREE.Mesh(rightWallGeometry, wallMaterial)
      rightWall.position.set(15, 5, 0)
      rightWall.receiveShadow = true
      scene.add(rightWall)

      // Ceiling
      const ceilingGeometry = new THREE.PlaneGeometry(30, 30)
      const ceilingMaterial = new THREE.MeshStandardMaterial({
        color: 0x444455,
        roughness: 0.9,
        metalness: 0.1,
      })
      const ceiling = new THREE.Mesh(ceilingGeometry, ceilingMaterial)
      ceiling.rotation.x = Math.PI / 2
      ceiling.position.set(0, 10, 0)
      ceiling.receiveShadow = true
      scene.add(ceiling)

      // Conference table
      const tableGeometry = new THREE.CylinderGeometry(5, 5, 0.5, 32)
      const tableTexture = new THREE.TextureLoader().load("/placeholder.svg?height=512&width=512&text=Table")
      tableTexture.wrapS = THREE.RepeatWrapping
      tableTexture.wrapT = THREE.RepeatWrapping
      tableTexture.repeat.set(2, 2)

      const tableMaterial = new THREE.MeshStandardMaterial({
        color: 0x885533,
        roughness: 0.3,
        metalness: 0.2,
        map: tableTexture,
      })

      const table = new THREE.Mesh(tableGeometry, tableMaterial)
      table.position.set(0, 0.75, 0)
      table.castShadow = true
      table.receiveShadow = true
      scene.add(table)

      // Table legs
      const legGeometry = new THREE.CylinderGeometry(0.2, 0.2, 1.5, 16)
      const legMaterial = new THREE.MeshStandardMaterial({
        color: 0x553311,
        roughness: 0.5,
        metalness: 0.3,
      })

      for (let i = 0; i < 4; i++) {
        const angle = (i / 4) * Math.PI * 2
        const leg = new THREE.Mesh(legGeometry, legMaterial)
        leg.position.set(Math.sin(angle) * 4, 0, Math.cos(angle) * 4)
        leg.castShadow = true
        table.add(leg)
      }

      // Chairs
      const chairPositions = []
      for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * Math.PI * 2
        chairPositions.push({
          x: Math.sin(angle) * 7,
          z: Math.cos(angle) * 7,
          rotation: angle + Math.PI,
        })
      }

      chairPositions.forEach((pos) => {
        createChair(scene, pos.x, pos.z, pos.rotation)
      })

      // Presentation screen
      const screenGeometry = new THREE.BoxGeometry(10, 6, 0.2)
      const screenTexture = new THREE.TextureLoader().load(
        "/placeholder.svg?height=512&width=512&text=Kings+Ark+Presentation",
      )

      const screenMaterial = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        roughness: 0.2,
        metalness: 0.1,
        emissive: 0x333333,
        map: screenTexture,
      })

      const screen = new THREE.Mesh(screenGeometry, screenMaterial)
      screen.position.set(0, 5, -14.5)
      screen.castShadow = true
      scene.add(screen)

      // Screen frame
      const frameGeometry = new THREE.BoxGeometry(10.5, 6.5, 0.1)
      const frameMaterial = new THREE.MeshStandardMaterial({
        color: 0x333333,
        roughness: 0.5,
        metalness: 0.5,
      })
      const frame = new THREE.Mesh(frameGeometry, frameMaterial)
      frame.position.set(0, 5, -14.7)
      frame.castShadow = true
      scene.add(frame)

      // Add decorative plants
      createPlant(scene, -12, 0, -12, 3)
      createPlant(scene, 12, 0, -12, 2.5)
      createPlant(scene, -12, 0, 12, 2)
      createPlant(scene, 12, 0, 12, 3.5)

      // Add ceiling lights
      for (let x = -10; x <= 10; x += 10) {
        for (let z = -10; z <= 10; z += 10) {
          createCeilingLight(scene, x, z)
        }
      }
    } catch (e) {
      console.error("Error creating environment:", e)
      // Continue without environment if there's an error
    }
  }, [])

  // Create a chair
  const createChair = useCallback((scene: THREE.Scene, x: number, z: number, rotation: number) => {
    try {
      const chairGroup = new THREE.Group()
      chairGroup.position.set(x, 0, z)
      chairGroup.rotation.y = rotation

      // Seat
      const seatGeometry = new THREE.BoxGeometry(1.2, 0.1, 1.2)
      const seatMaterial = new THREE.MeshStandardMaterial({
        color: 0x444444,
        roughness: 0.5,
        metalness: 0.2,
      })
      const seat = new THREE.Mesh(seatGeometry, seatMaterial)
      seat.position.y = 0.5
      seat.castShadow = true
      chairGroup.add(seat)

      // Back
      const backGeometry = new THREE.BoxGeometry(1.2, 1.2, 0.1)
      const back = new THREE.Mesh(backGeometry, seatMaterial)
      back.position.set(0, 1.1, -0.6)
      back.castShadow = true
      chairGroup.add(back)

      // Legs
      const legGeometry = new THREE.CylinderGeometry(0.05, 0.05, 0.5, 8)
      const legMaterial = new THREE.MeshStandardMaterial({
        color: 0x888888,
        roughness: 0.2,
        metalness: 0.8,
      })

      const legPositions = [
        { x: 0.5, z: 0.5 },
        { x: -0.5, z: 0.5 },
        { x: 0.5, z: -0.5 },
        { x: -0.5, z: -0.5 },
      ]

      legPositions.forEach((pos) => {
        const leg = new THREE.Mesh(legGeometry, legMaterial)
        leg.position.set(pos.x, 0.25, pos.z)
        leg.castShadow = true
        chairGroup.add(leg)
      })

      scene.add(chairGroup)
      return chairGroup
    } catch (e) {
      console.error("Error creating chair:", e)
      return new THREE.Group() // Return empty group on error
    }
  }, [])

  // Create a decorative plant
  const createPlant = useCallback((scene: THREE.Scene, x: number, y: number, z: number, height: number) => {
    try {
      const plantGroup = new THREE.Group()
      plantGroup.position.set(x, y, z)

      // Pot
      const potGeometry = new THREE.CylinderGeometry(0.6, 0.8, 1, 16)
      const potMaterial = new THREE.MeshStandardMaterial({
        color: 0x885533,
        roughness: 0.8,
        metalness: 0.1,
      })
      const pot = new THREE.Mesh(potGeometry, potMaterial)
      pot.position.y = 0.5
      pot.castShadow = true
      pot.receiveShadow = true
      plantGroup.add(pot)

      // Stem
      const stemGeometry = new THREE.CylinderGeometry(0.05, 0.05, height, 8)
      const stemMaterial = new THREE.MeshStandardMaterial({
        color: 0x228833,
        roughness: 0.8,
        metalness: 0.1,
      })
      const stem = new THREE.Mesh(stemGeometry, stemMaterial)
      stem.position.y = 1 + height / 2
      stem.castShadow = true
      plantGroup.add(stem)

      // Leaves
      const leafGeometry = new THREE.SphereGeometry(0.6, 8, 8)
      const leafMaterial = new THREE.MeshStandardMaterial({
        color: 0x33aa33,
        roughness: 0.8,
        metalness: 0.1,
      })

      for (let i = 0; i < 5; i++) {
        const leaf = new THREE.Mesh(leafGeometry, leafMaterial)
        const angle = (i / 5) * Math.PI * 2
        const radius = 0.3
        const leafX = Math.cos(angle) * radius
        const leafZ = Math.sin(angle) * radius
        const leafY = 1 + height * (0.5 + i * 0.1)

        leaf.position.set(leafX, leafY, leafZ)
        leaf.scale.set(0.5, 0.5, 0.5)
        leaf.castShadow = true
        plantGroup.add(leaf)
      }

      scene.add(plantGroup)
    } catch (e) {
      console.error("Error creating plant:", e)
    }
  }, [])

  // Create a ceiling light
  const createCeilingLight = useCallback((scene: THREE.Scene, x: number, z: number) => {
    try {
      const lightGroup = new THREE.Group()
      lightGroup.position.set(x, 9.9, z)

      // Fixture
      const fixtureGeometry = new THREE.CylinderGeometry(0.5, 0.5, 0.2, 16)
      const fixtureMaterial = new THREE.MeshStandardMaterial({
        color: 0xcccccc,
        roughness: 0.5,
        metalness: 0.5,
      })
      const fixture = new THREE.Mesh(fixtureGeometry, fixtureMaterial)
      fixture.castShadow = true
      lightGroup.add(fixture)

      // Light bulb
      const bulbGeometry = new THREE.SphereGeometry(0.3, 16, 16)
      const bulbMaterial = new THREE.MeshBasicMaterial({
        color: 0xffffee,
        emissive: 0xffffee,
      })
      const bulb = new THREE.Mesh(bulbGeometry, bulbMaterial)
      bulb.position.y = -0.2
      lightGroup.add(bulb)

      // Add point light
      const light = new THREE.PointLight(0xffffee, 0.8, 15)
      light.position.y = -0.2
      light.castShadow = true
      light.shadow.mapSize.width = 512
      light.shadow.mapSize.height = 512
      lightGroup.add(light)

      scene.add(lightGroup)
    } catch (e) {
      console.error("Error creating ceiling light:", e)
    }
  }, [])

  // Load avatar models
  const loadAvatarModels = useCallback(() => {
    try {
      // Set up progress tracking
      const totalModels = users.length
      let loadedModels = 0

      const updateProgress = () => {
        loadedModels++
        const progress = Math.floor((loadedModels / totalModels) * 100)
        setLoadingProgress(progress)

        if (loadedModels === totalModels) {
          setIsLoading(false)
        }
      }

      // Set up DRACO loader for compressed models
      const dracoLoader = new DRACOLoader()
      dracoLoader.setDecoderPath("https://www.gstatic.com/draco/versioned/decoders/1.5.5/")

      // Set up GLTF loader
      const gltfLoader = new GLTFLoader()
      gltfLoader.setDRACOLoader(dracoLoader)

      // Create placeholder avatars for all users
      users.forEach((user) => {
        if (!sceneRef.current) {
          updateProgress()
          return
        }

        // Skip if avatar already exists
        if (avatarModelsRef.current.has(user.id)) {
          updateProgress()
          return
        }

        // Try to load GLTF model if available
        const avatarType = user.avatar?.model || "default"
        const modelUrl = `/models/${avatarType}.glb`

        // First try to load a GLTF model
        fetch(modelUrl, { method: "HEAD" })
          .then((response) => {
            if (response.ok) {
              // Model exists, load it
              gltfLoader.load(
                modelUrl,
                (gltf) => {
                  const model = gltf.scene
                  model.position.set(user.position[0], user.position[1], user.position[2])
                  model.rotation.set(user.rotation[0], user.rotation[1], user.rotation[2])
                  model.castShadow = true
                  model.traverse((object) => {
                    if (object instanceof THREE.Mesh) {
                      object.castShadow = true
                    }
                  })

                  sceneRef.current?.add(model)
                  avatarModelsRef.current.set(user.id, model)

                  // Create animation mixer
                  if (gltf.animations.length > 0) {
                    const mixer = new THREE.AnimationMixer(model)
                    const idleAction = mixer.clipAction(gltf.animations[0])
                    idleAction.play()
                    avatarMixersRef.current.set(user.id, mixer)
                  }

                  // Add name tag
                  addNameTag(model, user.name)

                  updateProgress()
                },
                (xhr) => {
                  // Progress
                  const individualProgress = Math.floor((xhr.loaded / xhr.total) * 100) / users.length
                  setLoadingProgress((prev) => Math.min(prev + individualProgress, 99))
                },
                (error) => {
                  console.error(`Error loading model for ${user.name}:`, error)
                  createFallbackAvatar(user)
                  updateProgress()
                },
              )
            } else {
              // Model doesn't exist, create fallback
              createFallbackAvatar(user)
              updateProgress()
            }
          })
          .catch((error) => {
            console.error("Error checking model availability:", error)
            createFallbackAvatar(user)
            updateProgress()
          })
      })
    } catch (e) {
      console.error("Error loading avatar models:", e)
      setIsLoading(false)
    }
  }, [users])

  // Create a fallback avatar when GLTF model is not available
  const createFallbackAvatar = useCallback((user: User) => {
    if (!sceneRef.current) return

    // Create a simple avatar representation
    const avatarGroup = new THREE.Group()

    // Body
    const bodyGeometry = new THREE.CylinderGeometry(0.25, 0.25, 1, 16)
    const bodyMaterial = new THREE.MeshStandardMaterial({
      color: 0x3366cc,
      roughness: 0.7,
      metalness: 0.2,
    })
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial)
    body.position.y = 0.5
    body.castShadow = true
    avatarGroup.add(body)

    // Head
    const headGeometry = new THREE.SphereGeometry(0.25, 32, 32)
    const headMaterial = new THREE.MeshStandardMaterial({
      color: 0xffaa88,
      roughness: 0.7,
      metalness: 0.1,
    })
    const head = new THREE.Mesh(headGeometry, headMaterial)
    head.position.y = 1.25
    head.castShadow = true
    avatarGroup.add(head)

    // Add name tag
    addNameTag(avatarGroup, user.name)

    // Speaking indicator
    const indicatorGeometry = new THREE.SphereGeometry(0.05, 16, 16)
    const indicatorMaterial = new THREE.MeshBasicMaterial({
      color: user.speaking ? 0x00ff00 : 0x666666,
    })
    const speakingIndicator = new THREE.Mesh(indicatorGeometry, indicatorMaterial)
    speakingIndicator.position.y = 1.8
    speakingIndicator.userData.isSpeakingIndicator = true
    avatarGroup.add(speakingIndicator)

    // Position the avatar
    avatarGroup.position.set(user.position[0], user.position[1], user.position[2])
    avatarGroup.rotation.set(user.rotation[0], user.rotation[1], user.rotation[2])

    // Add to scene and store reference
    sceneRef.current.add(avatarGroup)
    avatarModelsRef.current.set(user.id, avatarGroup)

    // Create a simple animation mixer
    const mixer = new THREE.AnimationMixer(avatarGroup)
    avatarMixersRef.current.set(user.id, mixer)
  }, [])

  // Add a name tag above an avatar
  const addNameTag = useCallback((model: THREE.Object3D, name: string) => {
    try {
      // Create canvas for name tag
      const canvas = document.createElement("canvas")
      canvas.width = 256
      canvas.height = 64
      const context = canvas.getContext("2d")

      if (context) {
        context.fillStyle = "#333333"
        context.fillRect(0, 0, canvas.width, canvas.height)
        context.fillStyle = "white"
        context.font = "24px Arial"
        context.textAlign = "center"
        context.textBaseline = "middle"
        context.fillText(name, canvas.width / 2, canvas.height / 2)
      }

      const nameTexture = new THREE.CanvasTexture(canvas)
      const nameGeometry = new THREE.PlaneGeometry(1, 0.25)
      const nameMaterial = new THREE.MeshBasicMaterial({
        map: nameTexture,
        transparent: true,
        side: THREE.DoubleSide,
      })

      const nameTag = new THREE.Mesh(nameGeometry, nameMaterial)
      nameTag.position.y = 1.7
      nameTag.rotation.x = -Math.PI / 6
      model.add(nameTag)
    } catch (e) {
      console.error("Error adding name tag:", e)
    }
  }, [])

  // Clean up Three.js resources
  const cleanupThreeJS = useCallback(() => {
    // Stop animation loop
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
      animationFrameRef.current = null
    }

    // Dispose of Three.js resources
    avatarModelsRef.current.forEach((model) => {
      model.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          if (object.geometry) object.geometry.dispose()
          if (object.material) {
            if (Array.isArray(object.material)) {
              object.material.forEach((material) => material.dispose())
            } else {
              object.material.dispose()
            }
          }
        }
      })
    })

    // Clear references
    avatarModelsRef.current.clear()
    avatarMixersRef.current.clear()

    // Dispose of renderer
    if (rendererRef.current && containerRef.current) {
      containerRef.current.removeChild(rendererRef.current.domElement)
      rendererRef.current.dispose()
      rendererRef.current = null
    }

    // Clear scene
    if (sceneRef.current) {
      while (sceneRef.current.children.length > 0) {
        const object = sceneRef.current.children[0]
        sceneRef.current.remove(object)
      }
      sceneRef.current = null
    }

    // Clear other references
    cameraRef.current = null
    controlsRef.current = null
    composerRef.current = null
    outlinePassRef.current = null
  }, [])

  // Initialize Three.js on mount
  useEffect(() => {
    initThreeJS()

    return () => {
      cleanupThreeJS()
    }
  }, [initThreeJS, cleanupThreeJS])

  // Update current user reference
  useEffect(() => {
    currentUserRef.current = users.find((user) => user.id === currentUserId) || null
  }, [users, currentUserId])

  // Update user avatars when users change
  useEffect(() => {
    if (!sceneRef.current) return

    // Update positions of existing avatars
    users.forEach((user) => {
      const avatarModel = avatarModelsRef.current.get(user.id)

      if (avatarModel) {
        // Update position and rotation
        avatarModel.position.set(user.position[0], user.position[1], user.position[2])
        avatarModel.rotation.set(user.rotation[0], user.rotation[1], user.rotation[2])

        // Update speaking indicator
        avatarModel.traverse((object) => {
          if (object.userData && object.userData.isSpeakingIndicator) {
            ;(object as THREE.Mesh).material = new THREE.MeshBasicMaterial({
              color: user.speaking ? 0x00ff00 : 0x666666,
            })
          }
        })
      }
    })

    // Check for users that need to be added
    const existingUserIds = new Set(Array.from(avatarModelsRef.current.keys()))
    const currentUserIds = new Set(users.map((user) => user.id))

    // Find users to add
    users.forEach((user) => {
      if (!existingUserIds.has(user.id)) {
        // New user, create avatar
        createFallbackAvatar(user)
      }
    })

    // Find users to remove
    existingUserIds.forEach((userId) => {
      if (!currentUserIds.has(userId)) {
        // User left, remove avatar
        const model = avatarModelsRef.current.get(userId)
        if (model && sceneRef.current) {
          sceneRef.current.remove(model)
          avatarModelsRef.current.delete(userId)

          // Remove mixer
          avatarMixersRef.current.delete(userId)
        }
      }
    })
  }, [users, createFallbackAvatar])

  // Handle retry
  const handleRetry = useCallback(() => {
    setWebGLError(null)
    errorCountRef.current = 0
    isInitializedRef.current = false
    cleanupThreeJS()
    initThreeJS()
  }, [cleanupThreeJS, initThreeJS])

  // If WebGL error, show fallback
  if (webGLError) {
    return <WebGLFallback errorMessage={webGLError} onRetry={handleRetry} />
  }

  return (
    <div className="relative w-full h-full">
      <div ref={containerRef} className="w-full h-full" />

      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="h-8 w-8 animate-spin">
            <div className="h-full w-full rounded-full border-4 border-primary border-t-transparent"></div>
          </div>
          <div className="mt-4 text-lg font-medium">Loading 3D Environment</div>
          <div className="mt-2 w-64 h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300 ease-out"
              style={{ width: `${loadingProgress}%` }}
            ></div>
          </div>
          <div className="mt-1 text-sm text-muted-foreground">{loadingProgress}%</div>
        </div>
      )}
    </div>
  )
}

