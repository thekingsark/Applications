"use client"

import { useEffect, useRef, useState } from "react"
import type { User } from "@/types/metaverse"

interface SpatialAudioManagerProps {
  users: User[]
  currentUserId: string
  enabled: boolean
}

export function SpatialAudioManager({ users, currentUserId, enabled }: SpatialAudioManagerProps) {
  const audioContextRef = useRef<AudioContext | null>(null)
  const audioElementsRef = useRef<Map<string, HTMLAudioElement>>(new Map())
  const audioSourcesRef = useRef<Map<string, MediaElementAudioSourceNode>>(new Map())
  const pannerNodesRef = useRef<Map<string, PannerNode>>(new Map())
  const gainNodesRef = useRef<Map<string, GainNode>>(new Map())
  const listenerRef = useRef<AudioListener | null>(null)
  const [isInitialized, setIsInitialized] = useState(false)

  // Initialize audio context on first user interaction
  useEffect(() => {
    const initializeAudio = () => {
      try {
        if (!audioContextRef.current && typeof window !== "undefined") {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
          listenerRef.current = audioContextRef.current.listener
          setIsInitialized(true)
        }
      } catch (error) {
        console.error("Error initializing audio context:", error)
      }
    }

    // Initialize on first user interaction
    const handleInteraction = () => {
      initializeAudio()
      document.removeEventListener("click", handleInteraction)
      document.removeEventListener("keydown", handleInteraction)
    }

    document.addEventListener("click", handleInteraction)
    document.addEventListener("keydown", handleInteraction)

    return () => {
      document.removeEventListener("click", handleInteraction)
      document.removeEventListener("keydown", handleInteraction)

      // Clean up audio context
      if (audioContextRef.current && audioContextRef.current.state !== "closed") {
        try {
          audioContextRef.current.close()
        } catch (error) {
          console.error("Error closing audio context:", error)
        }
      }
    }
  }, [])

  // Update spatial audio based on user positions
  useEffect(() => {
    if (!isInitialized || !enabled || !audioContextRef.current) return

    try {
      const currentUser = users.find((user) => user.id === currentUserId)
      if (!currentUser) return

      // Update listener position based on current user
      if (listenerRef.current) {
        // Set listener position
        if (listenerRef.current.positionX) {
          listenerRef.current.positionX.value = currentUser.position[0]
          listenerRef.current.positionY.value = currentUser.position[1]
          listenerRef.current.positionZ.value = currentUser.position[2]
        } else {
          // Fallback for browsers that don't support positionX
          listenerRef.current.setPosition(currentUser.position[0], currentUser.position[1], currentUser.position[2])
        }

        // Set listener orientation
        // Forward direction
        const forwardX = Math.sin(currentUser.rotation[1])
        const forwardY = 0
        const forwardZ = Math.cos(currentUser.rotation[1])

        // Up direction
        const upX = 0
        const upY = 1
        const upZ = 0

        if (listenerRef.current.forwardX) {
          listenerRef.current.forwardX.value = forwardX
          listenerRef.current.forwardY.value = forwardY
          listenerRef.current.forwardZ.value = forwardZ
          listenerRef.current.upX.value = upX
          listenerRef.current.upY.value = upY
          listenerRef.current.upZ.value = upZ
        } else {
          // Fallback for browsers that don't support forwardX
          listenerRef.current.setOrientation(forwardX, forwardY, forwardZ, upX, upY, upZ)
        }
      }

      // Update other users' audio positions
      users.forEach((user) => {
        if (user.id === currentUserId || !user.speaking) return

        // Create or update audio elements for speaking users
        if (!audioElementsRef.current.has(user.id)) {
          // Create a dummy audio element for the user
          const audioElement = new Audio()
          audioElement.loop = true
          audioElement.crossOrigin = "anonymous"
          audioElement.src = "/audio/voice-placeholder.mp3" // Placeholder audio
          audioElement.volume = 0.5

          // Create audio source
          const source = audioContextRef.current!.createMediaElementSource(audioElement)

          // Create panner node for spatial audio
          const panner = audioContextRef.current!.createPanner()
          panner.panningModel = "HRTF"
          panner.distanceModel = "inverse"
          panner.refDistance = 1
          panner.maxDistance = 10
          panner.rolloffFactor = 1
          panner.coneInnerAngle = 360
          panner.coneOuterAngle = 360
          panner.coneOuterGain = 0

          // Create gain node for volume control
          const gain = audioContextRef.current!.createGain()
          gain.gain.value = 1.0

          // Connect nodes
          source.connect(panner)
          panner.connect(gain)
          gain.connect(audioContextRef.current!.destination)

          // Store references
          audioElementsRef.current.set(user.id, audioElement)
          audioSourcesRef.current.set(user.id, source)
          pannerNodesRef.current.set(user.id, panner)
          gainNodesRef.current.set(user.id, gain)

          // Start playing
          audioElement.play().catch((error) => {
            console.error("Error playing audio:", error)
          })
        }

        // Update panner position
        const panner = pannerNodesRef.current.get(user.id)
        if (panner) {
          if (panner.positionX) {
            panner.positionX.value = user.position[0]
            panner.positionY.value = user.position[1]
            panner.positionZ.value = user.position[2]
          } else {
            panner.setPosition(user.position[0], user.position[1], user.position[2])
          }

          // Set orientation based on user rotation
          const orientationX = Math.sin(user.rotation[1])
          const orientationZ = Math.cos(user.rotation[1])

          if (panner.orientationX) {
            panner.orientationX.value = orientationX
            panner.orientationY.value = 0
            panner.orientationZ.value = orientationZ
          } else {
            panner.setOrientation(orientationX, 0, orientationZ)
          }
        }
      })

      // Clean up audio for users who are no longer speaking
      audioElementsRef.current.forEach((audioElement, userId) => {
        const user = users.find((u) => u.id === userId)
        if (!user || !user.speaking) {
          // Stop and remove audio
          audioElement.pause()

          // Disconnect and clean up nodes
          const source = audioSourcesRef.current.get(userId)
          const panner = pannerNodesRef.current.get(userId)
          const gain = gainNodesRef.current.get(userId)

          if (source && panner && gain) {
            try {
              source.disconnect()
              panner.disconnect()
              gain.disconnect()
            } catch (error) {
              console.error("Error disconnecting audio nodes:", error)
            }
          }

          // Remove references
          audioElementsRef.current.delete(userId)
          audioSourcesRef.current.delete(userId)
          pannerNodesRef.current.delete(userId)
          gainNodesRef.current.delete(userId)
        }
      })
    } catch (error) {
      console.error("Error updating spatial audio:", error)
    }
  }, [users, currentUserId, enabled, isInitialized])

  // Clean up on unmount
  useEffect(() => {
    return () => {
      // Stop all audio elements
      audioElementsRef.current.forEach((audioElement) => {
        audioElement.pause()
      })

      // Clear all references
      audioElementsRef.current.clear()
      audioSourcesRef.current.clear()
      pannerNodesRef.current.clear()
      gainNodesRef.current.clear()
    }
  }, [])

  // This component doesn't render anything visible
  return null
}

