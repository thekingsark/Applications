"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mic, MicOff, Search, X, Volume2, Info } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

interface MetaverseVoiceSearchProps {
  isOpen: boolean
  onClose: () => void
  onSearch: (query: string) => void
  onCommand?: (command: string, params?: string) => boolean
}

export default function MetaverseVoiceSearch({ isOpen, onClose, onSearch, onCommand }: MetaverseVoiceSearchProps) {
  const [isListening, setIsListening] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [recognition, setRecognition] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [showCommands, setShowCommands] = useState(false)
  const [commandResult, setCommandResult] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (typeof window !== "undefined") {
      try {
        // @ts-ignore - SpeechRecognition is not in the TypeScript types yet
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

        if (SpeechRecognition) {
          const recognitionInstance = new SpeechRecognition()
          recognitionInstance.continuous = false
          recognitionInstance.interimResults = true
          recognitionInstance.lang = "en-US"

          recognitionInstance.onresult = (event: any) => {
            let finalTranscript = ""
            let interimTranscript = ""

            for (let i = event.resultIndex; i < event.results.length; i++) {
              const transcript = event.results[i][0].transcript
              if (event.results[i].isFinal) {
                finalTranscript += transcript
              } else {
                interimTranscript += transcript
              }
            }

            setTranscript(finalTranscript || interimTranscript)
          }

          recognitionInstance.onend = () => {
            setIsListening(false)

            // Process command if available
            if (onCommand && transcript.trim()) {
              processCommand(transcript)
            }
          }

          recognitionInstance.onerror = (event: any) => {
            console.error("Speech recognition error", event.error)
            setError(`Error: ${event.error}. Please try again.`)
            setIsListening(false)
          }

          setRecognition(recognitionInstance)
        } else {
          setError("Speech recognition is not supported in your browser.")
        }
      } catch (error) {
        console.error("Error initializing speech recognition:", error)
        setError("Failed to initialize speech recognition. Please try again.")
      }
    }

    return () => {
      if (recognition) {
        try {
          recognition.abort()
        } catch (error) {
          console.error("Error aborting recognition:", error)
        }
      }
    }
  }, [onCommand, transcript])

  // Focus input when modal opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => {
        inputRef.current?.focus()
      }, 100)
    }
  }, [isOpen])

  const toggleListening = () => {
    if (isListening) {
      try {
        recognition?.stop()
      } catch (error) {
        console.error("Error stopping recognition:", error)
      }
      setIsListening(false)
    } else {
      setTranscript("")
      setError(null)
      setCommandResult(null)
      try {
        recognition?.start()
        setIsListening(true)
      } catch (error) {
        console.error("Error starting recognition:", error)
        setError("Failed to start speech recognition. Please try again.")
        setIsListening(false)
      }
    }
  }

  const handleSearch = () => {
    if (transcript.trim()) {
      onSearch(transcript)
      onClose()
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTranscript(e.target.value)
    setCommandResult(null)
  }

  const processCommand = (text: string) => {
    // Simple command processing
    const commandPatterns = [
      { regex: /^(go|goto|find|navigate to)\s+(.+)$/i, command: "goto" },
      { regex: /^(find|search for|look for)\s+(.+)$/i, command: "find" },
      { regex: /^(join|enter|go to)\s+(room|the room|the)\s+(.+)$/i, command: "join" },
      {
        regex: /^(create|make|start)\s+(a|new)?\s*(deal|business|transaction)\s+(with|for)?\s+(.+)$/i,
        command: "createDeal",
      },
      { regex: /^(open|show|display)\s+(the|a)?\s*map$/i, command: "openMap" },
      { regex: /^(toggle|turn on|turn off|enable|disable)\s+(spatial audio|audio)$/i, command: "toggleSpatialAudio" },
      { regex: /^(mute|silence)\s+(all|everyone)$/i, command: "muteAll" },
      { regex: /^(unmute|enable audio for)\s+(all|everyone)$/i, command: "unmuteAll" },
      { regex: /^(show|display|list)\s+(participants|users|people)$/i, command: "showParticipants" },
      { regex: /^(show|display|list)\s+(deals|transactions|business)$/i, command: "showDeals" },
      {
        regex: /^(toggle|turn on|turn off|enable|disable)\s+(text to speech|tts|speech)$/i,
        command: "toggleTextToSpeech",
      },
      {
        regex: /^(toggle|turn on|turn off|enable|disable)\s+(voice commands|commands|voice control)$/i,
        command: "toggleVoiceCommands",
      },
      {
        regex: /^(toggle|turn on|turn off|enable|disable)\s+(speech bubbles|bubbles)$/i,
        command: "toggleSpeechBubbles",
      },
      { regex: /^(open|show|display)\s+(settings|options|preferences)$/i, command: "showSettings" },
    ]

    for (const pattern of commandPatterns) {
      const match = text.match(pattern.regex)
      if (match) {
        let params: string | undefined

        if (pattern.command === "join" && match[3]) {
          params = match[3]
        } else if (pattern.command === "createDeal" && match[5]) {
          params = match[5]
        } else if (
          match[2] &&
          ![
            "openMap",
            "toggleSpatialAudio",
            "muteAll",
            "unmuteAll",
            "showParticipants",
            "showDeals",
            "toggleTextToSpeech",
            "toggleVoiceCommands",
            "toggleSpeechBubbles",
            "showSettings",
          ].includes(pattern.command)
        ) {
          params = match[2]
        }

        if (onCommand && onCommand(pattern.command, params)) {
          setCommandResult(`Command executed: ${pattern.command}${params ? ` with parameter: ${params}` : ""}`)
          return true
        }
      }
    }

    // If no command matched, use as search
    setCommandResult("No command recognized. Using as search query.")
    return false
  }

  // Speak text function for feedback
  const speakText = (text: string) => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      try {
        const utterance = new SpeechSynthesisUtterance(text)
        utterance.lang = "en-US"
        window.speechSynthesis.speak(utterance)
      } catch (error) {
        console.error("Error with text-to-speech:", error)
      }
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <Search className="h-5 w-5 mr-2 gold-glow-icon" />
              Voice Search & Commands
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </CardTitle>
          <CardDescription>Speak or type your search query or command</CardDescription>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <Input
              ref={inputRef}
              value={transcript}
              onChange={handleInputChange}
              placeholder="Say something or type your query..."
              className="flex-1"
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            />
            <Button
              variant={isListening ? "destructive" : "outline"}
              size="icon"
              onClick={toggleListening}
              disabled={!recognition}
              className={`${isListening ? "voice-listening" : ""} gold-glow-icon`}
            >
              {isListening ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </Button>
          </div>

          {isListening && (
            <div className="mt-2 flex items-center justify-center">
              <div className="flex space-x-1">
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-75"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-150"></div>
                <div className="h-2 w-2 bg-primary rounded-full animate-bounce delay-300"></div>
              </div>
              <p className="text-xs text-primary ml-2">Listening to your voice...</p>
            </div>
          )}

          {error && <div className="text-center text-sm text-destructive">{error}</div>}

          {commandResult && <div className="text-center text-sm p-2 bg-primary/10 rounded-md">{commandResult}</div>}

          <div className="flex justify-between items-center">
            <Button
              variant="ghost"
              size="sm"
              className="text-xs flex items-center gap-1"
              onClick={() => setShowCommands(!showCommands)}
            >
              <Info className="h-3 w-3" />
              {showCommands ? "Hide Commands" : "Show Available Commands"}
            </Button>

            <Button
              variant="outline"
              size="sm"
              className="h-6 text-xs flex items-center gap-1"
              onClick={() => speakText(transcript)}
            >
              <Volume2 className="h-3 w-3" /> Speak Text
            </Button>
          </div>

          {showCommands && (
            <div className="text-xs border rounded-md p-2 max-h-40 overflow-y-auto">
              <p className="font-medium mb-1">Available Voice Commands:</p>
              <ul className="space-y-1 pl-2">
                <li>"Go to [person name]" - Navigate to a person</li>
                <li>"Find [person name]" - Search for a person</li>
                <li>"Join [room name]" - Enter a different room</li>
                <li>"Create deal with [person name]" - Start a new deal</li>
                <li>"Open map" - Show the room map</li>
                <li>"Toggle spatial audio" - Enable/disable spatial audio</li>
                <li>"Show participants" - View the participants list</li>
                <li>"Show deals" - View the deals list</li>
                <li>"Toggle text to speech" - Enable/disable TTS</li>
                <li>"Open settings" - Show settings panel</li>
              </ul>
            </div>
          )}
        </CardContent>

        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSearch} disabled={!transcript.trim()} className="gap-2 gold-glow-icon">
            <Search className="h-4 w-4" />
            Search
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

