"use client"

import { useEffect, useState } from "react"

interface SpeechBubbleProps {
  text: string
  position: { x: number; y: number }
  isActive: boolean
}

export function SpeechBubble({ text, position, isActive }: SpeechBubbleProps) {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (isActive) {
      setVisible(true)
    } else {
      const timer = setTimeout(() => setVisible(false), 500)
      return () => clearTimeout(timer)
    }
  }, [isActive])

  if (!visible || !text) return null

  return (
    <div
      className="fixed z-50 speech-bubble bg-background/90 backdrop-blur-sm border border-primary/20 px-3 py-2 text-sm max-w-[200px] shadow-lg"
      style={{
        left: position.x,
        top: position.y - 80,
        transform: "translateX(-50%)",
        opacity: isActive ? 1 : 0,
        transition: "opacity 0.3s ease",
      }}
    >
      {text}
    </div>
  )
}

