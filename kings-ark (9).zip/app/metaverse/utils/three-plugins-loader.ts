/**
 * This utility ensures all necessary Three.js plugins are loaded
 * It pre-loads the required modules to prevent rendering issues
 */

import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader"
import { DRACOLoader } from "three/examples/jsm/loaders/DRACOLoader"
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer"
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass"
import { OutlinePass } from "three/examples/jsm/postprocessing/OutlinePass"
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass"
import { FXAAShader } from "three/examples/jsm/shaders/FXAAShader"

export class ThreePluginsLoader {
  static isLoaded = false

  static async preloadPlugins(): Promise<boolean> {
    if (this.isLoaded) return true

    try {
      // Verify all plugins are loaded
      if (
        !THREE ||
        !OrbitControls ||
        !GLTFLoader ||
        !DRACOLoader ||
        !EffectComposer ||
        !RenderPass ||
        !OutlinePass ||
        !ShaderPass ||
        !FXAAShader
      ) {
        console.error("Some Three.js plugins failed to load")
        return false
      }

      // Set up DRACO loader path
      const dracoLoader = new DRACOLoader()
      dracoLoader.setDecoderPath("https://www.gstatic.com/draco/versioned/decoders/1.5.5/")

      // Create a test renderer to verify WebGL is working
      if (typeof window !== "undefined") {
        const testCanvas = document.createElement("canvas")
        const testRenderer = new THREE.WebGLRenderer({
          canvas: testCanvas,
          antialias: true,
        })

        // Dispose of test renderer
        testRenderer.dispose()
      }

      this.isLoaded = true
      return true
    } catch (error) {
      console.error("Error preloading Three.js plugins:", error)
      return false
    }
  }
}

// Preload plugins when this module is imported
if (typeof window !== "undefined") {
  ThreePluginsLoader.preloadPlugins()
}

