/**
 * WebGL Detector
 * Detects WebGL support and capabilities in the current browser
 */

export class WebGLDetector {
  static isWebGLAvailable(): boolean {
    try {
      const canvas = document.createElement("canvas")
      return !!(window.WebGLRenderingContext && (canvas.getContext("webgl") || canvas.getContext("experimental-webgl")))
    } catch (e) {
      return false
    }
  }

  static isWebGL2Available(): boolean {
    try {
      const canvas = document.createElement("canvas")
      return !!(window.WebGL2RenderingContext && canvas.getContext("webgl2"))
    } catch (e) {
      return false
    }
  }

  static getWebGLErrorMessage(): string {
    return "Your browser does not support WebGL, which is required for the 3D environment. Please try a different browser like Chrome, Firefox, or Edge."
  }

  static getWebGL2ErrorMessage(): string {
    return "Your browser does not support WebGL 2. The application will run with WebGL 1, but performance may be reduced."
  }
}

