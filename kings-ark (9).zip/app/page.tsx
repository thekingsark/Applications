"use client"

import { useState, useEffect } from "react"
import LoadingScreen from "@/components/loading-screen"
import MainContent from "@/components/main-content"
import BackgroundSmoke from "@/components/background-smoke"
import ErrorBoundaryWrapper from "@/components/error-boundary-wrapper"

export default function Home() {
  const [loading, setLoading] = useState(true)
  const [progress, setProgress] = useState(0)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    try {
      // Simulate loading progress
      const interval = setInterval(() => {
        setProgress((prevProgress) => {
          const newProgress = prevProgress + Math.random() * 10
          if (newProgress >= 100) {
            clearInterval(interval)
            // Add a small delay before removing the loading screen
            setTimeout(() => {
              setLoading(false)
            }, 500)
            return 100
          }
          return newProgress
        })
      }, 500)

      // Force completion after 8 seconds
      const timeout = setTimeout(() => {
        setProgress(100)
        clearInterval(interval)
        setTimeout(() => {
          setLoading(false)
        }, 500)
      }, 8000)

      return () => {
        clearInterval(interval)
        clearTimeout(timeout)
      }
    } catch (err) {
      console.error("Error in Home component:", err)
      setError("Failed to initialize application")
      setLoading(false)
    }
  }, [])

  // Debug logging
  useEffect(() => {
    console.log("Home component rendered, loading state:", loading)
  }, [loading])

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="max-w-md w-full p-6 bg-card rounded-lg shadow-lg border border-border">
          <h1 className="text-xl font-bold text-center mb-4">Application Error</h1>
          <p className="text-muted-foreground text-center mb-6">{error}</p>
          <div className="flex justify-center">
            <button
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md"
              onClick={() => window.location.reload()}
            >
              Refresh Page
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <ErrorBoundaryWrapper>
      <main className="min-h-screen">
        {loading ? (
          <LoadingScreen progress={progress} />
        ) : (
          <div className="relative min-h-screen">
            <BackgroundSmoke />
            <MainContent />
          </div>
        )}
      </main>
    </ErrorBoundaryWrapper>
  )
}

