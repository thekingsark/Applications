"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Search,
  Filter,
  Download,
  Upload,
  FileText,
  Folder,
  ArrowLeft,
  MoreHorizontal,
  Share2,
  Star,
  StarOff,
} from "lucide-react"
import Link from "next/link"
import { format } from "date-fns"

// Sample documents data
const documents = [
  {
    id: "doc-001",
    name: "Trade Agreement Template",
    type: "document",
    format: "docx",
    size: "245 KB",
    created: new Date("2025-03-10"),
    modified: new Date("2025-03-12"),
    category: "Templates",
    starred: true,
    shared: true,
  },
  {
    id: "doc-002",
    name: "International Shipping Guidelines",
    type: "document",
    format: "pdf",
    size: "1.2 MB",
    created: new Date("2025-03-05"),
    modified: new Date("2025-03-05"),
    category: "Guidelines",
    starred: false,
    shared: true,
  },
  {
    id: "doc-003",
    name: "Market Analysis Report - Q1 2025",
    type: "document",
    format: "pdf",
    size: "3.5 MB",
    created: new Date("2025-03-01"),
    modified: new Date("2025-03-01"),
    category: "Reports",
    starred: true,
    shared: false,
  },
  {
    id: "doc-004",
    name: "Product Catalog",
    type: "document",
    format: "pdf",
    size: "8.7 MB",
    created: new Date("2025-02-28"),
    modified: new Date("2025-03-10"),
    category: "Marketing",
    starred: false,
    shared: true,
  },
  {
    id: "doc-005",
    name: "Invoice Template",
    type: "document",
    format: "xlsx",
    size: "125 KB",
    created: new Date("2025-02-25"),
    modified: new Date("2025-02-25"),
    category: "Templates",
    starred: false,
    shared: false,
  },
  {
    id: "doc-006",
    name: "Compliance Checklist",
    type: "document",
    format: "docx",
    size: "180 KB",
    created: new Date("2025-02-20"),
    modified: new Date("2025-02-22"),
    category: "Guidelines",
    starred: false,
    shared: false,
  },
  {
    id: "doc-007",
    name: "Buyer-Seller Agreement",
    type: "document",
    format: "docx",
    size: "210 KB",
    created: new Date("2025-02-15"),
    modified: new Date("2025-02-15"),
    category: "Templates",
    starred: true,
    shared: true,
  },
  {
    id: "doc-008",
    name: "Product Images",
    type: "folder",
    items: "12 items",
    created: new Date("2025-02-10"),
    modified: new Date("2025-03-08"),
    category: "Marketing",
    starred: false,
    shared: true,
  },
]

// Folders
const folders = [
  {
    id: "folder-001",
    name: "Templates",
    items: "3 items",
    created: new Date("2025-01-15"),
    modified: new Date("2025-03-12"),
  },
  {
    id: "folder-002",
    name: "Reports",
    items: "8 items",
    created: new Date("2025-01-20"),
    modified: new Date("2025-03-01"),
  },
  {
    id: "folder-003",
    name: "Marketing Materials",
    items: "15 items",
    created: new Date("2025-01-25"),
    modified: new Date("2025-03-10"),
  },
  {
    id: "folder-004",
    name: "Guidelines",
    items: "5 items",
    created: new Date("2025-02-01"),
    modified: new Date("2025-03-05"),
  },
]

export default function DocumentsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")
  const [starredDocs, setStarredDocs] = useState(documents.filter((doc) => doc.starred))

  // Filter documents based on search query and active tab
  const filteredDocuments = documents.filter((doc) => {
    // Search filter
    if (searchQuery && !doc.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false
    }

    // Tab filter
    if (activeTab === "starred" && !doc.starred) {
      return false
    }
    if (activeTab === "shared" && !doc.shared) {
      return false
    }

    return true
  })

  // Toggle star status
  const toggleStar = (id: string) => {
    const updatedDocs = documents.map((doc) => {
      if (doc.id === id) {
        return { ...doc, starred: !doc.starred }
      }
      return doc
    })

    // Update starred docs
    setStarredDocs(updatedDocs.filter((doc) => doc.starred))
  }

  return (
    <div className="container mx-auto py-6 px-4 md:px-6 max-w-6xl">
      <div className="flex items-center gap-2 mb-6">
        <Link href="/" className="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Documents</h1>
          <p className="text-muted-foreground">Manage your trade documents and files</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <Button className="flex-1 sm:flex-none gap-2">
            <Upload className="h-4 w-4" />
            Upload
          </Button>
          <Button variant="outline" className="flex-1 sm:flex-none gap-2">
            <Download className="h-4 w-4" />
            Download
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search documents..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-2 w-full sm:w-auto">
          <Filter className="h-4 w-4" />
          Filters
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-6">
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Folders</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {folders.map((folder) => (
                <Button key={folder.id} variant="ghost" className="w-full justify-start">
                  <Folder className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>{folder.name}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{folder.items}</span>
                </Button>
              ))}
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                New Folder
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Categories</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {["Templates", "Reports", "Guidelines", "Marketing"].map((category) => (
                <Button key={category} variant="ghost" className="w-full justify-start">
                  <span>{category}</span>
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>

        <div>
          <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Documents</TabsTrigger>
              <TabsTrigger value="starred">Starred</TabsTrigger>
              <TabsTrigger value="shared">Shared</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4">
              <div className="border rounded-md">
                <div className="grid grid-cols-12 gap-2 p-3 border-b bg-muted/50 text-sm font-medium">
                  <div className="col-span-5">Name</div>
                  <div className="col-span-2">Category</div>
                  <div className="col-span-2">Modified</div>
                  <div className="col-span-2">Size</div>
                  <div className="col-span-1"></div>
                </div>
                {filteredDocuments.length > 0 ? (
                  <div className="divide-y">
                    {filteredDocuments.map((doc) => (
                      <div
                        key={doc.id}
                        className="grid grid-cols-12 gap-2 p-3 items-center hover:bg-muted/30 transition-colors"
                      >
                        <div className="col-span-5 flex items-center gap-3">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStar(doc.id)}>
                            {doc.starred ? (
                              <Star className="h-4 w-4 text-amber-500" />
                            ) : (
                              <StarOff className="h-4 w-4 text-muted-foreground" />
                            )}
                          </Button>
                          {doc.type === "document" ? (
                            <FileText className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <Folder className="h-5 w-5 text-muted-foreground" />
                          )}
                          <span className="font-medium">{doc.name}</span>
                          {doc.format && (
                            <Badge variant="outline" className="ml-2">
                              {doc.format}
                            </Badge>
                          )}
                        </div>
                        <div className="col-span-2">
                          <Badge variant="secondary">{doc.category}</Badge>
                        </div>
                        <div className="col-span-2 text-sm text-muted-foreground">
                          {format(doc.modified, "MMM d, yyyy")}
                        </div>
                        <div className="col-span-2 text-sm text-muted-foreground">{doc.size || doc.items}</div>
                        <div className="col-span-1 flex justify-end">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium">No documents found</h3>
                    <p className="text-muted-foreground">Try adjusting your search or filters</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="starred" className="space-y-4">
              <div className="border rounded-md">
                <div className="grid grid-cols-12 gap-2 p-3 border-b bg-muted/50 text-sm font-medium">
                  <div className="col-span-5">Name</div>
                  <div className="col-span-2">Category</div>
                  <div className="col-span-2">Modified</div>
                  <div className="col-span-2">Size</div>
                  <div className="col-span-1"></div>
                </div>
                {filteredDocuments.length > 0 ? (
                  <div className="divide-y">
                    {filteredDocuments.map((doc) => (
                      <div
                        key={doc.id}
                        className="grid grid-cols-12 gap-2 p-3 items-center hover:bg-muted/30 transition-colors"
                      >
                        <div className="col-span-5 flex items-center gap-3">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStar(doc.id)}>
                            <Star className="h-4 w-4 text-amber-500" />
                          </Button>
                          {doc.type === "document" ? (
                            <FileText className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <Folder className="h-5 w-5 text-muted-foreground" />
                          )}
                          <span className="font-medium">{doc.name}</span>
                          {doc.format && (
                            <Badge variant="outline" className="ml-2">
                              {doc.format}
                            </Badge>
                          )}
                        </div>
                        <div className="col-span-2">
                          <Badge variant="secondary">{doc.category}</Badge>
                        </div>
                        <div className="col-span-2 text-sm text-muted-foreground">
                          {format(doc.modified, "MMM d, yyyy")}
                        </div>
                        <div className="col-span-2 text-sm text-muted-foreground">{doc.size || doc.items}</div>
                        <div className="col-span-1 flex justify-end">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <Star className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium">No starred documents</h3>
                    <p className="text-muted-foreground">Star documents to find them quickly</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="shared" className="space-y-4">
              <div className="border rounded-md">
                <div className="grid grid-cols-12 gap-2 p-3 border-b bg-muted/50 text-sm font-medium">
                  <div className="col-span-5">Name</div>
                  <div className="col-span-2">Category</div>
                  <div className="col-span-2">Modified</div>
                  <div className="col-span-2">Size</div>
                  <div className="col-span-1"></div>
                </div>
                {filteredDocuments.length > 0 ? (
                  <div className="divide-y">
                    {filteredDocuments.map((doc) => (
                      <div
                        key={doc.id}
                        className="grid grid-cols-12 gap-2 p-3 items-center hover:bg-muted/30 transition-colors"
                      >
                        <div className="col-span-5 flex items-center gap-3">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStar(doc.id)}>
                            {doc.starred ? (
                              <Star className="h-4 w-4 text-amber-500" />
                            ) : (
                              <StarOff className="h-4 w-4 text-muted-foreground" />
                            )}
                          </Button>
                          {doc.type === "document" ? (
                            <FileText className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <Folder className="h-5 w-5 text-muted-foreground" />
                          )}
                          <span className="font-medium">{doc.name}</span>
                          {doc.format && (
                            <Badge variant="outline" className="ml-2">
                              {doc.format}
                            </Badge>
                          )}
                        </div>
                        <div className="col-span-2">
                          <Badge variant="secondary">{doc.category}</Badge>
                        </div>
                        <div className="col-span-2 text-sm text-muted-foreground">
                          {format(doc.modified, "MMM d, yyyy")}
                        </div>
                        <div className="col-span-2 text-sm text-muted-foreground">{doc.size || doc.items}</div>
                        <div className="col-span-1 flex justify-end">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Share2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-8 text-center">
                    <Share2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium">No shared documents</h3>
                    <p className="text-muted-foreground">Documents shared with you will appear here</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

