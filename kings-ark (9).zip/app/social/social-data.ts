import type { SocialUser, Post, Trend, Notification, Conversation, Message } from "@/types/social"
import { partnersData } from "@/app/global-map/partners-data"

// Convert partners to social users
export const generateSocialUsers = (): SocialUser[] => {
  return partnersData.map((partner) => ({
    id: partner.id,
    name: partner.name,
    username: partner.name.toLowerCase().replace(/\s+/g, "_"),
    avatar: partner.logo,
    bio: partner.description,
    verified: partner.verified,
    following: Math.floor(Math.random() * 500) + 50,
    followers: Math.floor(Math.random() * 5000) + 100,
    joined: `${2020 + Math.floor(Math.random() * 4)}`,
    location: `${partner.city}, ${partner.country}`,
    website: partner.website,
    partner: partner,
  }))
}

// Business-related hashtags
const businessHashtags = [
  "#B2B",
  "#GlobalTrade",
  "#Innovation",
  "#Sustainability",
  "#SupplyChain",
  "#Logistics",
  "#Manufacturing",
  "#Export",
  "#Import",
  "#BusinessGrowth",
  "#InternationalTrade",
  "#MarketExpansion",
  "#TradeFair",
  "#Industry40",
  "#DigitalTransformation",
  "#BusinessStrategy",
  "#GlobalMarkets",
  "#KingsArk",
]

// Generate random hashtags for a post
const getRandomHashtags = (count: number): string[] => {
  const shuffled = [...businessHashtags].sort(() => 0.5 - Math.random())
  return shuffled.slice(0, count)
}

// Business-related post content templates
const postTemplates = [
  "Excited to announce our new partnership with {company} to expand our reach in {region}!",
  "Just closed a major deal with {company}. Looking forward to this collaboration!",
  "Attending the {industry} trade show in {location} next month. Who else will be there?",
  "Our latest product line has seen a 30% increase in international orders. Global markets are responding well!",
  "Sustainability isn't just a buzzword for us. Here's how we're reducing our carbon footprint in our supply chain.",
  "Proud to announce that we've been certified as a {certification} company. Commitment to quality is our priority!",
  "Looking for reliable suppliers in {region} for our upcoming project. Any recommendations?",
  "The future of {industry} is changing rapidly. Here's our take on the emerging trends.",
  "Just published our quarterly market analysis. Key insights for businesses operating in {region}.",
  "Celebrating 5 years of successful international trade partnerships today! Thanks to all our global partners.",
  "Regulatory changes in {region} are creating new opportunities for exporters. Here's what you need to know.",
  "Our team is growing! We're looking for experienced professionals in {field} to join our international operations.",
  "Innovation is at the heart of what we do. Check out our latest solution for {industry} challenges.",
  "Supply chain disruptions are affecting many businesses. Here's how we're navigating these challenges.",
  "Just shipped our largest order to date to {location}! Expanding our global footprint one step at a time.",
  "Participated in a fascinating panel discussion on the future of {industry} at the {event} conference.",
  "Quality control is crucial for international trade. Here's our approach to maintaining standards across borders.",
  "Market research indicates growing demand for {product} in {region}. Time to explore these opportunities!",
  "Digital transformation has revolutionized how we manage our global operations. Here's our journey.",
  "Proud to support sustainable development goals through our business practices. Here's our impact report.",
]

// Fill in templates with random data
const fillTemplate = (template: string): string => {
  const companies = partnersData.map((p) => p.name)
  const regions = ["Asia", "Europe", "North America", "South America", "Africa", "Middle East", "Australia"]
  const industries = [
    "Manufacturing",
    "Technology",
    "Agriculture",
    "Textiles",
    "Electronics",
    "Automotive",
    "Food & Beverage",
  ]
  const locations = partnersData.map((p) => `${p.city}, ${p.country}`)
  const certifications = ["ISO 9001", "Fair Trade", "Organic", "B Corp", "ISO 14001", "LEED"]
  const fields = ["Logistics", "Marketing", "Product Development", "International Sales", "Supply Chain Management"]
  const products = [
    "Sustainable Materials",
    "Smart Devices",
    "Organic Products",
    "Industrial Equipment",
    "Luxury Goods",
  ]
  const events = [
    "Global Trade Summit",
    "Industry Expo",
    "International Business Forum",
    "Tech Conference",
    "Sustainability Summit",
  ]

  return template
    .replace("{company}", companies[Math.floor(Math.random() * companies.length)])
    .replace("{region}", regions[Math.floor(Math.random() * regions.length)])
    .replace("{industry}", industries[Math.floor(Math.random() * industries.length)])
    .replace("{location}", locations[Math.floor(Math.random() * locations.length)])
    .replace("{certification}", certifications[Math.floor(Math.random() * certifications.length)])
    .replace("{field}", fields[Math.floor(Math.random() * fields.length)])
    .replace("{product}", products[Math.floor(Math.random() * products.length)])
    .replace("{event}", events[Math.floor(Math.random() * events.length)])
}

// Generate random timestamp within the last 30 days
const getRandomTimestamp = (): string => {
  const now = new Date()
  const randomMinutes = Math.floor(Math.random() * 30 * 24 * 60) // Random minutes within 30 days
  const date = new Date(now.getTime() - randomMinutes * 60000)

  // Format as "10h" or "2d" or "Mar 15" depending on how old
  const diffHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

  if (diffHours < 24) {
    return `${diffHours}h`
  } else {
    const diffDays = Math.floor(diffHours / 24)
    if (diffDays < 7) {
      return `${diffDays}d`
    } else {
      return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
    }
  }
}

// Generate sample posts
export const generatePosts = (users: SocialUser[]): Post[] => {
  const posts: Post[] = []

  // Each user creates 1-5 posts
  users.forEach((user) => {
    const postCount = Math.floor(Math.random() * 5) + 1

    for (let i = 0; i < postCount; i++) {
      const hasImage = Math.random() > 0.6
      const hasMultipleImages = hasImage && Math.random() > 0.7
      const hasVideo = !hasImage && Math.random() > 0.8

      const post: Post = {
        id: `post-${user.id}-${i}`,
        content: fillTemplate(postTemplates[Math.floor(Math.random() * postTemplates.length)]),
        author: user,
        timestamp: getRandomTimestamp(),
        likes: Math.floor(Math.random() * 100),
        reposts: Math.floor(Math.random() * 30),
        replies: Math.floor(Math.random() * 20),
        views: Math.floor(Math.random() * 1000) + 100,
        hasLiked: Math.random() > 0.7,
        hasReposted: Math.random() > 0.8,
        hashtags: getRandomHashtags(Math.floor(Math.random() * 3) + 1),
      }

      if (hasImage) {
        post.images = hasMultipleImages
          ? [
              `/placeholder.svg?height=400&width=600&text=Business+Image+1`,
              `/placeholder.svg?height=400&width=600&text=Business+Image+2`,
            ]
          : [`/placeholder.svg?height=400&width=600&text=Business+Image`]
      }

      if (hasVideo) {
        post.video = `/placeholder.svg?height=400&width=600&text=Business+Video`
      }

      posts.push(post)

      // Add some replies to this post
      if (Math.random() > 0.7) {
        const replyCount = Math.floor(Math.random() * 3) + 1

        for (let j = 0; j < replyCount; j++) {
          const replier = users[Math.floor(Math.random() * users.length)]

          const reply: Post = {
            id: `reply-${post.id}-${j}`,
            content: `Great initiative @${user.username}! Looking forward to seeing the results.`,
            author: replier,
            timestamp: getRandomTimestamp(),
            likes: Math.floor(Math.random() * 20),
            reposts: Math.floor(Math.random() * 5),
            replies: Math.floor(Math.random() * 3),
            views: Math.floor(Math.random() * 200) + 50,
            isReply: true,
            replyTo: post.id,
            mentions: [user.username],
          }

          posts.push(reply)
        }
      }

      // Add some reposts
      if (Math.random() > 0.8) {
        const reposter = users[Math.floor(Math.random() * users.length)]

        const repost: Post = {
          id: `repost-${post.id}`,
          content: "",
          author: reposter,
          timestamp: getRandomTimestamp(),
          likes: Math.floor(Math.random() * 15),
          reposts: Math.floor(Math.random() * 3),
          replies: Math.floor(Math.random() * 2),
          views: Math.floor(Math.random() * 150) + 30,
          isRepost: true,
          originalPost: post,
        }

        posts.push(repost)
      }
    }
  })

  // Sort posts by timestamp (newest first)
  return posts.sort(() => 0.5 - Math.random())
}

// Generate trending topics
export const generateTrends = (): Trend[] => {
  return [
    {
      id: "t1",
      name: "#GlobalTrade",
      category: "Business",
      posts: 15243,
    },
    {
      id: "t2",
      name: "#SupplyChain",
      category: "Business",
      posts: 8765,
    },
    {
      id: "t3",
      name: "#Sustainability",
      category: "Business",
      posts: 12456,
    },
    {
      id: "t4",
      name: "#B2BMarketing",
      category: "Marketing",
      posts: 6789,
    },
    {
      id: "t5",
      name: "#ExportOpportunities",
      category: "Trade",
      posts: 5432,
    },
    {
      id: "t6",
      name: "#InternationalLogistics",
      category: "Logistics",
      posts: 4321,
    },
    {
      id: "t7",
      name: "#MarketExpansion",
      category: "Business",
      posts: 7654,
    },
    {
      id: "t8",
      name: "#KingsArk",
      category: "Business",
      posts: 9876,
    },
    {
      id: "t9",
      name: "#IndustryInnovation",
      category: "Technology",
      posts: 8765,
    },
    {
      id: "t10",
      name: "#GlobalPartnerships",
      category: "Business",
      posts: 6543,
    },
  ]
}

// Generate notifications
export const generateNotifications = (users: SocialUser[], posts: Post[]): Notification[] => {
  const notifications: Notification[] = []

  for (let i = 0; i < 15; i++) {
    const actor = users[Math.floor(Math.random() * users.length)]
    const post = posts[Math.floor(Math.random() * posts.length)]
    const types: ("like" | "repost" | "reply" | "mention" | "follow")[] = [
      "like",
      "repost",
      "reply",
      "mention",
      "follow",
    ]
    const type = types[Math.floor(Math.random() * types.length)]

    notifications.push({
      id: `notif-${i}`,
      type,
      actor,
      post: type !== "follow" ? post : undefined,
      timestamp: getRandomTimestamp(),
      read: Math.random() > 0.3,
    })
  }

  return notifications
}

// Generate conversations and messages
export const generateConversations = (users: SocialUser[]): Conversation[] => {
  const conversations: Conversation[] = []
  const currentUser = users[0] // Assume first user is current user

  for (let i = 1; i < 10; i++) {
    const otherUser = users[i]
    const messages: Message[] = []

    // Generate 3-10 messages per conversation
    const messageCount = Math.floor(Math.random() * 8) + 3

    for (let j = 0; j < messageCount; j++) {
      const sender = j % 2 === 0 ? currentUser : otherUser
      const recipient = j % 2 === 0 ? otherUser : currentUser

      messages.push({
        id: `msg-${i}-${j}`,
        sender,
        recipient,
        content:
          j % 2 === 0
            ? `Hi ${recipient.name}, I'm interested in your ${recipient.partner?.category.toLowerCase()} products. Can we discuss potential collaboration?`
            : `Hello ${sender.name}, thank you for reaching out! I'd be happy to discuss our offerings and potential partnership opportunities.`,
        timestamp: getRandomTimestamp(),
        read: j < messageCount - 2,
      })
    }

    conversations.push({
      id: `conv-${i}`,
      participants: [currentUser, otherUser],
      lastMessage: messages[messages.length - 1],
      unreadCount: Math.floor(Math.random() * 3),
    })
  }

  return conversations
}

// Get who to follow suggestions
export const getWhoToFollowSuggestions = (users: SocialUser[], count = 3): SocialUser[] => {
  const shuffled = [...users].sort(() => 0.5 - Math.random())
  return shuffled.slice(0, count)
}

