"use client"

import { useState } from "react"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Verified, Heart, Repeat, MessageCircle, User, ArrowLeft } from "lucide-react"
import Link from "next/link"
import XHeader from "../components/x-header"
import { generateNotifications, generateSocialUsers, generatePosts } from "../social-data"
import type { Notification } from "@/types/social"

export default function NotificationsPage() {
  const [activeTab, setActiveTab] = useState("all")
  const users = generateSocialUsers()
  const posts = generatePosts(users)
  const allNotifications = generateNotifications(users, posts)

  const mentions = allNotifications.filter((n) => n.type === "mention")
  const verified = allNotifications.filter((n) => n.actor.verified)

  return (
    <div className="min-h-screen bg-background">
      <XHeader />

      <div className="container mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-0">
          {/* Left sidebar - hidden on mobile */}
          <div className="hidden md:block md:col-span-1">
            <div className="sticky top-14 p-4">
              {/* Replace the X icon with a glowing Back to Home link */}
              <Link
                href="/"
                className="flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-gradient-to-r from-primary/80 to-primary text-primary-foreground shadow-lg hover:shadow-primary/50 transition-all duration-300 animate-pulse"
              >
                <ArrowLeft className="h-5 w-5" />
                <span className="font-bold">Back to Home</span>
              </Link>

              <nav className="space-y-2">
                <Link
                  href="/social"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Home
                </Link>
                <Link
                  href="/social/explore"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Explore
                </Link>
                <Link
                  href="/social/notifications"
                  className="flex items-center gap-4 text-xl font-bold p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Notifications
                </Link>
                <Link
                  href="/social/messages"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Messages
                </Link>
                <Link
                  href="/social/bookmarks"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Bookmarks
                </Link>
                <Link
                  href="/social/profile"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Profile
                </Link>
              </nav>
            </div>
          </div>

          {/* Main content */}
          <div className="col-span-1 md:col-span-2 border-x min-h-screen">
            <div className="sticky top-14 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10 border-b">
              <div className="px-4 py-3">
                <h1 className="text-xl font-bold">Notifications</h1>
              </div>

              <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full grid grid-cols-3 rounded-none h-12">
                  <TabsTrigger
                    value="all"
                    className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
                  >
                    All
                  </TabsTrigger>
                  <TabsTrigger
                    value="mentions"
                    className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
                  >
                    Mentions
                  </TabsTrigger>
                  <TabsTrigger
                    value="verified"
                    className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
                  >
                    Verified
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="mt-0 p-0">
                  <div className="divide-y">
                    {allNotifications.map((notification) => (
                      <NotificationItem key={notification.id} notification={notification} />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="mentions" className="mt-0 p-0">
                  <div className="divide-y">
                    {mentions.length > 0 ? (
                      mentions.map((notification) => (
                        <NotificationItem key={notification.id} notification={notification} />
                      ))
                    ) : (
                      <div className="p-8 text-center text-muted-foreground">
                        <p>No mentions yet</p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="verified" className="mt-0 p-0">
                  <div className="divide-y">
                    {verified.length > 0 ? (
                      verified.map((notification) => (
                        <NotificationItem key={notification.id} notification={notification} />
                      ))
                    ) : (
                      <div className="p-8 text-center text-muted-foreground">
                        <p>No notifications from verified users</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>

          {/* Right sidebar - hidden on mobile and tablet */}
          <div className="hidden lg:block lg:col-span-1">
            <div className="sticky top-14 p-4 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Notification Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Push notifications</span>
                    <Button variant="outline" size="sm">
                      Manage
                    </Button>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Email notifications</span>
                    <Button variant="outline" size="sm">
                      Manage
                    </Button>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Filter notifications</span>
                    <Button variant="outline" size="sm">
                      Manage
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Notification Tips</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <p>• Use filters to focus on important notifications</p>
                  <p>• Enable push for time-sensitive updates</p>
                  <p>• Check the Verified tab for updates from verified business partners</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function NotificationItem({ notification }: { notification: Notification }) {
  return (
    <div className="p-4 hover:bg-accent/5 transition-colors">
      <div className="flex gap-3">
        <Avatar>
          <AvatarImage src={notification.actor.avatar} />
          <AvatarFallback>{notification.actor.name.charAt(0)}</AvatarFallback>
        </Avatar>

        <div>
          <div className="flex items-center gap-1 flex-wrap">
            <span className="font-semibold">{notification.actor.name}</span>
            {notification.actor.verified && <Verified className="h-4 w-4 text-primary" />}
          </div>

          <div className="flex items-center gap-1 text-sm">
            {notification.type === "like" && (
              <>
                <Heart className="h-4 w-4 text-red-500" />
                <span>liked your post</span>
              </>
            )}

            {notification.type === "repost" && (
              <>
                <Repeat className="h-4 w-4 text-green-500" />
                <span>reposted your post</span>
              </>
            )}

            {notification.type === "reply" && (
              <>
                <MessageCircle className="h-4 w-4 text-blue-500" />
                <span>replied to your post</span>
              </>
            )}

            {notification.type === "mention" && (
              <>
                <MessageCircle className="h-4 w-4 text-blue-500" />
                <span>mentioned you in a post</span>
              </>
            )}

            {notification.type === "follow" && (
              <>
                <User className="h-4 w-4 text-primary" />
                <span>followed you</span>
              </>
            )}
          </div>

          <p className="text-sm text-muted-foreground mt-1">{notification.timestamp}</p>

          {notification.post && (
            <div className="mt-2 p-3 border rounded-lg">
              <p className="line-clamp-2">{notification.post.content}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

