import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header skeleton */}
      <div className="border-b">
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center">
            <Skeleton className="h-8 w-8 rounded-full" />
          </div>

          <div className="hidden md:block w-full max-w-xs mx-4">
            <Skeleton className="h-9 w-full rounded-full" />
          </div>

          <div className="flex items-center space-x-2">
            <Skeleton className="h-8 w-8 rounded-full" />
            <Skeleton className="h-8 w-8 rounded-full" />
            <Skeleton className="h-8 w-8 rounded-full" />
          </div>
        </div>
      </div>

      <div className="container mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-0">
          {/* Left sidebar skeleton - hidden on mobile */}
          <div className="hidden md:block md:col-span-1">
            <div className="sticky top-14 p-4">
              <Skeleton className="h-8 w-8 mb-6" />
              <div className="space-y-2">
                {[...Array(6)].map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full rounded-full" />
                ))}
              </div>
            </div>
          </div>

          {/* Main content skeleton */}
          <div className="col-span-1 md:col-span-2 border-x min-h-screen">
            <div className="sticky top-14 bg-background z-10 border-b">
              <div className="px-4 py-3">
                <Skeleton className="h-7 w-24" />
              </div>

              <div className="grid grid-cols-2 h-12 border-b">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </div>
            </div>

            <div className="border-b p-4">
              <div className="flex gap-3">
                <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
                <div className="flex-1">
                  <Skeleton className="h-24 w-full mb-4" />
                  <div className="flex justify-between">
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <Skeleton key={i} className="h-8 w-8 rounded-full" />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Post skeletons */}
            {[...Array(5)].map((_, i) => (
              <div key={i} className="border-b p-4">
                <div className="flex gap-3">
                  <Skeleton className="h-10 w-10 rounded-full flex-shrink-0" />
                  <div className="flex-1">
                    <div className="flex justify-between mb-2">
                      <div className="flex gap-2">
                        <Skeleton className="h-5 w-24" />
                        <Skeleton className="h-5 w-16" />
                      </div>
                      <Skeleton className="h-5 w-5 rounded-full" />
                    </div>
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-3/4 mb-3" />
                    <Skeleton className="h-40 w-full rounded-xl mb-3" />
                    <div className="flex justify-between">
                      {[...Array(4)].map((_, j) => (
                        <Skeleton key={j} className="h-6 w-12" />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right sidebar skeleton - hidden on mobile and tablet */}
          <div className="hidden lg:block lg:col-span-1">
            <div className="sticky top-14 p-4 space-y-4">
              <Skeleton className="h-10 w-full rounded-full mb-4" />

              <div className="space-y-4">
                <Skeleton className="h-8 w-40 mb-2" />
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
                <Skeleton className="h-4 w-24" />
              </div>

              <div className="space-y-4 mt-6">
                <Skeleton className="h-8 w-40 mb-2" />
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
                <Skeleton className="h-4 w-24" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

