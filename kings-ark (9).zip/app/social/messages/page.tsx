"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Verified, Search, Settings, Edit, Send, Paperclip, Smile, ArrowLeft, MoreHorizontal, Home } from "lucide-react"
import Link from "next/link"
import XHeader from "../components/x-header"
import { generateSocialUsers, generateConversations } from "../social-data"
import type { Conversation } from "@/types/social"

export default function MessagesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [newMessage, setNewMessage] = useState("")
  const users = generateSocialUsers()
  const currentUser = users[0]
  const conversations = generateConversations(users)
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)

  const filteredConversations = searchQuery
    ? conversations.filter((conv) => {
        const otherUser = conv.participants.find((p) => p.id !== currentUser.id)!
        return (
          otherUser.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          otherUser.username.toLowerCase().includes(searchQuery.toLowerCase())
        )
      })
    : conversations

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedConversation) return
    // In a real app, this would send the message to the API
    setNewMessage("")
  }

  return (
    <div className="min-h-screen bg-background">
      <XHeader />

      <div className="container mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-0">
          {/* Left sidebar - hidden on mobile */}
          <div className="hidden md:block md:col-span-1">
            <div className="sticky top-14 p-4">
              {/* Replace the X icon with a glowing Back to Home link */}
              <Link
                href="/"
                className="flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-gradient-to-r from-primary/80 to-primary text-primary-foreground shadow-lg hover:shadow-primary/50 transition-all duration-300 animate-pulse"
              >
                <Home className="h-5 w-5" />
                <span className="font-bold">Back to Home</span>
              </Link>

              <nav className="space-y-2">
                <Link
                  href="/social"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Home
                </Link>
                <Link
                  href="/social/explore"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Explore
                </Link>
                <Link
                  href="/social/notifications"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Notifications
                </Link>
                <Link
                  href="/social/messages"
                  className="flex items-center gap-4 text-xl font-bold p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Messages
                </Link>
                <Link
                  href="/social/bookmarks"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Bookmarks
                </Link>
                <Link
                  href="/social/profile"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Profile
                </Link>
              </nav>
            </div>
          </div>

          {/* Main content */}
          <div className="col-span-1 md:col-span-3 lg:col-span-3 border-x min-h-screen">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 h-[calc(100vh-56px)]">
              {/* Conversation list */}
              <div className={`border-r ${selectedConversation ? "hidden md:block" : ""}`}>
                <div className="sticky top-14 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10 border-b p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h1 className="text-xl font-bold">Messages</h1>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon">
                        <Settings className="h-5 w-5" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Edit className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>

                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search Direct Messages"
                      className="pl-9"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>

                <div className="overflow-y-auto h-[calc(100vh-150px)]">
                  {filteredConversations.length > 0 ? (
                    filteredConversations.map((conversation) => {
                      const otherUser = conversation.participants.find((p) => p.id !== currentUser.id)!

                      return (
                        <div
                          key={conversation.id}
                          className={`p-4 hover:bg-accent/5 cursor-pointer transition-colors ${
                            selectedConversation?.id === conversation.id ? "bg-accent/10" : ""
                          }`}
                          onClick={() => setSelectedConversation(conversation)}
                        >
                          <div className="flex gap-3">
                            <Avatar>
                              <AvatarImage src={otherUser.avatar} />
                              <AvatarFallback>{otherUser.name.charAt(0)}</AvatarFallback>
                            </Avatar>

                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1">
                                <span className="font-semibold truncate">{otherUser.name}</span>
                                {otherUser.verified && <Verified className="h-4 w-4 text-primary" />}
                                <span className="text-sm text-muted-foreground">@{otherUser.username}</span>
                                <span className="text-sm text-muted-foreground ml-auto">
                                  {conversation.lastMessage.timestamp}
                                </span>
                              </div>

                              <p className="text-sm truncate">
                                {conversation.lastMessage.sender.id === currentUser.id ? "You: " : ""}
                                {conversation.lastMessage.content}
                              </p>

                              {conversation.unreadCount > 0 && (
                                <Badge className="mt-1">{conversation.unreadCount} new</Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      )
                    })
                  ) : (
                    <div className="p-8 text-center text-muted-foreground">
                      <p>No conversations found</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Conversation detail */}
              <div
                className={`col-span-1 md:col-span-1 lg:col-span-2 ${!selectedConversation ? "hidden md:flex" : ""} flex flex-col h-full`}
              >
                {selectedConversation ? (
                  <>
                    <div className="sticky top-14 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10 border-b p-4">
                      <div className="flex items-center gap-3">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="md:hidden"
                          onClick={() => setSelectedConversation(null)}
                        >
                          <ArrowLeft className="h-5 w-5" />
                        </Button>

                        <Avatar>
                          <AvatarImage
                            src={selectedConversation.participants.find((p) => p.id !== currentUser.id)?.avatar}
                          />
                          <AvatarFallback>
                            {selectedConversation.participants.find((p) => p.id !== currentUser.id)?.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>

                        <div className="flex-1">
                          <div className="flex items-center gap-1">
                            <span className="font-semibold">
                              {selectedConversation.participants.find((p) => p.id !== currentUser.id)?.name}
                            </span>
                            {selectedConversation.participants.find((p) => p.id !== currentUser.id)?.verified && (
                              <Verified className="h-4 w-4 text-primary" />
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            @{selectedConversation.participants.find((p) => p.id !== currentUser.id)?.username}
                          </p>
                        </div>

                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                      <div className="flex justify-start">
                        <div className="bg-accent rounded-lg p-3 max-w-[80%]">
                          <p>{selectedConversation.lastMessage.content}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {selectedConversation.lastMessage.timestamp}
                          </p>
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <div className="bg-primary text-primary-foreground rounded-lg p-3 max-w-[80%]">
                          <p>
                            Thank you for reaching out! I'd be happy to discuss our offerings and potential partnership
                            opportunities.
                          </p>
                          <p className="text-xs text-primary-foreground/70 mt-1">now</p>
                        </div>
                      </div>

                      <div className="flex justify-start">
                        <div className="bg-accent rounded-lg p-3 max-w-[80%]">
                          <p>
                            Great! Let's schedule a call next week to go over the details. What times work best for you?
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">just now</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 border-t">
                      <div className="flex gap-2">
                        <Button variant="ghost" size="icon">
                          <Paperclip className="h-5 w-5" />
                        </Button>

                        <Input
                          placeholder="Start a new message"
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          className="flex-1"
                        />

                        <Button variant="ghost" size="icon">
                          <Smile className="h-5 w-5" />
                        </Button>

                        <Button size="icon" onClick={handleSendMessage} disabled={!newMessage.trim()}>
                          <Send className="h-5 w-5" />
                        </Button>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center p-8">
                      <h2 className="text-2xl font-bold mb-2">Select a conversation</h2>
                      <p className="text-muted-foreground">Choose a conversation from the list or start a new one</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

