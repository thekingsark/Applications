import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { trends } from "../mock-data"

export default function TrendingSection() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl">Trends for you</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {trends.slice(0, 5).map((trend) => (
          <Link
            key={trend.id}
            href={`/social/search?q=${encodeURIComponent(trend.name)}`}
            className="block hover:bg-muted/50 -mx-2 px-2 py-1 rounded-md transition-colors"
          >
            <div className="text-xs text-muted-foreground">{trend.category}</div>
            <div className="font-semibold">{trend.name}</div>
            <div className="text-xs text-muted-foreground">{trend.posts.toLocaleString()} posts</div>
          </Link>
        ))}
        <Link href="/social/trends" className="block text-primary text-sm hover:underline">
          Show more
        </Link>
      </CardContent>
    </Card>
  )
}

