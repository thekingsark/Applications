"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Heart, MessageCircle, Repeat, Share, MoreHorizontal, Bookmark } from "lucide-react"
import Link from "next/link"
import type { Post } from "@/types/x-clone"

interface PostCardProps {
  post: Post
}

export default function PostCard({ post }: PostCardProps) {
  const [liked, setLiked] = useState(post.liked || false)
  const [reposted, setReposted] = useState(post.reposted || false)
  const [bookmarked, setBookmarked] = useState(post.bookmarked || false)
  const [likeCount, setLikeCount] = useState(post.likes)
  const [repostCount, setRepostCount] = useState(post.reposts)

  const handleLike = () => {
    if (liked) {
      setLikeCount(likeCount - 1)
    } else {
      setLikeCount(likeCount + 1)
    }
    setLiked(!liked)
  }

  const handleRepost = () => {
    if (reposted) {
      setRepostCount(repostCount - 1)
    } else {
      setRepostCount(repostCount + 1)
    }
    setReposted(!reposted)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  return (
    <Card className="border-x-0 border-t-0 rounded-none hover:bg-muted/30 transition-colors">
      <CardContent className="p-4">
        <div className="flex gap-3">
          <Link href={`/social/profile/${post.author.username}`} className="flex-shrink-0">
            <div className="w-10 h-10 rounded-full overflow-hidden">
              <img
                src={post.author.profileImage || "/placeholder.svg"}
                alt={post.author.name}
                className="w-full h-full object-cover"
              />
            </div>
          </Link>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-sm">
                <Link href={`/social/profile/${post.author.username}`} className="font-bold hover:underline">
                  {post.author.name}
                </Link>
                {post.author.verified && (
                  <span className="text-blue-500">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                      <path
                        fillRule="evenodd"
                        d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </span>
                )}
                <span className="text-muted-foreground">@{post.author.username}</span>
                <span className="text-muted-foreground">·</span>
                <span className="text-muted-foreground">{formatDate(post.createdAt)}</span>
              </div>

              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreHorizontal className="h-4 w-4" />
                <span className="sr-only">More options</span>
              </Button>
            </div>

            <div className="mt-1">
              <p className="whitespace-pre-wrap">{post.content}</p>

              {post.images && post.images.length > 0 && (
                <div className={`mt-3 grid gap-2 ${post.images.length > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
                  {post.images.map((image, index) => (
                    <div key={index} className="rounded-xl overflow-hidden bg-muted">
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`Post image ${index + 1}`}
                        className="w-full h-auto object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>

      <CardFooter className="p-0 px-4 pb-2">
        <div className="flex justify-between w-full text-muted-foreground">
          <Button variant="ghost" size="sm" className="gap-1" onClick={() => {}}>
            <MessageCircle className="h-4 w-4" />
            <span className="text-xs">{post.replies}</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            className={`gap-1 ${reposted ? "text-green-500" : ""}`}
            onClick={handleRepost}
          >
            <Repeat className="h-4 w-4" />
            <span className="text-xs">{repostCount}</span>
          </Button>

          <Button variant="ghost" size="sm" className={`gap-1 ${liked ? "text-red-500" : ""}`} onClick={handleLike}>
            <Heart className="h-4 w-4" />
            <span className="text-xs">{likeCount}</span>
          </Button>

          <Button
            variant="ghost"
            size="sm"
            className={`gap-1 ${bookmarked ? "text-blue-500" : ""}`}
            onClick={() => setBookmarked(!bookmarked)}
          >
            <Bookmark className="h-4 w-4" />
          </Button>

          <Button variant="ghost" size="sm" className="gap-1">
            <Share className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

