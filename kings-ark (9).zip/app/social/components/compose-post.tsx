"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Image, Video, BarChart2, MapPin, Calendar, Smile } from "lucide-react"
import { currentUser } from "../mock-data"

export default function ComposePost() {
  const [content, setContent] = useState("")
  const [images, setImages] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleSubmit = async () => {
    if (!content.trim() && images.length === 0) return

    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Reset form
    setContent("")
    setImages([])
    setIsSubmitting(false)
  }

  const handleImageUpload = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    // In a real app, you would upload these to a server
    // For demo purposes, we'll use placeholder images
    const newImages = Array.from(files).map(
      (_, index) => `/placeholder.svg?height=400&width=600&text=Image+${images.length + index + 1}`,
    )

    setImages([...images, ...newImages])
  }

  return (
    <div className="border-b p-4">
      <div className="flex gap-3">
        <div className="flex-shrink-0">
          <div className="w-10 h-10 rounded-full overflow-hidden">
            <img
              src={currentUser.profileImage || "/placeholder.svg"}
              alt={currentUser.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        <div className="flex-1">
          <Textarea
            placeholder="What's happening in your business world?"
            className="border-0 focus-visible:ring-0 resize-none text-lg p-0 h-auto min-h-[80px]"
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />

          {images.length > 0 && (
            <div className={`mt-3 grid gap-2 ${images.length > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
              {images.map((image, index) => (
                <div key={index} className="relative rounded-xl overflow-hidden bg-muted">
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`Upload ${index + 1}`}
                    className="w-full h-auto object-cover"
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-1 right-1 h-6 w-6 rounded-full"
                    onClick={() => setImages(images.filter((_, i) => i !== index))}
                  >
                    ×
                  </Button>
                </div>
              ))}
            </div>
          )}

          <div className="mt-4 flex items-center justify-between">
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" onClick={handleImageUpload}>
                <Image className="h-5 w-5 text-primary" />
                <span className="sr-only">Add image</span>
              </Button>
              <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/*"
                multiple
                onChange={handleFileChange}
              />

              <Button variant="ghost" size="icon">
                <Video className="h-5 w-5 text-primary" />
                <span className="sr-only">Add video</span>
              </Button>

              <Button variant="ghost" size="icon">
                <BarChart2 className="h-5 w-5 text-primary" />
                <span className="sr-only">Add poll</span>
              </Button>

              <Button variant="ghost" size="icon">
                <Smile className="h-5 w-5 text-primary" />
                <span className="sr-only">Add emoji</span>
              </Button>

              <Button variant="ghost" size="icon">
                <Calendar className="h-5 w-5 text-primary" />
                <span className="sr-only">Schedule</span>
              </Button>

              <Button variant="ghost" size="icon">
                <MapPin className="h-5 w-5 text-primary" />
                <span className="sr-only">Add location</span>
              </Button>
            </div>

            <Button
              disabled={(!content.trim() && images.length === 0) || isSubmitting}
              onClick={handleSubmit}
              className="rounded-full"
            >
              {isSubmitting ? "Posting..." : "Post"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

