"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Bell, Bookmark, Home, Mail, Search, User, MoreHorizontal } from "lucide-react"
import Link from "next/link"
import { currentUser } from "../mock-data"
import SpinningCrownLogo from "@/components/spinning-crown-logo"

export default function XHeader() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
      <div className="flex items-center justify-between h-14 px-4">
        <div className="flex items-center">
          <Link href="/social" className="mr-4 flex items-center">
            <SpinningCrownLogo size={30} className="text-primary" />
            <span className="ml-2 font-bold hidden md:inline">Kings Ark Social</span>
          </Link>
        </div>

        <div className="hidden md:flex relative max-w-xs w-full mx-4">
          <div className="relative w-full">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search Kings Ark Social"
              className="w-full bg-muted pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center space-x-1">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/social">
              <Home className="h-5 w-5" />
              <span className="sr-only">Home</span>
            </Link>
          </Button>

          <Button variant="ghost" size="icon" asChild>
            <Link href="/social/notifications">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Link>
          </Button>

          <Button variant="ghost" size="icon" asChild>
            <Link href="/social/messages">
              <Mail className="h-5 w-5" />
              <span className="sr-only">Messages</span>
            </Link>
          </Button>

          <Button variant="ghost" size="icon" asChild>
            <Link href="/social/bookmarks">
              <Bookmark className="h-5 w-5" />
              <span className="sr-only">Bookmarks</span>
            </Link>
          </Button>

          <Button variant="ghost" size="icon" asChild>
            <Link href="/social/profile">
              <User className="h-5 w-5" />
              <span className="sr-only">Profile</span>
            </Link>
          </Button>

          <Button variant="ghost" size="icon">
            <MoreHorizontal className="h-5 w-5" />
            <span className="sr-only">More</span>
          </Button>

          <Button variant="ghost" size="sm" className="ml-2">
            <div className="w-8 h-8 rounded-full overflow-hidden">
              <img
                src={currentUser.profileImage || "/placeholder.svg"}
                alt={currentUser.name}
                className="w-full h-full object-cover"
              />
            </div>
          </Button>
        </div>
      </div>
    </header>
  )
}

