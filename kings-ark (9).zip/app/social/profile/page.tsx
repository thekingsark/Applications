"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Calendar, LinkIcon, MapPin } from "lucide-react"
import XHeader from "../components/x-header"
import PostCard from "../components/post-card"
import { currentUser, posts } from "../mock-data"

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("posts")
  const user = currentUser

  return (
    <div className="min-h-screen bg-background">
      <XHeader />

      <div className="container mx-auto max-w-3xl">
        <div className="border-x min-h-screen">
          {/* Profile header */}
          <div className="relative">
            {/* Cover image */}
            <div className="h-48 bg-gradient-to-r from-blue-400 to-blue-600"></div>

            {/* Profile image */}
            <div className="absolute left-4 -bottom-16 border-4 border-background rounded-full">
              <div className="w-32 h-32 rounded-full overflow-hidden">
                <img
                  src={user.profileImage || "/placeholder.svg"}
                  alt={user.name}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Edit profile button */}
            <div className="absolute right-4 bottom-4">
              <Button variant="outline" className="rounded-full">
                Edit profile
              </Button>
            </div>
          </div>

          {/* Profile info */}
          <div className="mt-20 px-4">
            <div className="mb-4">
              <div className="flex items-center gap-1">
                <h1 className="text-xl font-bold">{user.name}</h1>
                {user.verified && (
                  <span className="text-blue-500">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                      <path
                        fillRule="evenodd"
                        d="M8.603 3.799A4.49 4.49 0 0112 2.25c1.357 0 2.573.6 3.397 1.549a4.49 4.49 0 013.498 1.307 4.491 4.491 0 011.307 3.497A4.49 4.49 0 0121.75 12a4.49 4.49 0 01-1.549 3.397 4.491 4.491 0 01-1.307 3.497 4.491 4.491 0 01-3.497 1.307A4.49 4.49 0 0112 21.75a4.49 4.49 0 01-3.397-1.549 4.49 4.49 0 01-3.498-1.306 4.491 4.491 0 01-1.307-3.498A4.49 4.49 0 012.25 12c0-1.357.6-2.573 1.549-3.397a4.49 4.49 0 011.307-3.497 4.49 4.49 0 013.497-1.307zm7.007 6.387a.75.75 0 10-1.22-.872l-3.236 4.53L9.53 12.22a.75.75 0 00-1.06 1.06l2.25 2.25a.75.75 0 001.14-.094l3.75-5.25z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </span>
                )}
              </div>
              <p className="text-muted-foreground">@{user.username}</p>
            </div>

            <div className="mb-4">
              <p>{user.bio}</p>
            </div>

            <div className="flex flex-wrap gap-x-4 gap-y-2 text-sm text-muted-foreground mb-4">
              {user.company && (
                <div className="flex items-center gap-1">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                    <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                  </svg>
                  <span>{user.company}</span>
                </div>
              )}

              {user.location && (
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  <span>{user.location}</span>
                </div>
              )}

              {user.website && (
                <div className="flex items-center gap-1">
                  <LinkIcon className="h-4 w-4" />
                  <a
                    href={`https://${user.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    {user.website}
                  </a>
                </div>
              )}

              {user.joinedDate && (
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  <span>Joined {user.joinedDate}</span>
                </div>
              )}
            </div>

            <div className="flex gap-4 text-sm mb-4">
              <div>
                <span className="font-bold">{user.following}</span>{" "}
                <span className="text-muted-foreground">Following</span>
              </div>
              <div>
                <span className="font-bold">{user.followers}</span>{" "}
                <span className="text-muted-foreground">Followers</span>
              </div>
            </div>
          </div>

          {/* Profile tabs */}
          <Tabs defaultValue="posts" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full grid grid-cols-4 rounded-none h-12 border-b">
              <TabsTrigger
                value="posts"
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
              >
                Posts
              </TabsTrigger>
              <TabsTrigger
                value="replies"
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
              >
                Replies
              </TabsTrigger>
              <TabsTrigger
                value="media"
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
              >
                Media
              </TabsTrigger>
              <TabsTrigger
                value="likes"
                className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
              >
                Likes
              </TabsTrigger>
            </TabsList>

            <TabsContent value="posts" className="mt-0 p-0">
              <div>
                {posts
                  .filter((post) => post.author.id === user.id)
                  .map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="replies" className="mt-0 p-0">
              <div className="p-4 text-center text-muted-foreground">No replies yet</div>
            </TabsContent>

            <TabsContent value="media" className="mt-0 p-0">
              <div>
                {posts
                  .filter((post) => post.author.id === user.id && post.images && post.images.length > 0)
                  .map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="likes" className="mt-0 p-0">
              <div>
                {posts
                  .filter((post) => post.liked)
                  .map((post) => (
                    <PostCard key={post.id} post={post} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

