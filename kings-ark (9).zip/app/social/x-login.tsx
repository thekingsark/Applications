import { Button } from "@/components/ui/button"

export default function XLoginPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="text-4xl font-bold mb-8">X</div>
      <h2 className="text-2xl font-semibold mb-4">Happening now</h2>
      <div className="mb-6">
        <h3 className="text-xl font-semibold mb-2">Join today.</h3>
        <Button className="w-full mb-2">Sign up with Apple</Button>
        <div className="text-center text-gray-500">or</div>
        <Button className="w-full">Create account</Button>
        <p className="text-xs text-gray-500 mt-2">
          By signing up, you agree to the Terms of Service and Privacy Policy, including Cookie Use.
        </p>
      </div>
      <div>
        <h3 className="text-xl font-semibold mb-2">Already have an account?</h3>
        <Button variant="outline" className="w-full">
          Sign in
        </Button>
      </div>
      <div className="mt-8 text-xs text-gray-500">
        <a href="#" className="mr-2">
          About
        </a>
        <a href="#" className="mr-2">
          Download the X app
        </a>
        <a href="#" className="mr-2">
          Help Center
        </a>
        <a href="#" className="mr-2">
          Terms of Service
        </a>
        <a href="#" className="mr-2">
          Privacy Policy
        </a>
        <a href="#" className="mr-2">
          Cookie Policy
        </a>
        <a href="#" className="mr-2">
          Accessibility
        </a>
        <a href="#" className="mr-2">
          Ads info
        </a>
        <a href="#" className="mr-2">
          Blog
        </a>
        <a href="#" className="mr-2">
          Careers
        </a>
        <a href="#" className="mr-2">
          Brand Resources
        </a>
        <a href="#" className="mr-2">
          Advertising
        </a>
        <a href="#" className="mr-2">
          Marketing
        </a>
        <a href="#" className="mr-2">
          X for Business
        </a>
        <a href="#" className="mr-2">
          Developers
        </a>
        <a href="#" className="mr-2">
          Directory
        </a>
        <a href="#" className="mr-2">
          Settings
        </a>
        <span>© 2025 X Corp.</span>
      </div>
    </div>
  )
}

