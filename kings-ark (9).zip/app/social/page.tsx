"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Bookmark,
  User,
  MoreHorizontal,
  Heart,
  Repeat,
  MessageCircle,
  Share,
  ImageIcon,
  BarChart,
  Calendar,
  MapPin,
  X,
  Send,
  Paperclip,
  Smile,
  Flag,
  VolumeX,
  ArrowLeft,
  Loader2,
  Verified,
  Play,
  Home,
} from "lucide-react"
import type { SocialUser, Post, Trend, Notification, Conversation } from "@/types/social"
import {
  generateSocialUsers,
  generatePosts,
  generateTrends,
  generateNotifications,
  generateConversations,
  getWhoToFollowSuggestions,
} from "./social-data"
import SpinningCrownLogo from "@/components/spinning-crown-logo"
import XHeader from "./components/x-header"
import ComposePost from "./components/compose-post"
import PostCard from "./components/post-card"
import TrendingSection from "./components/trending-section"
import WhoToFollow from "./components/who-to-follow"
import { posts } from "./mock-data"

export default function SocialMediaPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [activeTab, setActiveTab] = useState("for-you")
  const [users, setUsers] = useState<SocialUser[]>([])
  const [postsData, setPostsData] = useState<Post[]>([])
  const [trends, setTrends] = useState<Trend[]>([])
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [whoToFollow, setWhoToFollow] = useState<SocialUser[]>([])
  const [newPostContent, setNewPostContent] = useState("")
  const [newPostImages, setNewPostImages] = useState<string[]>([])
  const [isPostingLoading, setIsPostingLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedView, setSelectedView] = useState("home")
  const [currentUser, setCurrentUser] = useState<SocialUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showComposeDialog, setShowComposeDialog] = useState(false)
  const [selectedPost, setSelectedPost] = useState<Post | null>(null)
  const [showPostDetail, setShowPostDetail] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [showMessages, setShowMessages] = useState(false)
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)
  const [newMessage, setNewMessage] = useState("")
  const timelineRef = useRef<HTMLDivElement>(null)

  // Initialize data
  useEffect(() => {
    const initializeData = () => {
      setIsLoading(true)
      const generatedUsers = generateSocialUsers()
      setUsers(generatedUsers)
      setCurrentUser(generatedUsers[0]) // Set first user as current user

      const generatedPosts = generatePosts(generatedUsers)
      setPostsData(generatedPosts)

      setTrends(generateTrends())
      setNotifications(generateNotifications(generatedUsers, generatedPosts))
      setConversations(generateConversations(generatedUsers))
      setWhoToFollow(getWhoToFollowSuggestions(generatedUsers))

      setIsLoading(false)
    }

    initializeData()
  }, [])

  // Handle post interactions
  const handleLike = (postId: string) => {
    setPostsData((prevPosts) =>
      prevPosts.map((post) => {
        if (post.id === postId) {
          const hasLiked = !post.hasLiked
          return {
            ...post,
            hasLiked,
            likes: hasLiked ? post.likes + 1 : post.likes - 1,
          }
        }
        return post
      }),
    )
  }

  const handleRepost = (postId: string) => {
    setPostsData((prevPosts) =>
      prevPosts.map((post) => {
        if (post.id === postId) {
          const hasReposted = !post.hasReposted
          return {
            ...post,
            hasReposted,
            reposts: hasReposted ? post.reposts + 1 : post.reposts - 1,
          }
        }
        return post
      }),
    )
  }

  const handleReply = (post: Post) => {
    setSelectedPost(post)
    setShowPostDetail(true)
  }

  const handleShare = (postId: string) => {
    // Implement share functionality
    alert(`Sharing post ${postId}`)
  }

  // Handle new post submission
  const handleSubmitPost = () => {
    if (!newPostContent.trim() && newPostImages.length === 0) return

    setIsPostingLoading(true)

    // Simulate API call
    setTimeout(() => {
      const newPost: Post = {
        id: `post-${Date.now()}`,
        content: newPostContent,
        author: currentUser!,
        timestamp: "now",
        likes: 0,
        reposts: 0,
        replies: 0,
        views: 0,
        hasLiked: false,
        hasReposted: false,
        images: newPostImages.length > 0 ? newPostImages : undefined,
        hashtags: newPostContent.match(/#\w+/g) || [],
      }

      setPostsData((prevPosts) => [newPost, ...prevPosts])
      setNewPostContent("")
      setNewPostImages([])
      setShowComposeDialog(false)
      setIsPostingLoading(false)
    }, 1000)
  }

  // Handle image upload
  const handleImageUpload = () => {
    // Simulate image upload
    const newImage = `/placeholder.svg?height=400&width=600&text=Uploaded+Image+${newPostImages.length + 1}`
    setNewPostImages((prev) => [...prev, newImage])
  }

  // Handle message send
  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedConversation) return

    // Simulate sending message
    const message = {
      id: `msg-new-${Date.now()}`,
      sender: currentUser!,
      recipient: selectedConversation.participants.find((p) => p.id !== currentUser!.id)!,
      content: newMessage,
      timestamp: "now",
      read: false,
    }

    setConversations((prevConversations) =>
      prevConversations.map((conv) => {
        if (conv.id === selectedConversation.id) {
          return {
            ...conv,
            lastMessage: message,
            unreadCount: 0,
          }
        }
        return conv
      }),
    )

    setNewMessage("")
  }

  // Render post component
  const renderPost = (post: Post) => {
    return (
      <div key={post.id} className="border-b p-4 hover:bg-accent/5 transition-colors">
        {post.isRepost && (
          <div className="flex items-center text-muted-foreground text-sm mb-2">
            <Repeat className="h-4 w-4 mr-2" />
            <span>{post.author.name} reposted</span>
          </div>
        )}

        <div className="flex gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={post.isRepost ? post.originalPost!.author.avatar : post.author.avatar} />
            <AvatarFallback>
              {post.isRepost ? post.originalPost!.author.name.charAt(0) : post.author.name.charAt(0)}
            </AvatarFallback>
          </Avatar>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 flex-wrap">
              <span className="font-semibold truncate">
                {post.isRepost ? post.originalPost!.author.name : post.author.name}
              </span>

              {(post.isRepost ? post.originalPost!.author.verified : post.author.verified) && (
                <Verified className="h-4 w-4 text-primary" />
              )}

              <span className="text-muted-foreground">
                @{post.isRepost ? post.originalPost!.author.username : post.author.username}
              </span>

              <span className="text-muted-foreground">·</span>

              <span className="text-muted-foreground">{post.timestamp}</span>

              <div className="ml-auto">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Bookmark className="h-4 w-4 mr-2" />
                      Bookmark
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <User className="h-4 w-4 mr-2" />
                      View Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <VolumeX className="h-4 w-4 mr-2" />
                      Mute
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Flag className="h-4 w-4 mr-2" />
                      Report
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>

            {post.isReply && (
              <div className="text-sm text-muted-foreground mb-1">Replying to @{post.mentions?.[0]}</div>
            )}

            <div className="mt-1 whitespace-pre-wrap">{post.isRepost ? post.originalPost!.content : post.content}</div>

            {(post.isRepost ? post.originalPost!.hashtags : post.hashtags)?.length > 0 && (
              <div className="mt-1 flex flex-wrap gap-1">
                {(post.isRepost ? post.originalPost!.hashtags : post.hashtags)?.map((tag) => (
                  <Link
                    href={`/social/hashtag/${tag.replace("#", "")}`}
                    key={tag}
                    className="text-primary hover:underline"
                  >
                    {tag}
                  </Link>
                ))}
              </div>
            )}

            {(post.isRepost ? post.originalPost!.images : post.images)?.length > 0 && (
              <div
                className={`mt-3 grid gap-2 ${(post.isRepost ? post.originalPost!.images : post.images)!.length > 1 ? "grid-cols-2" : "grid-cols-1"} rounded-xl overflow-hidden border`}
              >
                {(post.isRepost ? post.originalPost!.images : post.images)!.map((img, i) => (
                  <div key={i} className="relative aspect-video">
                    <Image src={img || "/placeholder.svg"} alt="Post image" fill className="object-cover" />
                  </div>
                ))}
              </div>
            )}

            {(post.isRepost ? post.originalPost!.video : post.video) && (
              <div className="mt-3 relative aspect-video rounded-xl overflow-hidden border">
                <div className="absolute inset-0 flex items-center justify-center bg-black/10">
                  <Play className="h-12 w-12 text-white" />
                </div>
                <Image
                  src={(post.isRepost ? post.originalPost!.video : post.video)!}
                  alt="Post video"
                  fill
                  className="object-cover"
                />
              </div>
            )}

            <div className="flex justify-between mt-3">
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-primary hover:bg-primary/10"
                onClick={() => handleReply(post)}
              >
                <MessageCircle className={`h-4 w-4 mr-2`} />
                <span>{post.replies}</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                className={`${post.hasReposted ? "text-green-500" : "text-muted-foreground"} hover:text-green-500 hover:bg-green-500/10`}
                onClick={() => handleRepost(post.id)}
              >
                <Repeat className={`h-4 w-4 mr-2 ${post.hasReposted ? "fill-green-500" : ""}`} />
                <span>{post.reposts}</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                className={`${post.hasLiked ? "text-red-500" : "text-muted-foreground"} hover:text-red-500 hover:bg-red-500/10`}
                onClick={() => handleLike(post.id)}
              >
                <Heart className={`h-4 w-4 mr-2 ${post.hasLiked ? "fill-red-500" : ""}`} />
                <span>{post.likes}</span>
              </Button>

              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-primary hover:bg-primary/10"
                onClick={() => handleShare(post.id)}
              >
                <Share className="h-4 w-4 mr-2" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Loading state
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <SpinningCrownLogo size={48} />
          <h2 className="mt-4 text-xl font-semibold">Loading B2B Social Media...</h2>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <XHeader />

      <div className="container mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-0">
          {/* Left sidebar - hidden on mobile */}
          <div className="hidden md:block md:col-span-1">
            <div className="sticky top-14 p-4">
              {/* Replace the X icon with a glowing Back to Home link */}
              <Link
                href="/"
                className="flex items-center gap-2 mb-6 px-4 py-2 rounded-full bg-gradient-to-r from-primary/80 to-primary text-primary-foreground shadow-lg hover:shadow-primary/50 transition-all duration-300 animate-pulse"
              >
                <Home className="h-5 w-5" />
                <span className="font-bold">Back to Home</span>
              </Link>

              <nav className="space-y-2">
                <a
                  href="/social"
                  className="flex items-center gap-4 text-xl font-bold p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Home
                </a>
                <a
                  href="/social/explore"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Explore
                </a>
                <a
                  href="/social/notifications"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Notifications
                </a>
                <a
                  href="/social/messages"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Messages
                </a>
                <a
                  href="/social/bookmarks"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Bookmarks
                </a>
                <a
                  href="/social/profile"
                  className="flex items-center gap-4 text-xl p-2 rounded-full hover:bg-muted transition-colors"
                >
                  Profile
                </a>
              </nav>
            </div>
          </div>

          {/* Main content */}
          <div className="col-span-1 md:col-span-2 border-x min-h-screen">
            <div className="sticky top-14 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10 border-b">
              <div className="px-4 py-3">
                <h1 className="text-xl font-bold">Home</h1>
              </div>

              <Tabs defaultValue="for-you" value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="w-full grid grid-cols-2 rounded-none h-12">
                  <TabsTrigger
                    value="for-you"
                    className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
                  >
                    For you
                  </TabsTrigger>
                  <TabsTrigger
                    value="following"
                    className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none"
                  >
                    Following
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="for-you" className="mt-0 p-0">
                  <ComposePost />
                  <div>
                    {posts.map((post) => (
                      <PostCard key={post.id} post={post} />
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="following" className="mt-0 p-0">
                  <ComposePost />
                  <div>
                    {posts
                      .filter((_, index) => index % 2 === 0)
                      .map((post) => (
                        <PostCard key={post.id} post={post} />
                      ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>

          {/* Right sidebar - hidden on mobile and tablet */}
          <div className="hidden lg:block lg:col-span-1">
            <div className="sticky top-14 p-4 space-y-4">
              <div className="mb-4">
                <div className="relative">
                  <input type="search" placeholder="Search" className="w-full bg-muted rounded-full py-2 px-4 pl-10" />
                  <div className="absolute left-3 top-2.5">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-muted-foreground"
                    >
                      <circle cx="11" cy="11" r="8"></circle>
                      <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                  </div>
                </div>
              </div>

              <TrendingSection />
              <WhoToFollow />

              <div className="text-xs text-muted-foreground">
                <div className="flex flex-wrap gap-x-2">
                  <a href="#" className="hover:underline">
                    Terms of Service
                  </a>
                  <a href="#" className="hover:underline">
                    Privacy Policy
                  </a>
                  <a href="#" className="hover:underline">
                    Cookie Policy
                  </a>
                  <a href="#" className="hover:underline">
                    Accessibility
                  </a>
                  <a href="#" className="hover:underline">
                    Ads Info
                  </a>
                  <a href="#" className="hover:underline">
                    More
                  </a>
                </div>
                <div className="mt-1">© 2025 Kings Ark B2B X</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Compose Dialog */}
      <Dialog open={showComposeDialog} onOpenChange={setShowComposeDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Create a post</DialogTitle>
            <DialogDescription>Share updates, news, or insights with your business network</DialogDescription>
          </DialogHeader>

          <div className="flex gap-3 mt-4">
            <Avatar>
              <AvatarImage src={currentUser?.avatar} />
              <AvatarFallback>{currentUser?.name.charAt(0)}</AvatarFallback>
            </Avatar>

            <div className="flex-1">
              <Textarea
                placeholder="What's happening in your business world?"
                className="border-none resize-none focus-visible:ring-0 p-0 text-lg min-h-[120px]"
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
              />

              {newPostImages.length > 0 && (
                <div
                  className={`mt-3 grid gap-2 ${newPostImages.length > 1 ? "grid-cols-2" : "grid-cols-1"} rounded-xl overflow-hidden border`}
                >
                  {newPostImages.map((img, i) => (
                    <div key={i} className="relative aspect-video group">
                      <Image src={img || "/placeholder.svg"} alt="Post image" fill className="object-cover" />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => setNewPostImages((prev) => prev.filter((_, index) => index !== i))}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-center justify-between mt-4">
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon" onClick={handleImageUpload}>
                    <ImageIcon className="h-5 w-5 text-primary" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <BarChart className="h-5 w-5 text-primary" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Smile className="h-5 w-5 text-primary" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Calendar className="h-5 w-5 text-primary" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MapPin className="h-5 w-5 text-primary" />
                  </Button>
                </div>

                <Button
                  disabled={(!newPostContent.trim() && newPostImages.length === 0) || isPostingLoading}
                  onClick={handleSubmitPost}
                >
                  {isPostingLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
                  Post
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Post Detail Dialog */}
      <Dialog open={showPostDetail} onOpenChange={setShowPostDetail}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle>Post</DialogTitle>
          </DialogHeader>

          {selectedPost && (
            <>
              {renderPost(selectedPost)}

              <Separator />

              <div className="flex gap-3 mt-4">
                <Avatar>
                  <AvatarImage src={currentUser?.avatar} />
                  <AvatarFallback>{currentUser?.name.charAt(0)}</AvatarFallback>
                </Avatar>

                <div className="flex-1">
                  <Textarea
                    placeholder={`Reply to @${selectedPost.author.username}`}
                    className="border-none resize-none focus-visible:ring-0 p-0"
                  />

                  <div className="flex items-center justify-between mt-4">
                    <div className="flex gap-2">
                      <Button variant="ghost" size="icon">
                        <ImageIcon className="h-5 w-5 text-primary" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Smile className="h-5 w-5 text-primary" />
                      </Button>
                    </div>

                    <Button>Reply</Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Notifications Dialog */}
      <Dialog open={showNotifications} onOpenChange={setShowNotifications}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Notifications</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 mt-4 max-h-[60vh] overflow-y-auto">
            {notifications.map((notification) => (
              <div
                key={notification.id}
                className={`flex gap-3 p-2 rounded-lg ${notification.read ? "" : "bg-primary/5"}`}
              >
                <Avatar>
                  <AvatarImage src={notification.actor.avatar} />
                  <AvatarFallback>{notification.actor.name.charAt(0)}</AvatarFallback>
                </Avatar>

                <div className="flex-1">
                  <div className="flex items-center gap-1">
                    <span className="font-semibold">{notification.actor.name}</span>
                    {notification.actor.verified && <Verified className="h-4 w-4 text-primary" />}
                  </div>

                  {notification.type === "like" && <p>liked your post</p>}

                  {notification.type === "repost" && <p>reposted your post</p>}

                  {notification.type === "reply" && <p>replied to your post</p>}

                  {notification.type === "mention" && <p>mentioned you in a post</p>}

                  {notification.type === "follow" && <p>followed you</p>}

                  <p className="text-sm text-muted-foreground">{notification.timestamp}</p>

                  {notification.post && (
                    <div className="mt-2 p-3 border rounded-lg">
                      <p className="line-clamp-2">{notification.post.content}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Messages Dialog */}
      <Dialog open={showMessages} onOpenChange={setShowMessages}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Messages</DialogTitle>
          </DialogHeader>

          {!selectedConversation ? (
            <div className="space-y-4 mt-4 max-h-[60vh] overflow-y-auto">
              {conversations.map((conversation) => {
                const otherUser = conversation.participants.find((p) => p.id !== currentUser?.id)!

                return (
                  <div
                    key={conversation.id}
                    className={`flex gap-3 p-2 rounded-lg cursor-pointer hover:bg-accent/10 ${conversation.unreadCount > 0 ? "bg-primary/5" : ""}`}
                    onClick={() => setSelectedConversation(conversation)}
                  >
                    <Avatar>
                      <AvatarImage src={otherUser.avatar} />
                      <AvatarFallback>{otherUser.name.charAt(0)}</AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1">
                        <span className="font-semibold truncate">{otherUser.name}</span>
                        {otherUser.verified && <Verified className="h-4 w-4 text-primary" />}
                        <span className="text-sm text-muted-foreground ml-auto">
                          {conversation.lastMessage.timestamp}
                        </span>
                      </div>

                      <p className="text-sm truncate">
                        {conversation.lastMessage.sender.id === currentUser?.id ? "You: " : ""}
                        {conversation.lastMessage.content}
                      </p>

                      {conversation.unreadCount > 0 && <Badge className="mt-1">{conversation.unreadCount} new</Badge>}
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 mb-4">
                <Button variant="ghost" size="icon" onClick={() => setSelectedConversation(null)}>
                  <ArrowLeft className="h-4 w-4" />
                </Button>

                <Avatar>
                  <AvatarImage src={selectedConversation.participants.find((p) => p.id !== currentUser?.id)?.avatar} />
                  <AvatarFallback>
                    {selectedConversation.participants.find((p) => p.id !== currentUser?.id)?.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>

                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-semibold">
                      {selectedConversation.participants.find((p) => p.id !== currentUser?.id)?.name}
                    </span>
                    {selectedConversation.participants.find((p) => p.id !== currentUser?.id)?.verified && (
                      <Verified className="h-4 w-4 text-primary" />
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    @{selectedConversation.participants.find((p) => p.id !== currentUser?.id)?.username}
                  </p>
                </div>

                <Button variant="ghost" size="icon" className="ml-auto">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </div>

              <div className="h-[40vh] overflow-y-auto border rounded-lg p-4 space-y-4">
                {/* Placeholder for message history */}
                <div className="flex justify-start">
                  <div className="bg-accent rounded-lg p-3 max-w-[80%]">
                    <p>{selectedConversation.lastMessage.content}</p>
                    <p className="text-xs text-muted-foreground mt-1">{selectedConversation.lastMessage.timestamp}</p>
                  </div>
                </div>

                <div className="flex justify-end">
                  <div className="bg-primary text-primary-foreground rounded-lg p-3 max-w-[80%]">
                    <p>
                      Thank you for reaching out! I'd be happy to discuss our offerings and potential partnership
                      opportunities.
                    </p>
                    <p className="text-xs text-primary-foreground/70 mt-1">now</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                <Button variant="ghost" size="icon">
                  <Paperclip className="h-5 w-5" />
                </Button>

                <Input
                  placeholder="Type a message"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1"
                />

                <Button size="icon" onClick={handleSendMessage} disabled={!newMessage.trim()}>
                  <Send className="h-5 w-5" />
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

