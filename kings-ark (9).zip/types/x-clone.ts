export interface User {
  id: string
  name: string
  username: string
  profileImage: string
  bio?: string
  following: number
  followers: number
  verified: boolean
  company?: string
  industry?: string
  location?: string
  website?: string
  joinedDate: string
}

export interface Post {
  id: string
  content: string
  images?: string[]
  video?: string
  createdAt: string
  author: User
  likes: number
  reposts: number
  replies: number
  views: number
  liked?: boolean
  reposted?: boolean
  replied?: boolean
  bookmarked?: boolean
}

export interface Trend {
  id: string
  name: string
  posts: number
  category: string
}

export interface Notification {
  id: string
  type: "like" | "repost" | "reply" | "mention" | "follow"
  user: User
  post?: Post
  createdAt: string
  read: boolean
}

export interface Message {
  id: string
  sender: User
  recipient: User
  content: string
  createdAt: string
  read: boolean
}

export interface Conversation {
  id: string
  participants: User[]
  lastMessage: Message
  unreadCount: number
}

