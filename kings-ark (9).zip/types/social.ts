import type { Partner } from "@/types"

export interface SocialUser {
  id: string
  name: string
  username: string
  avatar: string
  bio: string
  verified: boolean
  following: number
  followers: number
  joined: string
  location?: string
  website?: string
  partner?: Partner
}

export interface Post {
  id: string
  content: string
  author: SocialUser
  timestamp: string
  likes: number
  reposts: number
  replies: number
  views: number
  images?: string[]
  video?: string
  poll?: Poll
  hasLiked?: boolean
  hasReposted?: boolean
  isReply?: boolean
  replyTo?: string
  isRepost?: boolean
  originalPost?: Post
  hashtags?: string[]
  mentions?: string[]
}

export interface Poll {
  id: string
  question: string
  options: PollOption[]
  expiresAt: string
  totalVotes: number
  voted?: boolean
}

export interface PollOption {
  id: string
  text: string
  votes: number
  percentage: number
}

export interface Trend {
  id: string
  name: string
  category: string
  posts: number
}

export interface Notification {
  id: string
  type: "like" | "repost" | "reply" | "mention" | "follow"
  actor: SocialUser
  post?: Post
  timestamp: string
  read: boolean
}

export interface Message {
  id: string
  sender: SocialUser
  recipient: SocialUser
  content: string
  timestamp: string
  read: boolean
  attachments?: string[]
}

export interface Conversation {
  id: string
  participants: SocialUser[]
  lastMessage: Message
  unreadCount: number
}

