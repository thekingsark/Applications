import type React from "react"
// Core application types
export type SupportedLanguage = "en" | "es" | "fr" | "de" | "it" | "pt" | "ru" | "zh" | "ja" | "ko" | "ar" | "hi"

export interface TranslationMap {
  [key: string]: string
}

export interface LanguageMap {
  [key in SupportedLanguage]?: TranslationMap
}

export interface LoadingScreenProps {
  progress: number
}

export interface SpinningCrownLogoProps {
  size?: number
  className?: string
}

export interface BackgroundEffectsProps {
  type?: "smoke" | "particles" | "worldMap" | "none"
}

export interface MapLocation {
  id: string
  name: string
  region: string
  coordinates: { x: number; y: number }
  description: string
}

export interface AccessibilityPanelProps {
  isOpen: boolean
  onClose: () => void
}

export interface LanguageSelectorProps {
  onLanguageChange: (code: string) => void
}

export interface LanguageTranslatorProps {
  onLanguageChange: (code: string) => void
}

export interface TextToSpeechProps {
  isOpen: boolean
  onClose: () => void
}

export interface VoiceSearchProps {
  isOpen: boolean
  onClose: () => void
  onSearch: (query: string) => void
}

export interface Message {
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

export interface MenuItem {
  name: string
  href: string
  icon: React.ReactNode
  description?: string
}

export interface RightTabLink {
  name: string
  path: string
  icon: React.ReactNode
  description: string
}

export interface ExternalLink {
  name: string
  url: string
  icon?: React.ReactNode
}

export interface Partner {
  id: string
  name: string
  type: "buyer" | "seller" | "both"
  category: string
  subcategory: string
  country: string
  city: string
  coordinates: [number, number] // [latitude, longitude]
  rating: number
  verified: boolean
  description: string
  logo: string
  website: string
  contactPerson: string
  contactEmail: string
  contactPhone: string
  yearEstablished: number
  employeeCount: string
  specialties: string[]
  languages: string[]
}

