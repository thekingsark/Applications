export interface Avatar {
  id: string
  name: string
  model: string
  thumbnail: string
}

export interface User {
  id: string
  name: string
  avatar: Avatar
  position: [number, number, number]
  rotation: [number, number, number]
  speaking: boolean
  typing: boolean
  status: "online" | "away" | "busy" | "offline"
  company: string
  role: string
  country: string
}

export interface ChatMessage {
  id: string
  userId: string
  userName: string
  content: string
  timestamp: Date
  isPrivate: boolean
  recipientId?: string
}

export interface Room {
  id: string
  name: string
  description: string
  capacity: number
  currentUsers: number
  isPrivate: boolean
  password?: string
  owner: string
  thumbnail: string
}

export interface Deal {
  id: string
  title: string
  description: string
  sellerId: string
  sellerName: string
  buyerId: string
  buyerName: string
  amount: number
  currency: string
  status: "proposed" | "negotiating" | "accepted" | "rejected" | "completed"
  createdAt: Date
  updatedAt: Date
  documents: string[]
}

export interface VoiceChatProps {
  roomId: string
  userId: string
  onVoiceStatusChange: (isSpeaking: boolean) => void
}

export interface TextChatProps {
  roomId: string
  userId: string
  userName: string
  messages: ChatMessage[]
  onSendMessage: (message: string, isPrivate: boolean, recipientId?: string) => void
}

export interface ConferenceRoomProps {
  roomId: string
  userId: string
  users: User[]
  onUserMove: (position: [number, number, number], rotation: [number, number, number]) => void
}

export interface AvatarSelectorProps {
  avatars: Avatar[]
  selectedAvatar: Avatar
  onSelectAvatar: (avatar: Avatar) => void
}

export interface DealNegotiationProps {
  deal: Deal
  userId: string
  onUpdateDeal: (deal: Deal) => void
}

