export interface FundingInstitution {
  id: string
  name: string
  type: "bank" | "venture_capital" | "angel_investor" | "government" | "crowdfunding" | "private_equity" | "other"
  category: string[]
  description: string
  logo: string
  website: string
  headquarters: string
  foundedYear: number
  regions: string[]
  countries: string[]
  minimumFunding: number
  maximumFunding: number
  averageFundingSize: number
  fundingCriteria: string[]
  industries: string[]
  successStories: string[]
  contactPerson: string
  contactEmail: string
  contactPhone: string
  applicationProcess: string
  timeToFunding: string
  interestRates?: string
  equityRequirements?: string
  repaymentTerms?: string
  collateralRequirements?: string
  rating: number
  verified: boolean
}

export interface FundingRequest {
  id: string
  businessName: string
  businessType: string
  industry: string[]
  description: string
  logo?: string
  website?: string
  foundedYear: number
  headquarters: string
  country: string
  region: string
  employeeCount: string
  annualRevenue?: string
  fundingAmount: number
  fundingPurpose: string
  timeframe: string
  equityOffered?: number
  collateralAvailable?: string
  businessPlan?: boolean
  financialStatements?: boolean
  creditScore?: string
  previousFunding?: string[]
  contactPerson: string
  contactEmail: string
  contactPhone: string
  postedDate: Date
  status: "active" | "funded" | "expired" | "withdrawn"
}

export interface FundingCategory {
  id: string
  name: string
  description: string
  icon: string
}

export interface FundingRegion {
  id: string
  name: string
  countries: string[]
}

export interface FundingMessage {
  id: string
  senderId: string
  senderType: "business" | "institution"
  senderName: string
  receiverId: string
  receiverType: "business" | "institution"
  receiverName: string
  content: string
  timestamp: Date
  read: boolean
  attachments?: string[]
}

export interface FundingApplication {
  id: string
  businessId: string
  businessName: string
  institutionId: string
  institutionName: string
  requestId?: string
  amount: number
  purpose: string
  status: "submitted" | "reviewing" | "approved" | "rejected" | "funded"
  submissionDate: Date
  lastUpdated: Date
  notes?: string
  documents: string[]
  terms?: {
    interestRate?: number
    term?: string
    paymentSchedule?: string
    specialConditions?: string[]
  }
}

